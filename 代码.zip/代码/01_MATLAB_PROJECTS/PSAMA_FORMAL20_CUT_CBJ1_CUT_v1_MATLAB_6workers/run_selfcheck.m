function report = run_selfcheck()
%RUN_SELFCHECK Final-route correctness gate.
%
% Checks:
%   1) canonical 10J2F decoder/TEC regression;
%   2) MATLAB CUT vs independent global fixed-speed timing MILP;
%   3) one CBJ1 move from CUT optimum;
%   4) strict post-CUT improvement must change speed;
%   5) final CUT is nonworsening;
%   6) exact signed-rank / Holm utilities.

    setup_project();
    audit_config_fields();

    assert_digraph_maxflow_available();

    if exist('intlinprog','file')~=2
        error('PSAMA:MissingOptimizationToolbox', ...
            'Self-check requires intlinprog.');
    end

    cfg = make_shared_config();

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir,'10J2F.txt'),cfg);

    chromosome = make_canonical_10J2F_chromosome(inst);

    [obj,decoded,eval] = evaluate_solution(chromosome,inst,cfg);

    assert(abs(obj(1)-88)<1e-12);
    assert(abs(eval.totalElectricityCost-2803.164)<1e-8);

    deadline = decoded.makespan;

    CUT = solve_cut_retime(decoded,inst,cfg,deadline);

    MILP = solve_global_fixedspeed_milp( ...
        decoded,inst,cfg,deadline);

    if ~MILP.exactCertified
        error('PSAMA:SelfcheckMILPNotExact', ...
            'Independent global timing MILP was not exact-certified.');
    end

    if abs(CUT.totalTEC-MILP.totalTEC)>cfg.block.objectiveTolerance
        error('PSAMA:CUTMilpCrosscheckFailure', ...
            'MATLAB CUT and independent global timing MILP differ.');
    end

    cb = apply_one_cbj1(CUT.decoded,deadline,inst,cfg);

    if cb.accepted
        speedChanges = sum( ...
            cb.decoded.op.speed(:)~=CUT.decoded.op.speed(:));

        if speedChanges<=0
            error('PSAMA:SelfcheckSpeedAttribution', ...
                'Strict post-CUT CBJ1 improvement changed no speed.');
        end
    else
        speedChanges = 0;
    end

    FINAL = solve_cut_retime(cb.decoded,inst,cfg,deadline);

    if FINAL.totalTEC>CUT.totalTEC+cfg.block.objectiveTolerance
        error('PSAMA:SelfcheckFinalWorseThanCUT', ...
            'Final route became worse than first CUT.');
    end

    W = exact_signed_rank_dp((1:20)');

    assert(W.rankBiserial>0.999999);
    assert(abs(W.pTwoSided-2/2^20)<1e-12);

    adj = holm_adjust([0.001;0.01;0.02]);
    assert(all(adj>=0 & adj<=1));

    report.ok = true;
    report.baseTEC = decoded.cost.total;
    report.cutTEC = CUT.totalTEC;
    report.milpTEC = MILP.totalTEC;
    report.cbAccepted = cb.accepted;
    report.speedChanges = speedChanges;
    report.finalTEC = FINAL.totalTEC;
    report.speedValueAboveCUT = CUT.totalTEC-FINAL.totalTEC;

    report.cutNodes = CUT.nodes;
    report.cutEdges = CUT.edges;
    report.cutSeconds = CUT.totalSeconds;
    report.milpSeconds = MILP.solveSeconds;

    fprintf(['[PASS] Formal CUT-CBJ1-CUT self-check: ' ...
             'BASE=%.3f, CUT=%.3f, MILP=%.3f, ' ...
             'CBaccepted=%d, speedChanges=%d, FINAL=%.3f, ' ...
             'speedValue=%.3f.\n'], ...
        report.baseTEC,report.cutTEC,report.milpTEC, ...
        report.cbAccepted,report.speedChanges, ...
        report.finalTEC,report.speedValueAboveCUT);
end
