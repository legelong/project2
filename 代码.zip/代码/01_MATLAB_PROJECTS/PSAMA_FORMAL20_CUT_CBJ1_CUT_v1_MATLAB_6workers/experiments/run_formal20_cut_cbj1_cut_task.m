function summary = run_formal20_cut_cbj1_cut_task( ...
    task,cfg,expCfg,resultRoot,configHash)
%RUN_FORMAL20_CUT_CBJ1_CUT_TASK One complete formal paired run.

    outDir = fullfile(resultRoot,'raw',task.instanceName);

    if ~isfolder(outDir)
        mkdir(outDir);
    end

    outFile = fullfile(outDir,sprintf('run_%02d.mat',task.runIndex));

    if expCfg.resume && isfile(outFile)
        try
            S = load(outFile,'record');

            if isfield(S,'record') && ...
               isfield(S.record,'complete') && ...
               S.record.complete && ...
               isfield(S.record.summary,'configHash') && ...
               strcmp(S.record.summary.configHash,configHash)

                summary = S.record.summary;
                summary.skipped = true;
                return;
            end
        catch
        end
    end

    % Excluded from Stage-I and Stage-II timings.
    warm_formal_worker(cfg);

    variant = make_uniform_variant();

    options.maxNFE = expCfg.stage1NFE;
    options.populationSize = cfg.evolution.populationSize;

    stage1 = run_uniform_joint_checkpoint( ...
        task.instanceName,task.runIndex,task.seed,cfg,options,variant);

    base = stage1.result;
    checkpoint = stage1.state;

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir,[task.instanceName '.txt']),cfg);

    selected = select_diverse_archive_points( ...
        base.archive.objectives,cfg.refinement.maxRepresentativePoints);

    branch = refine_archive_cut_cbj1_cut( ...
        base,selected,inst,cfg);

    targetSeconds = max( ...
        branch.elapsedSeconds,cfg.fairness.minimumTimeBudgetSeconds);

    cont = continue_uniform_joint_walltime_snapshots( ...
        checkpoint,targetSeconds,inst,cfg,variant);

    fronts.BASE = nondominated_objectives(base.archive.objectives);
    fronts.CUT = branch.frontCUT;
    fronts.CUT_CBJ1 = branch.frontCUT_CBJ1;
    fronts.FINAL = branch.frontFINAL;
    fronts.CONT_FINAL = nondominated_objectives( ...
        cont.snapshots{1}.archive.objectives);

    % ---------------------------------------------------------------
    % Compact follow-up material (NOT used by the present experiment)
    % ---------------------------------------------------------------
    % This allows a later, separately registered strong control:
    %
    %     CONT_FINAL -> CUT
    %
    % without rerunning Stage-I or the matched continuation.
    %
    % We save only <=8 diverse continuation archive chromosomes rather than
    % the complete archive, keeping raw files compact. This logging happens
    % after all timed branches, so it does not affect the current fairness
    % target or measured algorithm times.
    contArchive = cont.snapshots{1}.archive;

    contSelected = select_diverse_archive_points( ...
        contArchive.objectives,cfg.refinement.maxRepresentativePoints);

    followup.contSelectedArchiveIndices = contSelected;
    followup.contSelectedChromosomes = ...
        contArchive.chromosomes(contSelected,:);
    followup.contSelectedObjectives = ...
        contArchive.objectives(contSelected,:);

    followup.baseSelectedArchiveIndices = selected;
    followup.baseSelectedChromosomes = ...
        base.archive.chromosomes(selected,:);
    followup.baseSelectedObjectives = ...
        base.archive.objectives(selected,:);

    summary.instance = task.instanceName;
    summary.run = task.runIndex;
    summary.seed = task.seed;
    summary.configHash = configHash;

    summary.stage1NFE = base.nfe;
    summary.stage1Runtime = base.elapsedSeconds;
    summary.stage1ArchiveSize = size(fronts.BASE,1);

    summary.selectedPoints = numel(selected);

    summary.finalTargetSeconds = targetSeconds;

    summary.firstCUTSeconds = branch.totalFirstCUTSeconds;
    summary.CBWallSeconds = branch.totalCBWallSeconds;
    summary.finalCUTSeconds = branch.totalFinalCUTSeconds;

    summary.CBExactEvaluations = branch.totalExactEvaluations;
    summary.CBCandidateCount = branch.totalCandidates;
    summary.CBExactSeconds = branch.totalExactSeconds;
    summary.CBBoundSeconds = branch.totalBoundSeconds;

    summary.CBAcceptedPoints = branch.acceptedPoints;
    summary.strictSpeedValuePoints = branch.strictSpeedValuePoints;
    summary.totalSpeedChangedOps = branch.totalSpeedChangedOps;

    summary.CONTActualSeconds = cont.actualSeconds(1);
    summary.CONTOvershootSeconds = cont.overshootSeconds(1);
    summary.CONTOvershootFraction = cont.overshootFraction(1);
    summary.CONTNFEAdded = cont.nfeAddedAt(1);
    summary.CONTGenerationsAdded = cont.generationsAddedAt(1);

    summary.source = 'FRESH_FORMAL_RUN';
    summary.skipped = false;

    record.complete = true;
    record.summary = summary;

    record.selectedArchiveIndices = selected;
    record.fronts = fronts;
    record.refinementTraces = branch.traces;

    % Compact material for a future separately analyzed CONT_FINAL->CUT
    % experiment. It is intentionally not included in current metrics.
    record.followup = followup;

    save(outFile,'record','-v7');
end
