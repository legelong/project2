function branch = refine_archive_cut_cbj1_cut(base,selected,inst,cfg)
%REFINE_ARCHIVE_CUT_CBJ1_CUT Frozen final terminal branch.
%
% For each selected Stage-I archive schedule:
%
%   1) CUT: global exact fixed-speed retiming under source deadline.
%   2) CBJ1: one exact best local speed+timing block move from CUT schedule.
%   3) CUT: global exact fixed-speed retiming at the new speed vector.
%
% The source deadline is ALWAYS the BASE decoded Cmax and is not tightened
% after the first CUT or CBJ1.
%
% Outputs:
%   CUT objectives
%   CUT_CBJ1 intermediate objectives
%   FINAL = CUT_CBJ1_CUT objectives
%
% The elapsedSeconds field is the actual complete FINAL-branch wall time and is
% used as the matched continuation target.

    K = numel(selected);

    cutObjectives = nan(K,2);
    cbObjectives = nan(K,2);
    finalObjectives = nan(K,2);

    traces = cell(K,1);

    baseFront = nondominated_objectives(base.archive.objectives);

    tBranch = tic;

    for k = 1:K
        archiveIdx = selected(k);
        chromosome = base.archive.chromosomes(archiveIdx,:);

        [obj,decoded] = evaluate_solution(chromosome,inst,cfg);

        if max(abs(obj-base.archive.objectives(archiveIdx,:)))>1e-8
            error('PSAMA:FormalArchiveDecodeMismatch', ...
                'Archive chromosome/objective mismatch.');
        end

        deadline = decoded.makespan;

        % ---------------- First CUT ----------------
        t = tic;
        firstCUT = solve_cut_retime(decoded,inst,cfg,deadline);
        timeFirstCUT = toc(t);

        % ---------------- One CBJ1 from CUT optimum ----------------
        t = tic;
        cb = apply_one_cbj1(firstCUT.decoded,deadline,inst,cfg);
        timeCB = toc(t);

        % If a strict local improvement exists after the fixed-speed global
        % timing optimum, it must change at least one speed.
        if cb.accepted
            speedChanges = sum( ...
                cb.decoded.op.speed(:)~=firstCUT.decoded.op.speed(:));

            if speedChanges<=0
                error('PSAMA:FormalSpeedAttributionContradiction', ...
                    ['Post-CUT CBJ1 strictly improved without changing speed. ' ...
                     'Check CUT / block objective consistency.']);
            end
        else
            speedChanges = 0;
        end

        % ---------------- Final CUT ----------------
        t = tic;
        finalCUT = solve_cut_retime(cb.decoded,inst,cfg,deadline);
        timeFinalCUT = toc(t);

        tol = cfg.block.objectiveTolerance;

        if firstCUT.totalTEC > decoded.cost.total+tol
            error('PSAMA:FormalFirstCUTWorse', ...
                'First CUT became worse than the BASE schedule.');
        end

        if cb.decoded.cost.total > firstCUT.totalTEC+tol
            error('PSAMA:FormalCBJ1Worse', ...
                'CBJ1 became worse than its CUT-optimal source.');
        end

        if finalCUT.totalTEC > cb.decoded.cost.total+tol
            error('PSAMA:FormalFinalCUTWorse', ...
                'Final CUT became worse than CUT->CBJ1.');
        end

        cutObjectives(k,:) = firstCUT.decoded.objectives;
        cbObjectives(k,:) = cb.decoded.objectives;
        finalObjectives(k,:) = finalCUT.decoded.objectives;

        tr.archiveIndex = archiveIdx;

        tr.baseObjectives = obj;
        tr.deadline = deadline;

        tr.cutObjectives = firstCUT.decoded.objectives;
        tr.cbObjectives = cb.decoded.objectives;
        tr.finalObjectives = finalCUT.decoded.objectives;

        tr.cutReductionPct = ...
            100*(obj(2)-tr.cutObjectives(2))/max(obj(2),eps);

        tr.finalReductionPct = ...
            100*(obj(2)-tr.finalObjectives(2))/max(obj(2),eps);

        tr.speedValueAboveCUT = ...
            tr.cutObjectives(2)-tr.finalObjectives(2);

        tr.speedValueAboveCUTPctOfBase = ...
            100*tr.speedValueAboveCUT/max(obj(2),eps);

        tr.cbAccepted = cb.accepted;
        tr.speedChangedOps = speedChanges;

        tr.bestGain = cb.bestGain;
        tr.bestBlockLength = cb.bestBlockLength;
        tr.bestBoundRank = cb.bestBoundRank;

        tr.totalCandidates = cb.totalCandidates;
        tr.exactEvaluations = cb.exactEvaluations;
        tr.exactEvaluationFraction = cb.exactEvaluationFraction;
        tr.exactSeconds = cb.exactSeconds;
        tr.boundSeconds = cb.boundSeconds;

        tr.firstCUTSeconds = timeFirstCUT;
        tr.cbWallSeconds = timeCB;
        tr.finalCUTSeconds = timeFinalCUT;
        tr.routeWallSeconds = ...
            timeFirstCUT+timeCB+timeFinalCUT;

        tr.firstCUTNodes = firstCUT.nodes;
        tr.firstCUTEdges = firstCUT.edges;
        tr.finalCUTNodes = finalCUT.nodes;
        tr.finalCUTEdges = finalCUT.edges;

        tr.firstCUTCertificate = firstCUT.certificateValid;
        tr.finalCUTCertificate = finalCUT.certificateValid;

        traces{k} = tr;
    end

    branch.elapsedSeconds = toc(tBranch);

    branch.cutObjectives = cutObjectives;
    branch.cbObjectives = cbObjectives;
    branch.finalObjectives = finalObjectives;
    branch.traces = traces;

    branch.frontCUT = nondominated_objectives([baseFront;cutObjectives]);
    branch.frontCUT_CBJ1 = nondominated_objectives([baseFront;cbObjectives]);
    branch.frontFINAL = nondominated_objectives([baseFront;finalObjectives]);

    branch.totalExactEvaluations = 0;
    branch.totalCandidates = 0;
    branch.totalExactSeconds = 0;
    branch.totalBoundSeconds = 0;

    branch.totalFirstCUTSeconds = 0;
    branch.totalCBWallSeconds = 0;
    branch.totalFinalCUTSeconds = 0;

    branch.acceptedPoints = 0;
    branch.strictSpeedValuePoints = 0;
    branch.totalSpeedChangedOps = 0;

    for k = 1:K
        tr = traces{k};

        branch.totalExactEvaluations = ...
            branch.totalExactEvaluations+tr.exactEvaluations;

        branch.totalCandidates = ...
            branch.totalCandidates+tr.totalCandidates;

        branch.totalExactSeconds = ...
            branch.totalExactSeconds+tr.exactSeconds;

        branch.totalBoundSeconds = ...
            branch.totalBoundSeconds+tr.boundSeconds;

        branch.totalFirstCUTSeconds = ...
            branch.totalFirstCUTSeconds+tr.firstCUTSeconds;

        branch.totalCBWallSeconds = ...
            branch.totalCBWallSeconds+tr.cbWallSeconds;

        branch.totalFinalCUTSeconds = ...
            branch.totalFinalCUTSeconds+tr.finalCUTSeconds;

        branch.acceptedPoints = ...
            branch.acceptedPoints+double(tr.cbAccepted);

        branch.strictSpeedValuePoints = ...
            branch.strictSpeedValuePoints+ ...
            double(tr.speedValueAboveCUT>cfg.cb.improvementTolerance);

        branch.totalSpeedChangedOps = ...
            branch.totalSpeedChangedOps+tr.speedChangedOps;
    end
end
