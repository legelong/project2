function warm_formal_worker(cfg)
%WARM_FORMAL_WORKER One-time worker-local solver warm-up.
%
% Formal route timings should not be dominated by one-time class loading/JIT
% on a worker's first task. Each process worker therefore performs one tiny
% deterministic warm-up before Stage-I timing starts.
%
% persistent state is worker-local in a Processes pool.

    persistent warmed

    if ~isempty(warmed) && warmed
        return;
    end

    assert_digraph_maxflow_available();

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir,'10J2F.txt'),cfg);

    chromosome = make_canonical_10J2F_chromosome(inst);
    [~,decoded] = evaluate_solution(chromosome,inst,cfg);

    % Warm maxflow / CUT.
    solve_cut_retime(decoded,inst,cfg,decoded.makespan);

    % Warm intlinprog through a single deterministic reduced-family block.
    blocks = enumerate_containment_reduced_blocks( ...
        decoded,decoded.makespan,inst,cfg);

    if ~isempty(blocks)
        sol = solve_block_speed_time_milp( ...
            decoded,blocks(1),inst,cfg,'JOINT'); %#ok<NASGU>
    end

    warmed = true;
end
