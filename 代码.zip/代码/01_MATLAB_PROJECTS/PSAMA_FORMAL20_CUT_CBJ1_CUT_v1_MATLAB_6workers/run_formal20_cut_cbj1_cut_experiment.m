function outputs = run_formal20_cut_cbj1_cut_experiment()
%RUN_FORMAL20_CUT_CBJ1_CUT_EXPERIMENT Frozen final 20-instance study.

    setup_project();

    cfg = make_shared_config();
    expCfg = make_formal20_cut_cbj1_cut_experiment();

    [configHash,signature] = ...
        compute_formal20_cut_cbj1_cut_hash(cfg,expCfg);

    assert_digraph_maxflow_available();

    if exist('intlinprog','file')~=2
        error('PSAMA:MissingOptimizationToolbox', ...
            'Optimization Toolbox / intlinprog is required.');
    end

    fprintf('\n============================================================\n');
    fprintf('PSA-MA FORMAL 20-INSTANCE CUT-CBJ1-CUT v1\n');
    fprintf('Instances : 20 Li DHFJSP benchmarks\n');
    fprintf('Runs      : %d each\n',expCfg.numRuns);
    fprintf('Stage-I   : UNIFORM_JOINT, %d NFE\n',expCfg.stage1NFE);
    fprintf('Stage-II  : CUT -> one exact CBJ1 -> CUT\n');
    fprintf('Fixed base: CUT\n');
    fprintf('Fair ctrl : same-time CONT_FINAL from same Stage-I checkpoint\n');
    fprintf('Blocks    : all L5 + non-embeddable L3\n');
    fprintf('Workers   : %d Processes workers\n',expCfg.workers);
    fprintf('Raw reuse : none (fresh resumable Stage-I state required)\n');
    fprintf('ConfigHash: %s\n',configHash);
    fprintf('============================================================\n\n');

    resultRoot = fullfile(cfg.project.root,'results',expCfg.tag);

    if ~isfolder(resultRoot)
        mkdir(resultRoot);
    end

    save(fullfile(resultRoot,'experiment_config.mat'), ...
        'cfg','expCfg','configHash','signature','-v7');

    d = fullfile(resultRoot,'manifests');

    if ~isfolder(d)
        mkdir(d);
    end

    fid = fopen(fullfile(d,'protocol_signature.json'),'w');
    fprintf(fid,'%s',signature);
    fclose(fid);

    % Start the requested Processes pool BEFORE repository preparation.
    % The same pool is reused for both initial-population generation and the
    % expensive formal run tasks.
    poolInfo = ensure_parallel_pool(expCfg.workers); %#ok<NASGU>

    % Deterministic initial populations are prepared in parallel by instance.
    prepare_formal_initial_populations(cfg,expCfg);

    % Pre-create instance raw directories serially.
    for ii = 1:numel(expCfg.instances)
        dInst = fullfile(resultRoot,'raw',expCfg.instances{ii});

        if ~isfolder(dInst)
            mkdir(dInst);
        end
    end

    tasks = struct('instanceName',{},'runIndex',{},'seed',{});

    t = 0;

    for ii = 1:numel(expCfg.instances)
        for rr = 1:expCfg.numRuns
            t = t+1;

            tasks(t).instanceName = expCfg.instances{ii};
            tasks(t).runIndex = rr;
            tasks(t).seed = cfg.experiment.baseSeed+rr-1;
        end
    end

    summaries = cell(numel(tasks),1);

    parfor i = 1:numel(tasks)
        summaries{i} = run_formal20_cut_cbj1_cut_task( ...
            tasks(i),cfg,expCfg,resultRoot,configHash);

        fprintf(['[DONE] %s run%02d | StageI %.1fs | FINAL %.1fs | ' ...
                 'CUT %.2fs | CB exact=%d | speed+ points=%d/%d | ' ...
                 'CONT +NFE=%d\n'], ...
            tasks(i).instanceName,tasks(i).runIndex, ...
            summaries{i}.stage1Runtime, ...
            summaries{i}.finalTargetSeconds, ...
            summaries{i}.firstCUTSeconds, ...
            summaries{i}.CBExactEvaluations, ...
            summaries{i}.strictSpeedValuePoints, ...
            summaries{i}.selectedPoints, ...
            summaries{i}.CONTNFEAdded);
    end

    fprintf('\nBuilding paper-ready tables and statistics...\n');

    outputs = postprocess_formal20_cut_cbj1_cut( ...
        resultRoot,cfg,expCfg);

    save(fullfile(resultRoot,'formal20_cut_cbj1_cut_outputs.mat'), ...
        'outputs','-v7');

    fprintf('\n============================================================\n');
    fprintf('[FORMAL 20-INSTANCE CUT-CBJ1-CUT COMPLETE]\n');
    fprintf('Results: %s\n',resultRoot);
    fprintf('============================================================\n');
end
