function [hash,signature] = compute_formal20_cut_cbj1_cut_hash(cfg,expCfg)
%COMPUTE_FORMAL20_CUT_CBJ1_CUT_HASH Stable protocol fingerprint.

    S.algorithmVersion = cfg.project.algorithmVersion;
    S.instances = expCfg.instances;
    S.numRuns = expCfg.numRuns;
    S.stage1NFE = expCfg.stage1NFE;
    S.baseSeed = cfg.experiment.baseSeed;

    S.populationSize = cfg.evolution.populationSize;
    S.localSearchRatio = cfg.experiment.localSearchRatio;

    S.representativePoints = cfg.refinement.maxRepresentativePoints;
    S.blockFamily = 'all_L5_plus_nonembeddable_L3';

    S.finalRoute = 'CUT_then_one_CBJ1_then_CUT';
    S.fairnessRoute = 'CONT_FINAL_same_wall_time';

    S.timeGrid = cfg.block.timeGrid;
    S.blockMaxSolveSeconds = cfg.block.maxSolveSeconds;
    S.blockObjectiveTolerance = cfg.block.objectiveTolerance;

    S.speedLevels = cfg.problem.speedLevels;
    S.processingPowerCoefficient = cfg.problem.processingPowerCoefficient;
    S.idlePower = cfg.problem.idlePower;

    S.tariff = [ ...
        cfg.tariff.flatPrice, ...
        cfg.tariff.valleyPrice, ...
        cfg.tariff.peakPrice];

    signature = jsonencode(S);

    try
        md = javaMethod('getInstance','java.security.MessageDigest','MD5');
        md.update(uint8(signature));
        bytes = uint8(md.digest());
        hash = lower(reshape(dec2hex(bytes,2).',1,[]));
    catch
        u = double(uint8(signature));
        weights = mod((1:numel(u))*1315423911,2147483647);
        checksum = mod(sum(mod(u.*weights,2147483647)),2147483647);
        hash = sprintf('fallback_%010u',uint32(checksum));
    end
end
