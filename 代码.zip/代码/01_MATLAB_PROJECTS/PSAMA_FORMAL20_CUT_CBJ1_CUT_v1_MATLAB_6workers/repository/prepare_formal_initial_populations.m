function prepare_formal_initial_populations(cfg,expCfg)
%PREPARE_FORMAL_INITIAL_POPULATIONS Parallel deterministic preparation.
%
% The pool is started by the launcher before this function is called.
%
% Safety:
%   - each parfor iteration owns one instance directory;
%   - run files are unique by instance/run/seed;
%   - RNG is process-local because the project uses a Processes pool;
%   - existing files are validated/reused by get_shared_initial_population.
%
% This is preparation only; it does not change the scientific protocol.

    fprintf('[Repository] Preparing formal initial populations in parallel...\n');

    % Pre-create instance folders serially so workers never race on mkdir.
    for ii = 1:numel(expCfg.instances)
        d = fullfile(cfg.project.root,'initial_populations', ...
            expCfg.instances{ii});

        if ~isfolder(d)
            mkdir(d);
        end
    end

    nInstances = numel(expCfg.instances);

    parfor ii = 1:nInstances
        name = expCfg.instances{ii};

        inst = load_dhfjsp_instance( ...
            fullfile(cfg.paths.dhfjspInstanceDir,[name '.txt']),cfg);

        for rr = 1:expCfg.numRuns
            seed = cfg.experiment.baseSeed+rr-1;

            X = get_shared_initial_population( ...
                inst,name,rr,seed,cfg);

            assert(size(X,1)==cfg.evolution.populationSize);
            assert(size(X,2)==inst.encoding.totalLength);
        end

        fprintf('[Repository] Initial populations ready: %s\n',name);
    end

    fprintf('[Repository] All formal initial populations ready.\n');
end
