function outputs = summarize_formal20_cut_cbj1_cut()
%SUMMARIZE_FORMAL20_CUT_CBJ1_CUT Show the formal main evidence.

    setup_project();

    cfg = make_shared_config();
    expCfg = make_formal20_cut_cbj1_cut_experiment();

    root = fullfile(cfg.project.root,'results',expCfg.tag,'tables');

    outputs.summary = readtable( ...
        fullfile(root,'summary_by_instance_method.csv'));

    outputs.deltas = readtable( ...
        fullfile(root,'paired_deltas.csv'));

    outputs.statistics = readtable( ...
        fullfile(root,'paired_statistics.csv'));

    outputs.winTieLoss = readtable( ...
        fullfile(root,'win_tie_loss_by_instance.csv'));

    outputs.runtime = readtable( ...
        fullfile(root,'runtime_summary.csv'));

    outputs.refinement = readtable( ...
        fullfile(root,'refinement_summary.csv'));

    fprintf('\n=== PRIMARY SCIENTIFIC CONTRAST: FINAL vs CUT ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'FINAL_vs_CUT'),:));

    fprintf('\n=== PRIMARY COMPUTATION FAIRNESS: FINAL vs CONT_FINAL ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'FINAL_vs_CONT_FINAL'),:));

    fprintf('\n=== TIMING VALUE: CUT vs BASE ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'CUT_vs_BASE'),:));

    fprintf('\n=== Win / tie / loss across 20 instances ===\n');
    disp(outputs.winTieLoss);

    fprintf('\n=== Runtime overhead ===\n');
    disp(outputs.runtime);

    fprintf('\n=== Schedule-level exact refinement ===\n');
    disp(outputs.refinement);
end
