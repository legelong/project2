function T = run_scale_smoke_test()
%RUN_SCALE_SMOKE_TEST One deterministic final-route schedule at increasing size.
%
% Purpose:
%   catch large-instance MATLAB maxflow / MILP / memory issues before starting
%   the 400-run formal experiment.
%
% This is a software-scale smoke test, NOT scientific evidence.
%
% Instances:
%   10J2F
%   50J5F
%   100J6F
%   200J7F
%
% For each instance:
%   use the first chromosome from one deterministic shared initial population,
%   then run CUT -> one CBJ1 -> CUT under the source Cmax.

    setup_project();

    cfg = make_shared_config();

    names = {'10J2F','50J5F','100J6F','200J7F'};

    rows = cell(numel(names),11);

    for i = 1:numel(names)
        name = names{i};

        fprintf('[SMOKE] %s...\n',name);

        inst = load_dhfjsp_instance( ...
            fullfile(cfg.paths.dhfjspInstanceDir,[name '.txt']),cfg);

        seed = cfg.experiment.baseSeed+900+i;

        X = get_shared_initial_population( ...
            inst,['SMOKE_' name],1,seed,cfg);

        [~,decoded] = evaluate_solution(X(1,:),inst,cfg);

        deadline = decoded.makespan;

        t = tic;
        firstCUT = solve_cut_retime(decoded,inst,cfg,deadline);
        cutTime = toc(t);

        t = tic;
        cb = apply_one_cbj1(firstCUT.decoded,deadline,inst,cfg);
        cbTime = toc(t);

        t = tic;
        finalCUT = solve_cut_retime(cb.decoded,inst,cfg,deadline);
        finalCutTime = toc(t);

        speedChanges = sum( ...
            cb.decoded.op.speed(:)~=firstCUT.decoded.op.speed(:));

        speedValue = firstCUT.totalTEC-finalCUT.totalTEC;

        rows(i,:) = { ...
            name,decoded.makespan,decoded.cost.total, ...
            firstCUT.totalTEC,finalCUT.totalTEC,speedValue, ...
            speedChanges,cb.exactEvaluations, ...
            cutTime,cbTime,finalCutTime};

        fprintf(['        BASE=%.3f CUT=%.3f FINAL=%.3f ' ...
                 'speedValue=%.3f changes=%d exact=%d time=%.1fs\n'], ...
            decoded.cost.total,firstCUT.totalTEC,finalCUT.totalTEC, ...
            speedValue,speedChanges,cb.exactEvaluations, ...
            cutTime+cbTime+finalCutTime);
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Cmax','BaseTEC','CUTTEC','FinalTEC', ...
        'SpeedValueAboveCUT','SpeedChangedOps','ExactEvaluations', ...
        'FirstCUT_s','CB_s','FinalCUT_s'});

    outDir = fullfile(cfg.project.root,'results','scale_smoke_test');

    if ~isfolder(outDir)
        mkdir(outDir);
    end

    writetable(T,fullfile(outDir,'scale_smoke_test.csv'));

    fprintf('\n[PASS] Scale smoke test complete.\n');
    disp(T);
end
