function outputs = run_nsga2_cut_comparison()
%RUN_NSGA2_CUT_COMPARISON Formal generic-search baseline experiment.
%
% Newly computes:
%   NSGA-II @ 10000 NFE
%   NSGA-II + CUT
%
% Reuses frozen completed formal fronts:
%   Uniform MA
%   Uniform MA + CUT
%   FINAL = Uniform MA + CUT -> CBJ1 -> CUT

    setup_project();

    cfg = make_shared_config();
    expCfg = make_nsga2_cut_comparison_experiment();

    [configHash,signature] = compute_nsga2_cut_hash(cfg,expCfg);

    assert_digraph_maxflow_available();

    fprintf('\n============================================================\n');
    fprintf('PSA-MA NSGA-II + CUT COMPARISON v1\n');
    fprintf('Instances : all 20 Li benchmarks\n');
    fprintf('Runs      : %d each\n',expCfg.numRuns);
    fprintf('NFE       : %d\n',expCfg.stage1NFE);
    fprintf('New       : NSGA-II / NSGA-II+CUT\n');
    fprintf('Frozen    : Uniform / Uniform+CUT / FINAL\n');
    fprintf('Init/seed : same deterministic initializer, seeds 20262201-20\n');
    fprintf('Workers   : %d Processes workers\n',expCfg.workers);
    fprintf('ConfigHash: %s\n',configHash);
    fprintf('============================================================\n\n');

    sourceReport = validate_formal_uniform_source(cfg,expCfg); %#ok<NASGU>

    resultRoot = fullfile(cfg.project.root,'results',expCfg.tag);

    if ~isfolder(resultRoot)
        mkdir(resultRoot);
    end

    save(fullfile(resultRoot,'experiment_config.mat'), ...
        'cfg','expCfg','configHash','signature','sourceReport','-v7');

    d = fullfile(resultRoot,'manifests');
    if ~isfolder(d), mkdir(d); end

    fid = fopen(fullfile(d,'protocol_signature.json'),'w');
    fprintf(fid,'%s',signature);
    fclose(fid);

    poolInfo = ensure_parallel_pool(expCfg.workers); %#ok<NASGU>

    prepare_nsga2_initial_populations(cfg,expCfg);

    for ii = 1:numel(expCfg.instances)
        dInst = fullfile(resultRoot,'raw',expCfg.instances{ii});
        if ~isfolder(dInst), mkdir(dInst); end
    end

    tasks = struct('instanceName',{},'runIndex',{},'seed',{});
    t = 0;

    for ii = 1:numel(expCfg.instances)
        for rr = 1:expCfg.numRuns
            t = t+1;
            tasks(t).instanceName = expCfg.instances{ii};
            tasks(t).runIndex = rr;
            tasks(t).seed = cfg.experiment.baseSeed+rr-1;
        end
    end

    summaries = cell(numel(tasks),1);

    parfor i = 1:numel(tasks)
        summaries{i} = run_nsga2_cut_task( ...
            tasks(i),cfg,expCfg,resultRoot,configHash);

        fprintf(['[DONE] %s run%02d | NSGA-II %.1fs | CUT %.2fs | ' ...
                 'selected=%d | CUT-positive=%d\n'], ...
            tasks(i).instanceName,tasks(i).runIndex, ...
            summaries{i}.stage1Runtime, ...
            summaries{i}.CUTElapsedSeconds, ...
            summaries{i}.selectedPoints, ...
            summaries{i}.strictCUTReductionPoints);
    end

    fprintf('\nRecomputing unified empirical fronts and paired statistics...\n');

    outputs = postprocess_nsga2_cut_comparison( ...
        resultRoot,cfg,expCfg);

    save(fullfile(resultRoot,'nsga2_cut_comparison_outputs.mat'), ...
        'outputs','-v7');

    fprintf('\n============================================================\n');
    fprintf('[NSGA-II + CUT COMPARISON COMPLETE]\n');
    fprintf('Results: %s\n',resultRoot);
    fprintf('============================================================\n');
end
