function report = run_selfcheck()
%RUN_SELFCHECK Generic NSGA-II + CUT software/correctness gate.

    setup_project();
    audit_config_fields();
    assert_digraph_maxflow_available();

    cfg = make_shared_config();
    expCfg = make_nsga2_cut_comparison_experiment();

    sourceReport = validate_formal_uniform_source(cfg,expCfg);

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir,'10J2F.txt'),cfg);

    seed = cfg.experiment.baseSeed;

    X1 = get_shared_initial_population(inst,'SELFCHECK',1,seed,cfg);
    X2 = get_shared_initial_population(inst,'SELFCHECK',1,seed,cfg);

    assert(isequal(X1,X2));

    options.maxNFE = 300;
    options.populationSize = cfg.evolution.populationSize;

    nsga = run_nsga2_checkpoint( ...
        '10J2F',1,seed,cfg,options);

    assert(nsga.nfe==300);
    assert(~isempty(nsga.archive.objectives));

    selected = select_diverse_archive_points( ...
        nsga.archive.objectives,1);

    branch = refine_archive_cut_only(nsga,selected,inst,cfg);

    assert(size(branch.front,2)==2);

    tr = branch.traces{1};

    if tr.cutObjectives(2) > ...
       tr.sourceObjectives(2)+cfg.block.objectiveTolerance
        error('PSAMA:NSGA2SelfcheckCUT', ...
            'CUT became worse in NSGA-II self-check.');
    end

    assert(tr.certificateValid);

    report.ok = true;
    report.formalSourcesChecked = sourceReport.checked;
    report.nsgaNFE = nsga.nfe;
    report.nsgaArchiveSize = size(nsga.archive.objectives,1);
    report.sourceTEC = tr.sourceObjectives(2);
    report.cutTEC = tr.cutObjectives(2);

    fprintf(['[PASS] NSGA-II+CUT self-check: sources=%d, ' ...
             'NFE=%d, archive=%d, sourceTEC=%.3f, CUT=%.3f.\n'], ...
        report.formalSourcesChecked,report.nsgaNFE, ...
        report.nsgaArchiveSize,report.sourceTEC,report.cutTEC);
end
