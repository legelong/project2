function summary = run_nsga2_cut_task( ...
    task,cfg,expCfg,resultRoot,configHash)
%RUN_NSGA2_CUT_TASK One paired NSGA-II 10000-NFE + CUT run.

    outDir = fullfile(resultRoot,'raw',task.instanceName);

    if ~isfolder(outDir)
        mkdir(outDir);
    end

    outFile = fullfile(outDir,sprintf('run_%02d.mat',task.runIndex));

    if expCfg.resume && isfile(outFile)
        try
            S = load(outFile,'record');

            if isfield(S,'record') && ...
               isfield(S.record,'complete') && ...
               S.record.complete && ...
               isfield(S.record.summary,'configHash') && ...
               strcmp(S.record.summary.configHash,configHash)

                summary = S.record.summary;
                summary.skipped = true;
                return;
            end
        catch
        end
    end

    warm_nsga2_cut_worker(cfg);

    options.maxNFE = expCfg.stage1NFE;
    options.populationSize = cfg.evolution.populationSize;

    nsga = run_nsga2_checkpoint( ...
        task.instanceName,task.runIndex,task.seed,cfg,options);

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir, ...
        [task.instanceName '.txt']),cfg);

    selected = select_diverse_archive_points( ...
        nsga.archive.objectives, ...
        cfg.baseline.maxRepresentativePoints);

    cutBranch = refine_archive_cut_only( ...
        nsga,selected,inst,cfg);

    fronts.NSGAII = nondominated_objectives(nsga.archive.objectives);
    fronts.NSGAII_CUT = cutBranch.front;

    summary.instance = task.instanceName;
    summary.run = task.runIndex;
    summary.seed = task.seed;
    summary.configHash = configHash;

    summary.stage1NFE = nsga.nfe;
    summary.stage1Runtime = nsga.elapsedSeconds;
    summary.stage1ArchiveSize = size(fronts.NSGAII,1);

    summary.selectedPoints = numel(selected);
    summary.CUTElapsedSeconds = cutBranch.elapsedSeconds;
    summary.CUTSolveSeconds = cutBranch.totalCUTSeconds;
    summary.strictCUTReductionPoints = cutBranch.strictReductionPoints;

    summary.source = 'FRESH_NSGAII_RUN';
    summary.skipped = false;

    record.complete = true;
    record.summary = summary;
    record.selectedArchiveIndices = selected;
    record.fronts = fronts;
    record.archive = nsga.archive;
    record.cutTraces = cutBranch.traces;

    save(outFile,'record','-v7');
end
