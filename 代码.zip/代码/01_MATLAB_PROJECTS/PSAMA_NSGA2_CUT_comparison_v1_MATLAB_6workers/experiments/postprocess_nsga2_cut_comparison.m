function outputs = postprocess_nsga2_cut_comparison( ...
    resultRoot,cfg,expCfg)
%POSTPROCESS_NSGA2_CUT_COMPARISON Paired algorithm-level comparison.
%
% New:
%   NSGAII
%   NSGAII_CUT
%
% Frozen source:
%   UNIFORM      = formal BASE
%   UNIFORM_CUT  = formal CUT
%   FINAL        = formal CUT->CBJ1->CUT
%
% All metrics are recomputed under one enlarged empirical reference front that
% includes all five methods.

    tableRoot = fullfile(resultRoot,'tables');
    figRoot = fullfile(resultRoot,'figures');
    refRoot = fullfile(resultRoot,'reference_fronts');

    ensure_dir(tableRoot);
    ensure_dir(figRoot);
    ensure_dir(refRoot);

    methods = { ...
        'NSGAII','NSGAII_CUT','UNIFORM','UNIFORM_CUT','FINAL'};

    newRecords = cell(numel(expCfg.instances),expCfg.numRuns);
    formalRecords = cell(numel(expCfg.instances),expCfg.numRuns);

    refs = cell(numel(expCfg.instances),1);
    bounds = cell(numel(expCfg.instances),1);

    formalRoot = fullfile(cfg.project.root,'source_results', ...
        cfg.repository.sourceFormalTag,'raw');

    for ii = 1:numel(expCfg.instances)
        inst = expCfg.instances{ii};
        unionPts = [];

        for rr = 1:expCfg.numRuns
            S1 = load(fullfile(resultRoot,'raw',inst, ...
                sprintf('run_%02d.mat',rr)),'record');

            S2 = load(fullfile(formalRoot,inst, ...
                sprintf('run_%02d.mat',rr)),'record');

            N = S1.record;
            F = S2.record;

            newRecords{ii,rr} = N;
            formalRecords{ii,rr} = F;

            unionPts = [unionPts; ...
                N.fronts.NSGAII; ...
                N.fronts.NSGAII_CUT; ...
                F.fronts.BASE; ...
                F.fronts.CUT; ...
                F.fronts.FINAL]; %#ok<AGROW>
        end

        ref = nondominated_objectives(unionPts);
        refs{ii} = ref;

        lo = min(unionPts,[],1);
        hi = max(unionPts,[],1);
        span = hi-lo;
        span(span<=1e-12) = 1;

        bounds{ii}.lo = lo;
        bounds{ii}.span = span;

        writematrix(ref, ...
            fullfile(refRoot,[inst '_empirical_reference.csv']));
    end

    metricRows = {};
    runtimeRows = {};
    cutRows = {};
    rn = 0;

    for ii = 1:numel(expCfg.instances)
        inst = expCfg.instances{ii};

        lo = bounds{ii}.lo;
        span = bounds{ii}.span;
        refN = (refs{ii}-lo)./span;

        for rr = 1:expCfg.numRuns
            N = newRecords{ii,rr};
            F = formalRecords{ii,rr};

            fronts.NSGAII = N.fronts.NSGAII;
            fronts.NSGAII_CUT = N.fronts.NSGAII_CUT;
            fronts.UNIFORM = F.fronts.BASE;
            fronts.UNIFORM_CUT = F.fronts.CUT;
            fronts.FINAL = F.fronts.FINAL;

            for m = 1:numel(methods)
                method = methods{m};
                P = fronts.(method);
                PN = (P-lo)./span;

                rn = rn+1;

                metricRows(rn,:) = { ...
                    inst,rr,N.summary.seed,method, ...
                    size(P,1),min(P(:,1)),min(P(:,2)), ...
                    compute_hypervolume_2d( ...
                        PN,cfg.refinement.hvReferencePoint), ...
                    compute_igd(PN,refN)};
            end

            runtimeRows(end+1,:) = { ... %#ok<AGROW>
                inst,rr,N.summary.seed, ...
                N.summary.stage1Runtime, ...
                N.summary.CUTElapsedSeconds, ...
                F.summary.stage1Runtime, ...
                F.summary.firstCUTSeconds, ...
                F.summary.finalTargetSeconds, ...
                N.summary.selectedPoints, ...
                F.summary.selectedPoints};

            for k = 1:numel(N.cutTraces)
                if iscell(N.cutTraces)
                    tr = N.cutTraces{k};
                else
                    tr = N.cutTraces(k);
                end

                cutRows(end+1,:) = { ... %#ok<AGROW>
                    inst,rr,k,tr.archiveIndex, ...
                    tr.sourceObjectives(1),tr.sourceObjectives(2), ...
                    tr.cutObjectives(1),tr.cutObjectives(2), ...
                    tr.tecReduction,tr.tecReductionPct, ...
                    tr.cutWallSeconds,tr.cutNodes,tr.cutEdges, ...
                    tr.certificateValid};
            end
        end
    end

    metricsT = cell2table(metricRows,'VariableNames',{ ...
        'Instance','Run','Seed','Method', ...
        'ArchiveSize','MinCmax','MinTEC','HV','IGD'});

    runtimeT = cell2table(runtimeRows,'VariableNames',{ ...
        'Instance','Run','Seed', ...
        'NSGAIIStage1_s','NSGAIICUT_s', ...
        'UniformStage1_s','UniformCUT_s','FINALRoute_s', ...
        'NSGAIISelectedPoints','UniformSelectedPoints'});

    cutT = cell2table(cutRows,'VariableNames',{ ...
        'Instance','Run','SelectedPoint','ArchiveIndex', ...
        'SourceCmax','SourceTEC','CUTCmax','CUTTEC', ...
        'TECReduction','TECReductionPct', ...
        'CUTWall_s','CUTNodes','CUTEdges','CertificateValid'});

    summaryT = summarize_methods(metricsT);
    deltaT = paired_deltas(metricsT);
    statsT = paired_statistics(metricsT,cfg);
    wtlT = win_tie_loss_instances(deltaT);

    runtimeSummaryT = summarize_runtime(runtimeT);
    cutSummaryT = summarize_cut(cutT);

    writetable(metricsT,fullfile(tableRoot,'run_metrics.csv'));
    writetable(summaryT, ...
        fullfile(tableRoot,'summary_by_instance_method.csv'));

    writetable(deltaT,fullfile(tableRoot,'paired_deltas.csv'));
    writetable(statsT,fullfile(tableRoot,'paired_statistics.csv'));
    writetable(wtlT,fullfile(tableRoot,'win_tie_loss_by_instance.csv'));

    writetable(runtimeT,fullfile(tableRoot,'run_runtime.csv'));
    writetable(runtimeSummaryT, ...
        fullfile(tableRoot,'runtime_summary.csv'));

    writetable(cutT,fullfile(tableRoot,'nsga2_selected_cut.csv'));
    writetable(cutSummaryT, ...
        fullfile(tableRoot,'nsga2_cut_summary.csv'));

    if expCfg.writeXlsx
        try
            writetable(summaryT, ...
                fullfile(tableRoot,'summary_by_instance_method.xlsx'));
            writetable(deltaT,fullfile(tableRoot,'paired_deltas.xlsx'));
            writetable(statsT,fullfile(tableRoot,'paired_statistics.xlsx'));
        catch
        end
    end

    if expCfg.makeFigures
        make_relative_figure( ...
            deltaT,'UNIFORM_CUT_vs_NSGAII_CUT',figRoot);

        make_relative_figure( ...
            deltaT,'FINAL_vs_NSGAII_CUT',figRoot);

        make_runtime_figure(runtimeSummaryT,figRoot);
    end

    outputs.metrics = metricsT;
    outputs.summary = summaryT;
    outputs.deltas = deltaT;
    outputs.statistics = statsT;
    outputs.winTieLoss = wtlT;
    outputs.runtime = runtimeT;
    outputs.runtimeSummary = runtimeSummaryT;
    outputs.cut = cutT;
    outputs.cutSummary = cutSummaryT;
end

function T = summarize_methods(M)
    instances = unique(string(M.Instance),'stable');
    methods = {'NSGAII','NSGAII_CUT','UNIFORM','UNIFORM_CUT','FINAL'};

    rows = {};
    rn = 0;

    for i = 1:numel(instances)
        for m = 1:numel(methods)
            X = M(string(M.Instance)==instances(i) & ...
                  strcmp(M.Method,methods{m}),:);

            rn = rn+1;

            rows(rn,:) = { ...
                char(instances(i)),methods{m},height(X), ...
                mean(X.HV),std(X.HV), ...
                mean(X.IGD),std(X.IGD), ...
                mean(X.MinCmax),mean(X.MinTEC), ...
                mean(X.ArchiveSize)};
        end
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Method','Runs', ...
        'MeanHV','StdHV','MeanIGD','StdIGD', ...
        'MeanMinCmax','MeanMinTEC','MeanArchiveSize'});
end

function T = paired_deltas(M)
    instances = unique(string(M.Instance),'stable');

    contrasts = { ...
        'UNIFORM_vs_NSGAII','NSGAII','UNIFORM'; ...
        'NSGAII_CUT_vs_NSGAII','NSGAII','NSGAII_CUT'; ...
        'UNIFORM_CUT_vs_NSGAII_CUT','NSGAII_CUT','UNIFORM_CUT'; ...
        'FINAL_vs_UNIFORM_CUT','UNIFORM_CUT','FINAL'; ...
        'FINAL_vs_NSGAII_CUT','NSGAII_CUT','FINAL'};

    rows = {};
    rn = 0;

    for i = 1:numel(instances)
        inst = instances(i);

        for c = 1:size(contrasts,1)
            label = contrasts{c,1};
            Aname = contrasts{c,2};
            Bname = contrasts{c,3};

            A = M(string(M.Instance)==inst & strcmp(M.Method,Aname),:);
            B = M(string(M.Instance)==inst & strcmp(M.Method,Bname),:);

            [~,oa] = sort(A.Run);
            [~,ob] = sort(B.Run);
            A = A(oa,:);
            B = B(ob,:);

            dHV = B.HV-A.HV;
            dIGD = A.IGD-B.IGD;
            dTEC = A.MinTEC-B.MinTEC;

            rn = rn+1;

            rows(rn,:) = { ...
                char(inst),label,Aname,Bname,height(A), ...
                mean(dHV),median(dHV),sum(dHV>1e-12), ...
                100*mean(dHV./max(abs(A.HV),eps)), ...
                mean(dIGD),median(dIGD),sum(dIGD>1e-12), ...
                100*mean(dIGD./max(abs(A.IGD),eps)), ...
                mean(dTEC),median(dTEC),sum(dTEC>1e-12), ...
                100*mean(dTEC./max(abs(A.MinTEC),eps))};
        end
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Contrast','MethodA','MethodB','Runs', ...
        'MeanHVAdvantageB','MedianHVAdvantageB','HVWinsB', ...
        'MeanRelativeHVAdvantagePct', ...
        'MeanIGDAdvantageB','MedianIGDAdvantageB','IGDWinsB', ...
        'MeanRelativeIGDAdvantagePct', ...
        'MeanMinTECAdvantageB','MedianMinTECAdvantageB','MinTECWinsB', ...
        'MeanRelativeMinTECAdvantagePct'});
end

function T = paired_statistics(M,cfg)
    instances = unique(string(M.Instance),'stable');

    contrasts = { ...
        'UNIFORM_vs_NSGAII','NSGAII','UNIFORM'; ...
        'NSGAII_CUT_vs_NSGAII','NSGAII','NSGAII_CUT'; ...
        'UNIFORM_CUT_vs_NSGAII_CUT','NSGAII_CUT','UNIFORM_CUT'; ...
        'FINAL_vs_UNIFORM_CUT','UNIFORM_CUT','FINAL'; ...
        'FINAL_vs_NSGAII_CUT','NSGAII_CUT','FINAL'};

    rows = {};
    rn = 0;
    primary = struct();

    for c = 1:size(contrasts,1)
        label = contrasts{c,1};
        field = matlab.lang.makeValidName(label);
        primary.(field).p = [];
        primary.(field).rows = [];

        for i = 1:numel(instances)
            inst = instances(i);

            A = M(string(M.Instance)==inst & ...
                  strcmp(M.Method,contrasts{c,2}),:);
            B = M(string(M.Instance)==inst & ...
                  strcmp(M.Method,contrasts{c,3}),:);

            [~,oa] = sort(A.Run);
            [~,ob] = sort(B.Run);
            A = A(oa,:);
            B = B(ob,:);

            metrics = { ...
                'HV',B.HV-A.HV; ...
                'IGD',A.IGD-B.IGD; ...
                'MinTEC',A.MinTEC-B.MinTEC};

            for q = 1:size(metrics,1)
                metric = metrics{q,1};
                improvement = metrics{q,2};

                W = exact_signed_rank_dp(improvement);

                rn = rn+1;

                rows(rn,:) = { ...
                    char(inst),label,metric,height(improvement), ...
                    mean(improvement),median(improvement), ...
                    sum(improvement>1e-12), ...
                    W.wPlus,W.wMinus,W.rankBiserial, ...
                    W.pTwoSided,NaN};

                if any(strcmp(cfg.statistics.primaryContrasts,label)) && ...
                   any(strcmp(cfg.statistics.primaryMetrics,metric))
                    primary.(field).p(end+1,1) = ...
                        W.pTwoSided; %#ok<AGROW>
                    primary.(field).rows(end+1,1) = rn; %#ok<AGROW>
                end
            end
        end
    end

    fields = fieldnames(primary);

    for i = 1:numel(fields)
        f = fields{i};

        if isempty(primary.(f).p)
            continue;
        end

        adj = holm_adjust(primary.(f).p);

        for j = 1:numel(adj)
            rows{primary.(f).rows(j),12} = adj(j);
        end
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Contrast','Metric','Runs', ...
        'MeanImprovement','MedianImprovement','ImprovedRuns', ...
        'WPlus','WMinus','RankBiserial','ExactP_TwoSided', ...
        'HolmAdjustedP_PrimaryFamily'});
end

function T = win_tie_loss_instances(D)
    contrasts = unique(string(D.Contrast),'stable');

    rows = {};
    rn = 0;

    for c = 1:numel(contrasts)
        X = D(string(D.Contrast)==contrasts(c),:);

        fields = { ...
            'HV','MeanHVAdvantageB'; ...
            'IGD','MeanIGDAdvantageB'; ...
            'MinTEC','MeanMinTECAdvantageB'};

        for q = 1:size(fields,1)
            v = X.(fields{q,2});

            wins = sum(v>1e-12);
            losses = sum(v<-1e-12);
            ties = numel(v)-wins-losses;

            rn = rn+1;

            rows(rn,:) = { ...
                char(contrasts(c)),fields{q,1}, ...
                wins,ties,losses};
        end
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Contrast','Metric','Wins','Ties','Losses'});
end

function T = summarize_runtime(R)
    instances = unique(string(R.Instance),'stable');
    rows = cell(numel(instances),9);

    for i = 1:numel(instances)
        X = R(string(R.Instance)==instances(i),:);

        rows(i,:) = { ...
            char(instances(i)),height(X), ...
            mean(X.NSGAIIStage1_s), ...
            mean(X.NSGAIICUT_s), ...
            mean(X.UniformStage1_s), ...
            mean(X.UniformCUT_s), ...
            mean(X.FINALRoute_s), ...
            mean(X.NSGAIISelectedPoints), ...
            mean(X.UniformSelectedPoints)};
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Runs', ...
        'MeanNSGAIIStage1_s','MeanNSGAIICUT_s', ...
        'MeanUniformStage1_s','MeanUniformCUT_s', ...
        'MeanFINALRoute_s', ...
        'MeanNSGAIISelectedPoints','MeanUniformSelectedPoints'});
end

function T = summarize_cut(C)
    instances = unique(string(C.Instance),'stable');
    rows = cell(numel(instances)+1,8);

    for i = 1:numel(instances)
        X = C(string(C.Instance)==instances(i),:);
        rows(i,:) = one_row(char(instances(i)),X);
    end

    rows(end,:) = one_row('ALL',C);

    T = cell2table(rows,'VariableNames',{ ...
        'Group','Schedules','MeanTECReductionPct', ...
        'StrictReductionCount','MeanCUTWall_s', ...
        'MeanCUTNodes','MeanCUTEdges','CertificateFailures'});
end

function row = one_row(label,X)
    row = { ...
        label,height(X), ...
        mean(X.TECReductionPct), ...
        sum(X.TECReduction>1e-6), ...
        mean(X.CUTWall_s), ...
        mean(X.CUTNodes), ...
        mean(X.CUTEdges), ...
        sum(~X.CertificateValid)};
end

function make_relative_figure(D,contrast,figRoot)
    X = D(strcmp(D.Contrast,contrast),:);

    Y = [ ...
        X.MeanRelativeHVAdvantagePct, ...
        X.MeanRelativeIGDAdvantagePct];

    f = figure('Visible','off','Position',[100 100 1200 520]);
    bar(Y);
    xticks(1:height(X));
    xticklabels(X.Instance);
    xtickangle(45);
    ylabel('Mean relative advantage (%)');
    legend({'HV higher','IGD lower'},'Location','best');
    title(strrep(contrast,'_',' '));
    grid on;

    exportgraphics(f, ...
        fullfile(figRoot,[lower(contrast) '_relative.png']), ...
        'Resolution',220);

    exportgraphics(f, ...
        fullfile(figRoot,[lower(contrast) '_relative.pdf']));

    close(f);
end

function make_runtime_figure(R,figRoot)
    Y = [R.MeanNSGAIIStage1_s,R.MeanUniformStage1_s];

    f = figure('Visible','off','Position',[100 100 1150 500]);
    bar(Y);
    xticks(1:height(R));
    xticklabels(R.Instance);
    xtickangle(45);
    ylabel('Mean Stage-I wall time (s)');
    legend({'NSGA-II','Uniform MA'},'Location','best');
    title('Stage-I search runtime');
    grid on;

    exportgraphics(f, ...
        fullfile(figRoot,'stage1_runtime.png'), ...
        'Resolution',220);

    exportgraphics(f, ...
        fullfile(figRoot,'stage1_runtime.pdf'));

    close(f);
end

function ensure_dir(p)
    if ~isfolder(p)
        mkdir(p);
    end
end
