function out = run_nsga2_checkpoint( ...
    instanceName,runIndex,seed,cfg,options)
%RUN_NSGA2_CHECKPOINT Pure NSGA-II baseline under the same representation.
%
% Same as the frozen Stage-I infrastructure except:
%   - NO problem-specific local search;
%   - NO learning;
%   - exactly the same chromosome / decoder / initialization / variation;
%   - same population size and exact NFE budget.
%
% This makes NSGA-II a clean generic search baseline.

    instanceFile = fullfile(cfg.paths.dhfjspInstanceDir,[instanceName '.txt']);
    inst = load_dhfjsp_instance(instanceFile,cfg);

    N = cfg.evolution.populationSize;

    X = get_shared_initial_population( ...
        inst,instanceName,runIndex,seed,cfg);

    tRun = tic;

    pop = evaluate_population(X,inst,cfg);
    nfe = pop.nfe;

    pop = assign_rank_and_crowding(pop);
    archive = update_external_archive([],pop,cfg);

    generation = 0;

    history.generation = 0;
    history.nfe = nfe;
    history.archiveSize = size(archive.objectives,1);

    while nfe < options.maxNFE
        rng(seed+100000+generation,'twister');

        remaining = options.maxNFE-nfe;
        nOffspring = min(N,remaining);

        if nOffspring<=0
            break;
        end

        offspringX = make_offspring(pop,inst,cfg,nOffspring);
        offspring = evaluate_population(offspringX,inst,cfg);

        nfe = nfe+offspring.nfe;

        archive = update_external_archive(archive,offspring,cfg);

        merged = merge_populations(pop,offspring);
        pop = environmental_selection(merged,N);
        pop = assign_rank_and_crowding(pop);

        generation = generation+1;

        history.generation(end+1,1) = generation; %#ok<AGROW>
        history.nfe(end+1,1) = nfe; %#ok<AGROW>
        history.archiveSize(end+1,1) = ...
            size(archive.objectives,1); %#ok<AGROW>
    end

    out.instanceName = instanceName;
    out.runIndex = runIndex;
    out.seed = seed;

    out.archive.chromosomes = archive.chromosomes;
    out.archive.objectives = archive.objectives;

    out.finalPopulationObjectives = pop.objectives;

    out.nfe = nfe;
    out.generations = generation;
    out.elapsedSeconds = toc(tRun);
    out.history = history;
    out.options = options;
end
