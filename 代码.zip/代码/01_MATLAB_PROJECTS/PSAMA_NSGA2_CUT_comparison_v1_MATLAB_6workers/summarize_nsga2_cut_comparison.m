function outputs = summarize_nsga2_cut_comparison()
%SUMMARIZE_NSGA2_CUT_COMPARISON Show main algorithm-level evidence.

    setup_project();

    cfg = make_shared_config();
    expCfg = make_nsga2_cut_comparison_experiment();

    root = fullfile(cfg.project.root,'results',expCfg.tag,'tables');

    outputs.summary = readtable( ...
        fullfile(root,'summary_by_instance_method.csv'));

    outputs.deltas = readtable( ...
        fullfile(root,'paired_deltas.csv'));

    outputs.statistics = readtable( ...
        fullfile(root,'paired_statistics.csv'));

    outputs.winTieLoss = readtable( ...
        fullfile(root,'win_tie_loss_by_instance.csv'));

    outputs.runtime = readtable( ...
        fullfile(root,'runtime_summary.csv'));

    fprintf('\n=== Stage-I search: Uniform vs NSGA-II ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'UNIFORM_vs_NSGAII'),:));

    fprintf('\n=== Fair postprocessing: Uniform+CUT vs NSGA-II+CUT ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'UNIFORM_CUT_vs_NSGAII_CUT'),:));

    fprintf('\n=== Final method vs generic strong baseline NSGA-II+CUT ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'FINAL_vs_NSGAII_CUT'),:));

    fprintf('\n=== What CUT adds to NSGA-II ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'NSGAII_CUT_vs_NSGAII'),:));

    fprintf('\n=== Win / tie / loss across instances ===\n');
    disp(outputs.winTieLoss);

    fprintf('\n=== Runtime ===\n');
    disp(outputs.runtime);
end
