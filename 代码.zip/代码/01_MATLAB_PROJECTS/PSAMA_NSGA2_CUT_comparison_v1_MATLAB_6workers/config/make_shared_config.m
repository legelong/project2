function cfg = make_shared_config(instanceDir)
%MAKE_SHARED_CONFIG Formal 20-instance experiment for CUT->CBJ1->CUT.
%
% FINAL METHOD UNDER TEST
% -----------------------
% Stage I:
%   frozen UNIFORM_JOINT memetic search, 10000 NFE.
%
% Stage II:
%   terminal phenotype refinement on <=8 diverse Stage-I archive schedules:
%
%       BASE
%         -> CUT
%         -> one exact best CBJ1 speed+timing block move
%         -> CUT
%
% where:
%   CUT  = global fixed-speed exact timing optimization under source deadline;
%   CBJ1 = one safe-bound-guided exact best local speed+timing block move in:
%            all L5 + only non-embeddable L3.
%
% The first CUT removes all timing slack for the original speed vector v0.
% The CBJ1 step changes a local discrete speed vector.
% The final CUT returns the global fixed-speed timing optimum for the new speed
% vector v1.
%
% Thus the core scientific comparison:
%
%       FINAL vs CUT
%
% asks whether speed changes create value beyond the strong global fixed-speed
% timing optimum.
%
% COMPUTATION FAIRNESS
% --------------------
% CONT_FINAL continues the SAME Stage-I population/archive checkpoint for the
% actual same-run wall time consumed by the FINAL terminal branch. Continuation
% stops only at a complete generation boundary; overshoot is recorded.
%
% FORMAL MAIN METHODS
% -------------------
% BASE
% CUT
% CUT_CBJ1        (intermediate ablation; no extra compute)
% FINAL           (= CUT_CBJ1_CUT)
% CONT_FINAL
%
% The simpler order BASE->CBJ1->CUT was compared in the preceding bridge
% development study. It is not rerun here because the bridge already showed
% CUT->CBJ1->CUT to be the stronger average route, while this formal experiment
% focuses computation on the frozen final architecture.
%
% EXACTNESS SCOPE
% ---------------
% CUT:
%   global optimum of the fixed-speed fixed-order timing subproblem under the
%   common benchmark grid, fixed factory/machine/order and source deadline.
%
% CBJ1:
%   exact best improvement only within the defined reduced contiguous-block
%   speed+timing neighborhood with the outside schedule fixed.
%
% Neither is a globally exact solver for the full DHFJSP.

    thisFile = mfilename('fullpath');
    projectRoot = fileparts(fileparts(thisFile));

    if nargin < 1 || isempty(instanceDir)
        instanceDir = fullfile(projectRoot,'datasets','DHFJSP');
    end

    cfg.project.name = 'PSA-MA';
    cfg.project.algorithmVersion = 'PSAMA_NSGA2_CUT_Comparison_v1';
    cfg.project.step = 'nsga2-cut-comparison';
    cfg.project.schemaVersion = 'PSAMA-SCHEMA-NSGA2-CUT-COMPARISON-1.0';
    cfg.project.root = projectRoot;

    cfg.paths.dhfjspInstanceDir = instanceDir;

    % ---------------- Frozen physical / TOU model ----------------
    cfg.problem.speedLevels = [1,2,3,4,5];
    cfg.problem.processingPowerCoefficient = 4.0;
    cfg.problem.idlePower = 1.0;
    cfg.problem.durationRounding = 'floor';
    cfg.problem.minDuration = 1;

    cfg.tariff.period = 24.0;
    cfg.tariff.flatPrice = 0.52;
    cfg.tariff.valleyMultiplier = 0.30;
    cfg.tariff.peakMultiplier = 1.70;
    cfg.tariff.valleyIntervals = [0,6;11,14];
    cfg.tariff.peakIntervals = [16,23];
    cfg.tariff.valleyPrice = cfg.tariff.flatPrice * cfg.tariff.valleyMultiplier;
    cfg.tariff.peakPrice = cfg.tariff.flatPrice * cfg.tariff.peakMultiplier;
    cfg.tariff.idleCostPolicy = 'BETWEEN_CONSECUTIVE_OPERATIONS_ONLY';

    cfg.decoder.method = 'GT_ACTIVE_OS_PRIORITY';
    cfg.decoder.tolerance = 1e-9;
    cfg.decoder.validateChromosome = true;
    cfg.decoder.validateSchedule = true;

    % ---------------- Frozen Stage-I Uniform MA ----------------
    cfg.initialization.mode = 'HYBRID_SHARED';
    cfg.initialization.heuristicFraction = 0.70;
    cfg.initialization.lowSpeedFraction = 0.60;

    cfg.evolution.populationSize = 100;
    cfg.evolution.crossoverProbability = 0.80;
    cfg.evolution.segmentMutationProbability = 0.15;
    cfg.evolution.tournamentSize = 2;
    cfg.evolution.archiveMaxSize = 500;
    cfg.evolution.cacheDecoded = true;

    cfg.experiment.baseSeed = 20262201;
    cfg.experiment.localSearchRatio = 0.20;
    cfg.experiment.budgetMode = 'NFE';

    cfg.features.criticalTolerance = 1e-8;
    cfg.features.loadPressureEpsilon = 1e-12;
    cfg.features.contextDimension = 8;

    cfg.recovery.f2TopFraction = 0.30;
    cfg.recovery.minimumComponent = 1e-12;

    cfg.operators.names = { ...
        'A1_LowLoadMachineReassignment', ...
        'A2_CriticalSpeedUp', ...
        'A3_CriticalPathSwap', ...
        'A4_N6CriticalBlockInsertion', ...
        'A5_NoncriticalSlowDown', ...
        'A6_ShortestTimeMachineReassignment'};
    cfg.operators.count = numel(cfg.operators.names);
    cfg.operators.maxRandomTrials = 30;

    cfg.setReward.referencePoint = [1.1,1.1];
    cfg.setReward.gapWeight = 0.10;
    cfg.setReward.includeBoundaryGaps = true;

    % Compatibility only; Uniform Joint does not use learned scores.
    cfg.learning.method = 'LINUCB_PER_OPERATOR';
    cfg.learning.contextDimension = cfg.features.contextDimension;
    cfg.learning.useIntercept = true;
    cfg.learning.featureDimension = cfg.learning.contextDimension + 1;
    cfg.learning.ridgeLambda = 1.0;
    cfg.learning.alpha = 0.20;
    cfg.learning.rewardClip = [];
    cfg.learning.randomTieBreak = true;
    cfg.learning.maxOneOperatorPerSolution = true;
    cfg.learning.fillLocalBudget = true;
    cfg.learning.maxPairsPerSource = cfg.operators.count;

    cfg.contextAblation.zeroContext = zeros(1,cfg.features.contextDimension);

    cfg.uniform.score = 0.0;
    cfg.uniform.predictedMean = NaN;
    cfg.uniform.uncertainty = NaN;
    cfg.uniform.useRandomTieBreak = true;

    cfg.paretoDiagnosis.sparseQuantile = 0.75;
    cfg.paretoDiagnosis.denseQuantile = 0.25;
    cfg.paretoDiagnosis.kneeQuantile = 0.85;

    cfg.logging.enabled = true;
    cfg.logging.snapshotNFE = [1000,2500,5000,7500,10000];
    cfg.logging.saveArchiveSnapshots = true;
    cfg.logging.compactNumeric = true;

    % Completed formal Uniform/CUT/FINAL results are embedded in this project
    % as a frozen source. Only the missing NSGA-II side is newly computed.
    cfg.repository.previousProject = '';
    cfg.repository.sourceFormalTag = 'formal20_cut_cbj1_cut_v1';

    % ---------------- Reduced exact block family ----------------
    cfg.cb.blockLengths = [3,5];
    cfg.cb.improvementTolerance = 1e-6;
    cfg.cb.maxAcceptedMoves = 1;
    cfg.cb.requireExact = true;

    cfg.block.scoreSlackWeight = 0.45;
    cfg.block.scoreTariffEventWeight = 0.35;
    cfg.block.scoreExpensiveExposureWeight = 0.20;
    cfg.block.timeGrid = 1;
    cfg.block.maxSolveSeconds = 300;
    cfg.block.relativeGapTolerance = 0;
    cfg.block.absoluteGapTolerance = 1e-8;
    cfg.block.objectiveTolerance = 1e-6;
    cfg.block.maxBinaryVariables = 250000;

    % ---------------- MATLAB CUT ----------------
    cfg.cut.priceScale = 1000;
    cfg.cut.requireMaxflow = true;
    cfg.cut.verifyDirectCost = true;
    cfg.cut.verifyCutCertificate = true;

    % Independent global timing MILP used only in self-check.
    cfg.cut.milpMaxSolveSeconds = 180;
    cfg.cut.milpRelativeGapTolerance = 0;
    cfg.cut.milpAbsoluteGapTolerance = 1e-8;

    % ---------------- Final Stage-II ----------------
    cfg.refinement.maxRepresentativePoints = 8;
    cfg.refinement.maxRounds = 1;
    cfg.refinement.hvReferencePoint = [1.1,1.1];

    % ---------------- Fairness ----------------
    cfg.fairness.continuationGenerationCap = 500;
    cfg.fairness.minimumTimeBudgetSeconds = 0.01;
    cfg.fairness.parallelWorkers = 6;

    % ---------------- Formal statistics ----------------
    cfg.statistics.alpha = 0.05;
    cfg.statistics.primaryMetrics = {'HV','IGD'};
    cfg.statistics.primaryContrasts = { ...
        'UNIFORM_CUT_vs_NSGA2_CUT', ...
        'FINAL_vs_NSGA2_CUT'};

    cfg.baseline.parallelWorkers = 6;
    cfg.baseline.maxRepresentativePoints = 8;
end
