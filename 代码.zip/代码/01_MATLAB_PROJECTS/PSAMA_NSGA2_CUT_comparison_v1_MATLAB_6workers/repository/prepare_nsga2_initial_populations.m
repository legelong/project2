function prepare_nsga2_initial_populations(cfg,expCfg)
%PREPARE_NSGA2_INITIAL_POPULATIONS Same deterministic initializer/seeds.
%
% The formal Uniform runs used the same initialize_population implementation,
% population size, initialization parameters and seeds 20262201-20262220.
% Regenerating through get_shared_initial_population therefore creates the
% paired NSGA-II starting populations without rerunning Uniform.

    fprintf('[Repository] Preparing paired NSGA-II initial populations...\n');

    for ii = 1:numel(expCfg.instances)
        d = fullfile(cfg.project.root,'initial_populations', ...
            expCfg.instances{ii});
        if ~isfolder(d), mkdir(d); end
    end

    parfor ii = 1:numel(expCfg.instances)
        name = expCfg.instances{ii};

        inst = load_dhfjsp_instance( ...
            fullfile(cfg.paths.dhfjspInstanceDir,[name '.txt']),cfg);

        for rr = 1:expCfg.numRuns
            seed = cfg.experiment.baseSeed+rr-1;

            X = get_shared_initial_population( ...
                inst,name,rr,seed,cfg);

            assert(size(X,1)==cfg.evolution.populationSize);
            assert(size(X,2)==inst.encoding.totalLength);
        end

        fprintf('[Repository] NSGA-II initial populations ready: %s\n',name);
    end
end
