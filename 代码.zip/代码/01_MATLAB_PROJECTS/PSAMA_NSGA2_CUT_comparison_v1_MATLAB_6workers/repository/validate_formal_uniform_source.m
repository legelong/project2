function report = validate_formal_uniform_source(cfg,expCfg)
%VALIDATE_FORMAL_UNIFORM_SOURCE Validate 400 frozen formal source runs.

    root = fullfile(cfg.project.root,'source_results', ...
        cfg.repository.sourceFormalTag,'raw');

    expectedHash = '';
    checked = 0;

    fprintf('[Source audit] Validating formal Uniform/CUT/FINAL source...\n');

    for ii = 1:numel(expCfg.instances)
        inst = expCfg.instances{ii};

        for rr = 1:expCfg.numRuns
            file = fullfile(root,inst,sprintf('run_%02d.mat',rr));

            if ~isfile(file)
                error('PSAMA:NSGA2SourceMissing', ...
                    'Missing formal source raw: %s',file);
            end

            S = load(file,'record');
            R = S.record;

            expectedSeed = cfg.experiment.baseSeed+rr-1;

            ok = isfield(R,'complete') && R.complete && ...
                 strcmp(R.summary.instance,inst) && ...
                 R.summary.run==rr && ...
                 R.summary.seed==expectedSeed && ...
                 R.summary.stage1NFE==expCfg.stage1NFE && ...
                 isfield(R.fronts,'BASE') && ...
                 isfield(R.fronts,'CUT') && ...
                 isfield(R.fronts,'FINAL');

            if ~ok
                error('PSAMA:NSGA2SourceMismatch', ...
                    'Formal source compatibility check failed: %s',file);
            end

            if isempty(expectedHash)
                expectedHash = R.summary.configHash;
            elseif ~strcmp(expectedHash,R.summary.configHash)
                error('PSAMA:NSGA2SourceHash', ...
                    'Mixed formal-source config hashes detected.');
            end

            checked = checked+1;
        end
    end

    report.checked = checked;
    report.sourceConfigHash = expectedHash;

    fprintf('[PASS] Formal source audit: %d runs.\n',checked);
end
