function [hash,signature] = compute_nsga2_cut_hash(cfg,expCfg)
%COMPUTE_NSGA2_CUT_HASH Stable protocol fingerprint.

    S.algorithmVersion = cfg.project.algorithmVersion;
    S.instances = expCfg.instances;
    S.numRuns = expCfg.numRuns;
    S.stage1NFE = expCfg.stage1NFE;
    S.baseSeed = cfg.experiment.baseSeed;

    S.populationSize = cfg.evolution.populationSize;
    S.crossoverProbability = cfg.evolution.crossoverProbability;
    S.segmentMutationProbability = ...
        cfg.evolution.segmentMutationProbability;

    S.initializationMode = cfg.initialization.mode;
    S.heuristicFraction = cfg.initialization.heuristicFraction;
    S.lowSpeedFraction = cfg.initialization.lowSpeedFraction;

    S.maxRepresentativePoints = cfg.baseline.maxRepresentativePoints;

    S.speedLevels = cfg.problem.speedLevels;
    S.processingPowerCoefficient = cfg.problem.processingPowerCoefficient;
    S.idlePower = cfg.problem.idlePower;

    S.tariff = [ ...
        cfg.tariff.flatPrice, ...
        cfg.tariff.valleyPrice, ...
        cfg.tariff.peakPrice];

    signature = jsonencode(S);

    try
        md = javaMethod('getInstance','java.security.MessageDigest','MD5');
        md.update(uint8(signature));
        bytes = uint8(md.digest());
        hash = lower(reshape(dec2hex(bytes,2).',1,[]));
    catch
        u = double(uint8(signature));
        weights = mod((1:numel(u))*1315423911,2147483647);
        checksum = mod(sum(mod(u.*weights,2147483647)),2147483647);
        hash = sprintf('fallback_%010u',uint32(checksum));
    end
end
