function warm_nsga2_cut_worker(cfg)
%WARM_NSGA2_CUT_WORKER One-time process-local CUT/JIT warm-up.

    persistent warmed

    if ~isempty(warmed) && warmed
        return;
    end

    assert_digraph_maxflow_available();

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir,'10J2F.txt'),cfg);

    chromosome = make_canonical_10J2F_chromosome(inst);
    [~,decoded] = evaluate_solution(chromosome,inst,cfg);

    solve_cut_retime(decoded,inst,cfg,decoded.makespan);

    warmed = true;
end
