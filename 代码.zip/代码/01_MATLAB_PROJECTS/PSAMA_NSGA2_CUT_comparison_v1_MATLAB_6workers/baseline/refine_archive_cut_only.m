function branch = refine_archive_cut_only(base,selected,inst,cfg)
%REFINE_ARCHIVE_CUT_ONLY Same terminal CUT treatment for NSGA-II.
%
% At most eight diverse final archive schedules are selected, exactly matching
% the representative-count policy used by the formal Uniform+CUT baseline.
%
% Each selected schedule:
%   - is decoded from its chromosome;
%   - keeps its own decoded Cmax as the deadline;
%   - receives global fixed-speed exact CUT retiming.
%
% Final front = original NSGA-II archive front union CUT-refined points.

    K = numel(selected);

    refined = nan(K,2);
    traces = cell(K,1);

    baseFront = nondominated_objectives(base.archive.objectives);

    tBranch = tic;

    for k = 1:K
        archiveIdx = selected(k);
        chromosome = base.archive.chromosomes(archiveIdx,:);

        [obj,decoded] = evaluate_solution(chromosome,inst,cfg);

        if max(abs(obj-base.archive.objectives(archiveIdx,:)))>1e-8
            error('PSAMA:NSGA2ArchiveDecodeMismatch', ...
                'NSGA-II archive chromosome/objective mismatch.');
        end

        deadline = decoded.makespan;

        t = tic;
        cut = solve_cut_retime(decoded,inst,cfg,deadline);
        cutWall = toc(t);

        if cut.totalTEC > decoded.cost.total+cfg.block.objectiveTolerance
            error('PSAMA:NSGA2CUTWorse', ...
                'CUT became worse than the source NSGA-II schedule.');
        end

        refined(k,:) = cut.decoded.objectives;

        tr.archiveIndex = archiveIdx;
        tr.sourceObjectives = obj;
        tr.cutObjectives = cut.decoded.objectives;

        tr.tecReduction = obj(2)-cut.totalTEC;
        tr.tecReductionPct = ...
            100*tr.tecReduction/max(obj(2),eps);

        tr.cutWallSeconds = cutWall;
        tr.cutNodes = cut.nodes;
        tr.cutEdges = cut.edges;
        tr.certificateValid = cut.certificateValid;

        traces{k} = tr;
    end

    branch.elapsedSeconds = toc(tBranch);
    branch.refinedObjectives = refined;
    branch.traces = traces;

    branch.front = nondominated_objectives([baseFront;refined]);

    branch.totalCUTSeconds = 0;
    branch.strictReductionPoints = 0;

    for k = 1:K
        tr = traces{k};
        branch.totalCUTSeconds = ...
            branch.totalCUTSeconds+tr.cutWallSeconds;

        branch.strictReductionPoints = ...
            branch.strictReductionPoints+ ...
            double(tr.tecReduction>cfg.cb.improvementTolerance);
    end
end
