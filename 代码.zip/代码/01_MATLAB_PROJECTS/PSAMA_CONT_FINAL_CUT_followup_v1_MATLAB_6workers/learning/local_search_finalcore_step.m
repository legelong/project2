function [lsPop,archive,model,diag,eventLog,nfeUsed] = ...
    local_search_finalcore_step( ...
        sourcePop,archive,inst,cfg,model,budget,variant, ...
        generation,nfeBeforeBatch)
%LOCAL_SEARCH_FINALCORE_STEP Clean Joint/Serial single-factor comparison.
%
% Joint and Serial use exactly the SAME:
%   F1 pool
%   context
%   operator proposals
%   feasible unique child pairs
%   LinUCB pair scores
%   Parent reward
%   local-search NFE target
%
% Difference only:
%   JOINT  -> pairs compete globally.
%   SERIAL -> source ranked by mean pair score, then best operators within source.

    eventLog = empty_finalcore_event_log();

    if budget <= 0
        lsPop = empty_population_like(inst);
        diag = empty_diag(cfg);
        nfeUsed = 0;
        return;
    end

    if isempty(sourcePop.fronts)
        sourcePop = assign_rank_and_crowding(sourcePop);
    end

    t = tic;
    pool = build_search_source_pool_variant(sourcePop,inst,cfg,variant);
    poolTime = toc(t);

    t = tic;
    [pairs,profile] = build_joint_pairs_profiled( ...
        sourcePop,pool,archive,inst,cfg,model);
    pairBuildTime = toc(t);

    [pairs,dedup] = deduplicate_pairs_by_child(pairs);

    t = tic;
    switch upper(variant.allocatorMode)
        case 'JOINT'
            selected = select_joint_pairs_fair(pairs,budget,cfg);

        case 'SERIAL'
            selected = select_serial_pairs_same_scores(pairs,budget,cfg);

        otherwise
            error('PSAMA:AllocatorMode','Unknown allocator mode.');
    end
    selectionTime = toc(t);

    [lsPop,archive,model,execSummary,eventLog,nfeUsed] = ...
        execute_finalcore_pairs( ...
            selected,archive,inst,cfg,model,generation,nfeBeforeBatch);

    diag.requestedBudget = budget;
    diag.actualBudget = nfeUsed;
    diag.budgetShortfall = max(0,budget-nfeUsed);
    diag.poolSize = numel(pool.indices);
    diag.uniquePairs = numel(pairs);
    diag.duplicatesRemoved = dedup.duplicatesRemoved;

    if isempty(selected)
        diag.uniqueSelectedSources = 0;
        diag.maxPairsPerSource = 0;
    else
        s = [selected.sourceIndex]';
        u = unique(s);
        counts = zeros(numel(u),1);
        for i = 1:numel(u)
            counts(i) = sum(s==u(i));
        end
        diag.uniqueSelectedSources = numel(u);
        diag.maxPairsPerSource = max(counts);
    end

    diag.selectedByOperator = execSummary.selectedByOperator;
    diag.positiveRewardByOperator = ...
        execSummary.positiveRewardByOperator;
    diag.rewardByOperator = execSummary.rewardByOperator;
    diag.archiveChanges = execSummary.archiveChanges;

    diag.poolBuildTime = poolTime;
    diag.pairBuildTime = pairBuildTime;
    diag.contextTime = profile.contextTime;
    diag.operatorProposalTime = profile.operatorProposalTime;
    diag.scoringTime = profile.scoringTime;
    diag.selectionTime = selectionTime;

    if numel(pairs) >= budget && nfeUsed < budget
        error('PSAMA:BudgetFillFailure', ...
            'Enough unique pairs existed but LS budget was not filled.');
    end
end

function d = empty_diag(cfg)
    K = cfg.operators.count;

    d.requestedBudget = 0;
    d.actualBudget = 0;
    d.budgetShortfall = 0;
    d.poolSize = 0;
    d.uniquePairs = 0;
    d.duplicatesRemoved = 0;
    d.uniqueSelectedSources = 0;
    d.maxPairsPerSource = 0;

    d.selectedByOperator = zeros(K,1);
    d.positiveRewardByOperator = zeros(K,1);
    d.rewardByOperator = zeros(K,1);
    d.archiveChanges = 0;

    d.poolBuildTime = 0;
    d.pairBuildTime = 0;
    d.contextTime = 0;
    d.operatorProposalTime = 0;
    d.scoringTime = 0;
    d.selectionTime = 0;
end
