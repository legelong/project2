function [uniquePairs,info] = deduplicate_pairs_by_child(pairs)
%DEDUPLICATE_PAIRS_BY_CHILD Prevent duplicate-child evaluations.
%
% If several source/operator pairs propose the exact same chromosome, keep the
% representative with the highest current pair score. Both Joint and Serial use
% this SAME deduplicated candidate set.

    info.before = numel(pairs);
    info.after = numel(pairs);
    info.duplicatesRemoved = 0;

    if isempty(pairs)
        uniquePairs = pairs;
        return;
    end

    X = vertcat(pairs.child);
    score = [pairs.score]';
    source = [pairs.sourceIndex]';
    op = [pairs.operatorId]';

    % Best-scored representative appears first within a duplicate group.
    key = [-score,source,op];
    [~,order] = sortrows(key,[1 2 3]);

    Xs = X(order,:);
    [~,firstIdx] = unique(Xs,'rows','stable');
    keep = order(firstIdx);

    % Put retained pairs back into a stable deterministic score order.
    keptScore = [pairs(keep).score]';
    keptSource = [pairs(keep).sourceIndex]';
    keptOp = [pairs(keep).operatorId]';
    key2 = [-keptScore,keptSource,keptOp];
    [~,ord2] = sortrows(key2,[1 2 3]);

    uniquePairs = pairs(keep(ord2));

    info.after = numel(uniquePairs);
    info.duplicatesRemoved = info.before-info.after;
end
