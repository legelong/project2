function [pairs,profile] = build_joint_pairs_profiled( ...
    pop,pool,archive,inst,cfg,model)
%BUILD_JOINT_PAIRS_PROFILED Build feasible pairs and measure overhead.
%
% Invalid operators (meta.changed=false) do NOT enter the candidate set.
% No objective evaluation occurs here, so this consumes zero NFE.

    if isempty(archive) || isempty(archive.objectives)
        error('PSAMA:EmptyArchive', ...
            'Pair allocation requires a nonempty archive.');
    end

    referenceFront = archive.objectives;

    template = struct( ...
        'sourceIndex',NaN, ...
        'sourceType','', ...
        'recoveryScore',NaN, ...
        'sourceObjective',[], ...
        'operatorId',NaN, ...
        'operatorName','', ...
        'context',[], ...
        'score',NaN, ...
        'predictedMean',NaN, ...
        'uncertainty',NaN, ...
        'tieKey',NaN, ...
        'child',[], ...
        'operatorMeta',[]);

    pairs = repmat(template,0,1);
    catalog = operator_catalog(cfg);

    profile.contextTime = 0;
    profile.operatorProposalTime = 0;
    profile.scoringTime = 0;
    profile.sources = numel(pool.indices);
    profile.operatorAttempts = 0;
    profile.feasiblePairs = 0;

    for q = 1:numel(pool.indices)
        idx = pool.indices(q);

        if isempty(pop.decoded{idx})
            error('PSAMA:MissingDecodedCache', ...
                'Pair construction requires decoded schedules.');
        end

        decoded = pop.decoded{idx};
        objective = pop.objectives(idx,:);

        t = tic;
        [context,~,~] = build_context_vector( ...
            decoded,objective,referenceFront,inst,cfg);
        profile.contextTime = profile.contextTime + toc(t);

        for opId = 1:cfg.operators.count
            profile.operatorAttempts = profile.operatorAttempts+1;

            t = tic;
            [child,meta] = apply_operator( ...
                opId,pop.chromosomes(idx,:),decoded,inst,cfg);
            profile.operatorProposalTime = ...
                profile.operatorProposalTime + toc(t);

            if ~meta.changed
                continue;
            end

            t = tic;
            [score,mu,u] = linucb_score(model,opId,context,cfg);
            profile.scoringTime = profile.scoringTime + toc(t);

            item = template;
            item.sourceIndex = idx;
            item.sourceType = pool.sourceType{q};
            item.recoveryScore = pool.recoveryScore(q);
            item.sourceObjective = objective;
            item.operatorId = opId;
            item.operatorName = catalog(opId).name;
            item.context = context;
            item.score = score;
            item.predictedMean = mu;
            item.uncertainty = u;

            if cfg.learning.randomTieBreak
                item.tieKey = rand();
            else
                item.tieKey = opId;
            end

            item.child = child;
            item.operatorMeta = meta;

            pairs(end+1,1) = item; %#ok<AGROW>
        end
    end

    profile.feasiblePairs = numel(pairs);
end
