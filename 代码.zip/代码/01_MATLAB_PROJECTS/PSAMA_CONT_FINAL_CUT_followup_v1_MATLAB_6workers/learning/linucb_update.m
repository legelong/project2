function model = linucb_update(model,operatorId,context,reward,cfg)
%LINUCB_UPDATE Update one operator model using observed set-level reward.

    if ~isscalar(reward) || ~isfinite(reward)
        error('PSAMA:Reward','Reward must be one finite scalar.');
    end

    if ~isempty(cfg.learning.rewardClip)
        c = cfg.learning.rewardClip;
        reward = min(max(reward,-c),c);
    end

    x = augment_context(context,cfg);

    model.A{operatorId} = model.A{operatorId} + x*x';
    model.b{operatorId} = model.b{operatorId} + reward*x;
    model.theta{operatorId} = ...
        model.A{operatorId} \ model.b{operatorId};

    model.pullCount(operatorId) = model.pullCount(operatorId) + 1;
    model.rewardSum(operatorId) = model.rewardSum(operatorId) + reward;

    if reward > 0
        model.positiveRewardCount(operatorId) = ...
            model.positiveRewardCount(operatorId) + 1;
    end

    model.totalUpdates = model.totalUpdates + 1;
end
