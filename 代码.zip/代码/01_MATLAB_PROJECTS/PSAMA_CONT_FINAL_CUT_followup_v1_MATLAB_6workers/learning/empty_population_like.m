function pop = empty_population_like(inst)
%EMPTY_POPULATION_LIKE Empty common population struct.

    L = inst.encoding.totalLength;

    pop.chromosomes = zeros(0,L);
    pop.objectives = zeros(0,2);
    pop.decoded = cell(0,1);
    pop.rank = zeros(0,1);
    pop.crowding = zeros(0,1);
    pop.fronts = {};
    pop.nfe = 0;
end
