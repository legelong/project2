function selected = select_joint_pairs_fair(pairs,budget,cfg)
%SELECT_JOINT_PAIRS_FAIR Joint pair allocation with equal-budget filling.
%
% Round 1:
%   at most one pair per source.
%
% Remaining rounds:
%   choose highest-score unused pairs, allowing another operator from a source.
%
% Thus F1-only is not accidentally given less LS budget solely because F1 has
% fewer unique source solutions.

    if budget <= 0 || isempty(pairs)
        selected = pairs([]);
        return;
    end

    score = [pairs.score]';
    tie = [pairs.tieKey]';
    source = [pairs.sourceIndex]';
    op = [pairs.operatorId]';

    key = [-score,-tie,source,op];
    [~,order] = sortrows(key,[1 2 3 4]);

    selectedIdx = [];
    usedSource = [];

    % First diversity-preserving round.
    for kk = 1:numel(order)
        i = order(kk);

        if ismember(source(i),usedSource)
            continue;
        end

        selectedIdx(end+1) = i; %#ok<AGROW>
        usedSource(end+1) = source(i); %#ok<AGROW>

        if numel(selectedIdx) >= budget
            break;
        end
    end

    % Fill remaining budget with unused solution-operator pairs.
    if numel(selectedIdx) < budget && cfg.learning.fillLocalBudget
        for kk = 1:numel(order)
            i = order(kk);

            if ismember(i,selectedIdx)
                continue;
            end

            selectedIdx(end+1) = i; %#ok<AGROW>

            if numel(selectedIdx) >= budget
                break;
            end
        end
    end

    selected = pairs(selectedIdx);
end
