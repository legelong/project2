function x = augment_context(context,cfg)
%AUGMENT_CONTEXT Convert the frozen context to one regression feature column.

    context = context(:);

    if numel(context) ~= cfg.learning.contextDimension
        error('PSAMA:ContextDimension', ...
            'Context dimension is %d; expected %d.', ...
            numel(context),cfg.learning.contextDimension);
    end

    if any(~isfinite(context))
        error('PSAMA:ContextNonfinite','Context contains non-finite values.');
    end

    if cfg.learning.useIntercept
        x = [1; context];
    else
        x = context;
    end
end
