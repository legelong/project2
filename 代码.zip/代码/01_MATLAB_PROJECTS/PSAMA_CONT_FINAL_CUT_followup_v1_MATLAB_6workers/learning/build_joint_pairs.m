function pairs = build_joint_pairs(pop,pool,archive,inst,cfg,model)
%BUILD_JOINT_PAIRS Build feasible (solution,operator) candidates.
%
% Each source solution gets ONE frozen 8-D context relative to the current
% external Pareto archive. Each Step-5 operator is called once to propose a
% candidate child. No child objective is evaluated here.
%
% Therefore this function consumes zero additional NFE.

    if isempty(archive) || isempty(archive.objectives)
        error('PSAMA:EmptyArchive','Joint allocation requires a nonempty archive.');
    end

    referenceFront = archive.objectives;

    template = struct( ...
        'sourceIndex',NaN, ...
        'sourceType','', ...
        'recoveryScore',NaN, ...
        'sourceObjective',[], ...
        'operatorId',NaN, ...
        'operatorName','', ...
        'context',[], ...
        'score',NaN, ...
        'predictedMean',NaN, ...
        'uncertainty',NaN, ...
        'tieKey',NaN, ...
        'child',[], ...
        'operatorMeta',[]);

    pairs = repmat(template,0,1);
    catalog = operator_catalog(cfg);

    for q = 1:numel(pool.indices)
        idx = pool.indices(q);

        if isempty(pop.decoded{idx})
            error('PSAMA:MissingDecodedCache', ...
                ['Joint allocation requires decoded schedules cached by ' ...
                 'the common objective evaluator.']);
        end

        decoded = pop.decoded{idx};
        objective = pop.objectives(idx,:);

        [context,~,~] = build_context_vector( ...
            decoded,objective,referenceFront,inst,cfg);

        for opId = 1:cfg.operators.count
            [child,meta] = apply_operator( ...
                opId,pop.chromosomes(idx,:),decoded,inst,cfg);

            if ~meta.changed
                continue;
            end

            [score,mu,u] = linucb_score( ...
                model,opId,context,cfg);

            item = template;
            item.sourceIndex = idx;
            item.sourceType = pool.sourceType{q};
            item.recoveryScore = pool.recoveryScore(q);
            item.sourceObjective = objective;

            item.operatorId = opId;
            item.operatorName = catalog(opId).name;
            item.context = context;

            item.score = score;
            item.predictedMean = mu;
            item.uncertainty = u;

            if cfg.learning.randomTieBreak
                item.tieKey = rand();
            else
                item.tieKey = opId;
            end

            item.child = child;
            item.operatorMeta = meta;

            pairs(end+1,1) = item; %#ok<AGROW>
        end
    end
end
