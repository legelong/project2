function [score,meanReward,uncertainty] = ...
    linucb_score(model,operatorId,context,cfg)
%LINUCB_SCORE UCB score for one (solution,operator) pair.

    if operatorId < 1 || operatorId > model.numOperators
        error('PSAMA:OperatorId','Invalid LinUCB operator ID.');
    end

    x = augment_context(context,cfg);
    A = model.A{operatorId};
    theta = model.theta{operatorId};

    meanReward = theta' * x;

    variance = x' * (A \ x);
    variance = max(variance,0);
    uncertainty = sqrt(variance);

    score = meanReward + model.alpha * uncertainty;
end
