function selected = select_serial_pairs_same_scores(pairs,budget,cfg)
%SELECT_SERIAL_PAIRS_SAME_SCORES Clean H2 serial allocation.
%
% SAME pair scores as FULL are used.
%
% Stage 1: source score = mean LinUCB pair score over its feasible operators.
%          Sources are ranked independently of choosing one particular action.
% Stage 2: within each chosen source, choose its best currently unused operator.
%
% If budget remains, additional rounds revisit sources in the SAME source order
% and take their next-best unused operator.
%
% No hand-crafted pressure/flexibility source score is introduced.

    if budget <= 0 || isempty(pairs)
        selected = pairs([]);
        return;
    end

    sourceIds = unique([pairs.sourceIndex]','stable');
    sourceScore = zeros(numel(sourceIds),1);
    sourceTie = rand(numel(sourceIds),1);

    sourcePairOrder = cell(numel(sourceIds),1);

    for s = 1:numel(sourceIds)
        idx = find([pairs.sourceIndex]' == sourceIds(s));

        scores = [pairs(idx).score]';
        ties = [pairs(idx).tieKey]';
        opIds = [pairs(idx).operatorId]';

        sourceScore(s) = mean(scores);

        key = [-scores,-ties,opIds];
        [~,ord] = sortrows(key,[1 2 3]);
        sourcePairOrder{s} = idx(ord);
    end

    sourceKey = [-sourceScore,-sourceTie,sourceIds];
    [~,sourceOrder] = sortrows(sourceKey,[1 2 3]);

    selected = pairs([]);
    cursor = ones(numel(sourceIds),1);

    while numel(selected) < budget
        addedThisRound = 0;

        for oo = 1:numel(sourceOrder)
            s = sourceOrder(oo);
            list = sourcePairOrder{s};

            if cursor(s) > numel(list)
                continue;
            end

            selected(end+1,1) = pairs(list(cursor(s))); %#ok<AGROW>
            cursor(s) = cursor(s)+1;
            addedThisRound = addedThisRound+1;

            if numel(selected) >= budget
                break;
            end
        end

        if addedThisRound == 0
            break;
        end
    end
end
