function pool = build_search_source_pool_variant(pop,inst,cfg,variant)
%BUILD_SEARCH_SOURCE_POOL_VARIANT Common source pool with one H3 toggle.

    if isempty(pop.fronts)
        pop = assign_rank_and_crowding(pop);
    end

    f1 = pop.fronts{1}(:);

    switch upper(variant.sourceMode)
        case 'F1'
            pool.indices = f1;
            pool.sourceType = repmat({'F1'},numel(f1),1);
            pool.recoveryScore = ones(numel(f1),1);
            pool.f1Indices = f1;
            pool.f2SelectedIndices = [];
            pool.recovery = [];

        case 'F1F2'
            pool = build_search_source_pool(pop,inst,cfg);

        otherwise
            error('PSAMA:SourceMode', ...
                'Unknown source mode: %s',variant.sourceMode);
    end
end
