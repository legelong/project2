function summary = summarize_linucb(model,cfg)
%SUMMARIZE_LINUCB Print operator learning statistics.

    catalog = operator_catalog(cfg);
    K = model.numOperators;

    meanReward = zeros(K,1);
    positiveRate = zeros(K,1);

    for a = 1:K
        if model.pullCount(a) > 0
            meanReward(a) = ...
                model.rewardSum(a)/model.pullCount(a);
            positiveRate(a) = ...
                model.positiveRewardCount(a)/model.pullCount(a);
        end
    end

    summary.pullCount = model.pullCount;
    summary.rewardSum = model.rewardSum;
    summary.meanReward = meanReward;
    summary.positiveRewardRate = positiveRate;

    fprintf('\nLinUCB operator summary\n');
    fprintf('%-3s %-40s %8s %12s %12s\n', ...
        'ID','Operator','Pulls','MeanReward','PositiveRate');
    fprintf('%s\n',repmat('-',1,82));

    for a = 1:K
        fprintf('%-3d %-40s %8d %12.6g %12.3f\n', ...
            a,catalog(a).name,model.pullCount(a), ...
            meanReward(a),positiveRate(a));
    end
end
