function model = initialize_linucb(cfg)
%INITIALIZE_LINUCB Independent linear-UCB model for each operator.

    if nargin < 1 || isempty(cfg)
        cfg = make_shared_config();
    end

    K = cfg.operators.count;
    d = cfg.learning.featureDimension;
    lambda = cfg.learning.ridgeLambda;

    model.method = cfg.learning.method;
    model.numOperators = K;
    model.contextDimension = cfg.learning.contextDimension;
    model.featureDimension = d;
    model.alpha = cfg.learning.alpha;
    model.ridgeLambda = lambda;

    model.A = cell(K,1);
    model.b = cell(K,1);
    model.theta = cell(K,1);

    model.pullCount = zeros(K,1);
    model.rewardSum = zeros(K,1);
    model.positiveRewardCount = zeros(K,1);
    model.totalUpdates = 0;

    for a = 1:K
        model.A{a} = lambda * eye(d);
        model.b{a} = zeros(d,1);
        model.theta{a} = zeros(d,1);
    end
end
