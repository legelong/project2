function pop = append_evaluated_child(pop,chromosome,objective,decoded)
%APPEND_EVALUATED_CHILD Append one already evaluated solution.

    pop.chromosomes(end+1,:) = chromosome;
    pop.objectives(end+1,:) = objective(:)';
    pop.decoded{end+1,1} = decoded;
    pop.rank(end+1,1) = inf;
    pop.crowding(end+1,1) = 0;
    pop.fronts = {};
    pop.nfe = pop.nfe + 1;
end
