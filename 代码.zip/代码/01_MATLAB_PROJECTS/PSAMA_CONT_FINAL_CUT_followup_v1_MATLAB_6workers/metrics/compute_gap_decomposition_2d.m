function G = compute_gap_decomposition_2d(points,referenceFront)
%COMPUTE_GAP_DECOMPOSITION_2D Separate internal spacing from endpoint coverage.
%
% Inputs are normalized minimization fronts.
%
% Outputs:
%   compositeMaxGap
%       Legacy metric = max internal/anchor gap using artificial
%       anchors [0,1] and [1,0].
%
%   internalMaxGap
%       Maximum adjacent distance between ACTUAL front points only.
%
%   anchorLeftGap / anchorRightGap / anchorEndpointMaxGap
%       The two artificial-anchor components used by the legacy metric.
%
%   referenceLeftError / referenceRightError / referenceEndpointMaxError
%       Distance to the corresponding endpoint of the unified empirical
%       reference front. This is the preferred endpoint-coverage diagnostic.
%
% All Euclidean distances are divided by sqrt(2).

    P = nondominated_objectives(points);
    P = min(max(P,0),1);
    P = unique(P,'rows','stable');

    [~,ord] = sort(P(:,1),'ascend');
    P = P(ord,:);

    R = nondominated_objectives(referenceFront);
    R = min(max(R,0),1);
    R = unique(R,'rows','stable');
    [~,ordR] = sort(R(:,1),'ascend');
    R = R(ordR,:);

    G.compositeMaxGap = compute_max_gap_2d(P,true);

    if isempty(P)
        G.internalMaxGap = NaN;
        G.anchorLeftGap = 1;
        G.anchorRightGap = 1;
        G.anchorEndpointMaxGap = 1;
        G.referenceLeftError = 1;
        G.referenceRightError = 1;
        G.referenceEndpointMaxError = 1;
        G.referenceEndpointMeanError = 1;
        return;
    end

    if size(P,1) >= 2
        d = sqrt(sum(diff(P,1,1).^2,2))/sqrt(2);
        G.internalMaxGap = max(d);
    else
        G.internalMaxGap = NaN;
    end

    G.anchorLeftGap = norm(P(1,:)-[0,1])/sqrt(2);
    G.anchorRightGap = norm(P(end,:)-[1,0])/sqrt(2);
    G.anchorEndpointMaxGap = ...
        max(G.anchorLeftGap,G.anchorRightGap);

    if isempty(R)
        G.referenceLeftError = NaN;
        G.referenceRightError = NaN;
        G.referenceEndpointMaxError = NaN;
        G.referenceEndpointMeanError = NaN;
    else
        G.referenceLeftError = norm(P(1,:)-R(1,:))/sqrt(2);
        G.referenceRightError = norm(P(end,:)-R(end,:))/sqrt(2);
        G.referenceEndpointMaxError = ...
            max(G.referenceLeftError,G.referenceRightError);
        G.referenceEndpointMeanError = ...
            mean([G.referenceLeftError,G.referenceRightError]);
    end
end
