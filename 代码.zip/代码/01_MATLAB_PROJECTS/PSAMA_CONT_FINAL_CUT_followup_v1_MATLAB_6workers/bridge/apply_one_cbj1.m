function result = apply_one_cbj1(current,cmaxBound,inst,cfg)
%APPLY_ONE_CBJ1 One safe exact best speed+timing block improvement.

    scan = safe_best_reduced_joint_scan( ...
        current,cmaxBound,inst,cfg);

    if scan.bestGain > cfg.cb.improvementTolerance
        out = scan.bestSolution.decoded;
        accepted = true;
    else
        out = current;
        accepted = false;
    end

    result.decoded = out;
    result.accepted = accepted;

    result.bestGain = scan.bestGain;
    result.bestCandidateId = scan.bestCandidateId;
    result.bestBlockLength = scan.bestBlockLength;
    result.bestBoundRank = scan.bestBoundRank;

    result.totalCandidates = scan.totalCandidates;
    result.exactEvaluations = scan.exactEvaluations;
    result.exactEvaluationFraction = scan.exactEvaluationFraction;

    result.boundSeconds = scan.boundSeconds;
    result.exactSeconds = scan.exactSeconds;
end
