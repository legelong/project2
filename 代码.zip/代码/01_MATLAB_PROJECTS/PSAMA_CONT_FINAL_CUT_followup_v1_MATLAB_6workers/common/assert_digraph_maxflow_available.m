function assert_digraph_maxflow_available()
%ASSERT_DIGRAPH_MAXFLOW_AVAILABLE Real runtime test of digraph/maxflow.
%
% maxflow is commonly implemented as a digraph method, so checking whether a
% standalone maxflow.m file exists is not reliable.

    try
        G = digraph([1 1 2],[2 3 3],[2 1 2],3);
        f = maxflow(G,1,3);

        if ~isfinite(f) || abs(f-3)>1e-12
            error('Unexpected maxflow smoke-test value.');
        end
    catch ME
        error('PSAMA:MissingMATLABMaxflow', ...
            ['MATLAB digraph/maxflow smoke test failed.\n' ...
             'Original message: %s'],ME.message);
    end
end
