function candidates = enumerate_cb_blocks(current,cmaxBound,inst,cfg)
%ENUMERATE_CB_BLOCKS Every contiguous L=3/L=5 physical-machine block.

    graph = build_fixed_order_graph_general( ...
        current,inst,cmaxBound,cfg);

    candidates = struct( ...
        'candidateId',{},'factory',{},'machine',{}, ...
        'length',{},'machineStartPosition',{}, ...
        'opIds',{},'machinePositions',{}, ...
        'prevMachineOp',{},'nextMachineOp',{}, ...
        'selectionScore',{},'scoreSlackNorm',{}, ...
        'scoreEventFraction',{},'scoreExpensiveExposure',{}, ...
        'cmaxBound',{});

    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = current.machineSchedules{f,m};
            ids = ids(:);

            for ll = 1:numel(cfg.cb.blockLengths)
                L = cfg.cb.blockLengths(ll);

                if numel(ids)<L
                    continue;
                end

                for p = 1:(numel(ids)-L+1)
                    opIds = ids(p:p+L-1);

                    % Kept only as a diagnostic; never used for CB selection.
                    detail = score_block_candidate( ...
                        opIds,current,graph,inst,cfg);

                    if p>1
                        prevOp = ids(p-1);
                    else
                        prevOp = NaN;
                    end

                    if p+L-1 < numel(ids)
                        nextOp = ids(p+L);
                    else
                        nextOp = NaN;
                    end

                    c.candidateId = sprintf( ...
                        'F%d_M%d_P%d_L%d',f,m,p,L);
                    c.factory = f;
                    c.machine = m;
                    c.length = L;
                    c.machineStartPosition = p;
                    c.opIds = opIds(:)';
                    c.machinePositions = p:(p+L-1);
                    c.prevMachineOp = prevOp;
                    c.nextMachineOp = nextOp;

                    c.selectionScore = detail.score;
                    c.scoreSlackNorm = detail.slackNorm;
                    c.scoreEventFraction = detail.eventFraction;
                    c.scoreExpensiveExposure = detail.expensiveExposure;

                    c.cmaxBound = cmaxBound;

                    candidates(end+1,1) = c; %#ok<AGROW>
                end
            end
        end
    end
end
