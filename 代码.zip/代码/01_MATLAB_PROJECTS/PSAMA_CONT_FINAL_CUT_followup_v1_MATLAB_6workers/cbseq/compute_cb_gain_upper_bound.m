function U = compute_cb_gain_upper_bound( ...
    candidate,current,inst,cfg,mode)
%COMPUTE_CB_GAIN_UPPER_BOUND Safe exact-gain upper bound.
%
% For both modes:
%
%   ExactGain
%     = CurrentAffectedCost - FutureAffectedCost
%
%   FutureAffectedCost
%     >= FutureProcessingLowerBound
%
% because future machine idle cost is nonnegative.
%
% CB_RETIME:
%   speed/duration fixed, so processing lower bound is
%
%       sum_g P(v_current) * d_current * valleyPrice
%
% CB_JOINT:
%   speed can change, so use
%
%       sum_g min_v [P(v)*d_g(v)*valleyPrice]
%
% Hence ExactGain <= GainUpperBound in both modes.

    mode = upper(char(mode));

    if ~strcmp(mode,'CB_RETIME') && ~strcmp(mode,'CB_JOINT')
        error('PSAMA:CBMode','Unknown cost-bound mode: %s',mode);
    end

    opIds = candidate.opIds(:);

    currentAffected = compute_block_affected_cost( ...
        current.op.start(opIds), ...
        current.op.duration(opIds), ...
        current.op.speed(opIds), ...
        candidate,current,inst);

    processingLowerBound = 0;

    for q = 1:numel(opIds)
        g = opIds(q);

        if strcmp(mode,'CB_RETIME')
            v = current.op.speed(g);
            d = current.op.duration(g);
            p = processing_power(v,inst);

            best = p*d*inst.tariff.valleyPrice;
        else
            best = inf;

            for v = inst.speed.levels(:)'
                d = processing_duration(current.op.baseTime(g),v,inst);
                p = processing_power(v,inst);

                best = min(best,p*d*inst.tariff.valleyPrice);
            end
        end

        processingLowerBound = processingLowerBound+best;
    end

    gainUpperBound = currentAffected-processingLowerBound;

    if gainUpperBound < -cfg.block.objectiveTolerance
        error('PSAMA:NegativeCBUpperBound', ...
            'Derived safe gain upper bound is negative beyond tolerance.');
    end

    U.CurrentAffectedCost = currentAffected;
    U.ProcessingLowerBound = processingLowerBound;
    U.GainUpperBound = max(0,gainUpperBound);
end
