function scan = safe_best_block_scan(current,cmaxBound,inst,cfg,mode,iteration)
%SAFE_BEST_BLOCK_SCAN Provably find best block in current L3/L5 family.
%
% 1. enumerate every candidate
% 2. compute cheap safe GainUpperBound
% 3. sort by upper bound descending
% 4. exact-solve candidates until:
%
%       nextUB <= bestExactGain
%
% At that point no unevaluated block can beat the incumbent.

    mode = upper(char(mode));

    candidates = enumerate_cb_blocks( ...
        current,cmaxBound,inst,cfg);

    n = numel(candidates);

    if n==0
        scan = empty_scan(iteration,mode);
        scan.stopReason = 'NO_CANDIDATES';
        return;
    end

    gainUB = zeros(n,1);
    affected = zeros(n,1);
    lower = zeros(n,1);

    tBound = tic;

    for i = 1:n
        U = compute_cb_gain_upper_bound( ...
            candidates(i),current,inst,cfg,mode);

        gainUB(i) = U.GainUpperBound;
        affected(i) = U.CurrentAffectedCost;
        lower(i) = U.ProcessingLowerBound;
    end

    boundSeconds = toc(tBound);

    % Deterministic tie-break:
    % higher UB, then longer block, then physical location.
    L = [candidates.length]';
    f = [candidates.factory]';
    m = [candidates.machine]';
    p = [candidates.machineStartPosition]';

    key = [-gainUB,-L,f,m,p];
    [~,ord] = sortrows(key,[1 2 3 4 5]);

    candidates = candidates(ord);
    gainUB = gainUB(ord);
    affected = affected(ord);
    lower = lower(ord);

    entries = struct( ...
        'boundRank',{},'candidateId',{}, ...
        'factory',{},'machine',{},'blockLength',{}, ...
        'machineStartPosition',{}, ...
        'gainUpperBound',{},'currentAffectedCost',{}, ...
        'processingLowerBound',{}, ...
        'preTEC',{},'postTEC',{}, ...
        'exactGain',{},'gainPctOfInitialState',{}, ...
        'upperBoundSlack',{}, ...
        'solveSeconds',{},'binaryVariables',{}, ...
        'exactCertified',{},'status',{},'solution',{});

    bestGain = 0;
    bestEntryIndex = NaN;
    exactSeconds = 0;
    stopReason = 'EXHAUSTED';

    for i = 1:n
        % Safe pruning BEFORE solving current candidate.
        if gainUB(i) <= ...
                bestGain+cfg.cb.improvementTolerance
            stopReason = 'BOUND_CERTIFIED';
            break;
        end

        if strcmp(mode,'CB_RETIME')
            solverMode = 'RETIME_ONLY';
        else
            solverMode = 'JOINT';
        end

        sol = solve_block_speed_time_milp( ...
            current,candidates(i),inst,cfg,solverMode);

        if cfg.cb.requireExact && ~sol.exactCertified
            error('PSAMA:CBSafeScanNotExact', ...
                ['A required %s exact block was not certified. ' ...
                 'Increase solver limit before using this result.'],mode);
        end

        exactSeconds = exactSeconds+sol.solveSeconds;

        gain = current.cost.total-sol.totalTEC;

        if gain < -cfg.block.objectiveTolerance
            error('PSAMA:CBSafeScanNegativeGain', ...
                'Current decision should make exact block gain nonnegative.');
        end

        gain = max(0,gain);

        if gain > gainUB(i)+cfg.block.objectiveTolerance
            error('PSAMA:CBUpperBoundViolation', ...
                'Exact gain exceeded the safe upper bound.');
        end

        e.boundRank = i;
        e.candidateId = candidates(i).candidateId;
        e.factory = candidates(i).factory;
        e.machine = candidates(i).machine;
        e.blockLength = candidates(i).length;
        e.machineStartPosition = candidates(i).machineStartPosition;

        e.gainUpperBound = gainUB(i);
        e.currentAffectedCost = affected(i);
        e.processingLowerBound = lower(i);

        e.preTEC = current.cost.total;
        e.postTEC = sol.totalTEC;
        e.exactGain = gain;
        e.gainPctOfInitialState = ...
            100*gain/max(current.cost.total,eps);

        e.upperBoundSlack = gainUB(i)-gain;

        e.solveSeconds = sol.solveSeconds;
        e.binaryVariables = sol.numBinaryVariables;
        e.exactCertified = sol.exactCertified;
        e.status = sol.status;
        e.solution = sol;

        entries(end+1,1) = e; %#ok<AGROW>

        if gain > bestGain+cfg.cb.improvementTolerance
            bestGain = gain;
            bestEntryIndex = numel(entries);
        end
    end

    if n>0 && isempty(entries) && ...
       gainUB(1)<=cfg.cb.improvementTolerance
        stopReason = 'BOUND_PROVES_NO_POSITIVE_GAIN';
    elseif numel(entries)==n
        stopReason = 'EXHAUSTED';
    end

    scan.iteration = iteration;
    scan.mode = mode;

    scan.totalCandidates = n;
    scan.boundSeconds = boundSeconds;
    scan.exactSeconds = exactSeconds;

    scan.exactEvaluations = numel(entries);
    scan.exactEvaluationFraction = numel(entries)/n;

    scan.maxGainUpperBound = gainUB(1);
    scan.bestGain = bestGain;
    scan.bestEntryIndex = bestEntryIndex;
    scan.stopReason = stopReason;

    scan.entries = entries;

    if isnan(bestEntryIndex)
        scan.bestSolution = [];
        scan.bestCandidateId = '';
        scan.bestBlockLength = NaN;
        scan.bestBoundRank = NaN;
    else
        best = entries(bestEntryIndex);
        scan.bestSolution = best.solution;
        scan.bestCandidateId = best.candidateId;
        scan.bestBlockLength = best.blockLength;
        scan.bestBoundRank = best.boundRank;
    end
end

function scan = empty_scan(iteration,mode)
    scan.iteration = iteration;
    scan.mode = mode;
    scan.totalCandidates = 0;
    scan.boundSeconds = 0;
    scan.exactSeconds = 0;
    scan.exactEvaluations = 0;
    scan.exactEvaluationFraction = 0;
    scan.maxGainUpperBound = 0;
    scan.bestGain = 0;
    scan.bestEntryIndex = NaN;
    scan.stopReason = '';
    scan.entries = struct([]);
    scan.bestSolution = [];
    scan.bestCandidateId = '';
    scan.bestBlockLength = NaN;
    scan.bestBoundRank = NaN;
end
