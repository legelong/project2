function compact = compact_scan_for_storage(scan)
%COMPACT_SCAN_FOR_STORAGE Remove decoded solution payloads from scan raw.

    compact.iteration = scan.iteration;
    compact.mode = scan.mode;

    compact.totalCandidates = scan.totalCandidates;
    compact.boundSeconds = scan.boundSeconds;
    compact.exactSeconds = scan.exactSeconds;
    compact.exactEvaluations = scan.exactEvaluations;
    compact.exactEvaluationFraction = scan.exactEvaluationFraction;

    compact.maxGainUpperBound = scan.maxGainUpperBound;
    compact.bestGain = scan.bestGain;
    compact.bestEntryIndex = scan.bestEntryIndex;
    compact.stopReason = scan.stopReason;

    compact.bestCandidateId = scan.bestCandidateId;
    compact.bestBlockLength = scan.bestBlockLength;
    compact.bestBoundRank = scan.bestBoundRank;

    entryTemplate = struct( ...
        'boundRank',{},'candidateId',{}, ...
        'factory',{},'machine',{},'blockLength',{}, ...
        'machineStartPosition',{}, ...
        'gainUpperBound',{},'currentAffectedCost',{}, ...
        'processingLowerBound',{}, ...
        'preTEC',{},'postTEC',{}, ...
        'exactGain',{},'gainPctOfInitialState',{}, ...
        'upperBoundSlack',{}, ...
        'solveSeconds',{},'binaryVariables',{}, ...
        'exactCertified',{},'status',{});

    E = entryTemplate;

    for i = 1:numel(scan.entries)
        s = scan.entries(i);

        e.boundRank = s.boundRank;
        e.candidateId = s.candidateId;
        e.factory = s.factory;
        e.machine = s.machine;
        e.blockLength = s.blockLength;
        e.machineStartPosition = s.machineStartPosition;

        e.gainUpperBound = s.gainUpperBound;
        e.currentAffectedCost = s.currentAffectedCost;
        e.processingLowerBound = s.processingLowerBound;

        e.preTEC = s.preTEC;
        e.postTEC = s.postTEC;
        e.exactGain = s.exactGain;
        e.gainPctOfInitialState = s.gainPctOfInitialState;
        e.upperBoundSlack = s.upperBoundSlack;

        e.solveSeconds = s.solveSeconds;
        e.binaryVariables = s.binaryVariables;
        e.exactCertified = s.exactCertified;
        e.status = s.status;

        E(end+1,1) = e; %#ok<AGROW>
    end

    compact.entries = E;
end
