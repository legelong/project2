function out = run_costbound_sequential_method( ...
    initial,cmaxBound,inst,cfg,mode)
%RUN_COSTBOUND_SEQUENTIAL_METHOD Repeated safe exact best-block improvement.

    mode = upper(char(mode));

    if ~strcmp(mode,'CB_RETIME') && ~strcmp(mode,'CB_JOINT')
        error('PSAMA:CBSequentialMode','Unknown mode: %s',mode);
    end

    current = initial;

    if ~isfield(current,'cost')
        current.cost = compute_tec(current,inst);
        current.objectives = [current.makespan,current.cost.total];
    end

    validate_schedule(current,inst,cfg,true);

    initialTEC = current.cost.total;

    accepted = struct( ...
        'iteration',{},'candidateId',{}, ...
        'blockLength',{},'boundRank',{}, ...
        'preTEC',{},'postTEC',{}, ...
        'gain',{},'gainPctOfInitial',{}, ...
        'cumulativeGainPct',{}, ...
        'movedOperations',{},'speedChangedOperations',{}, ...
        'tariffAlignedFraction',{}, ...
        'totalCandidates',{},'exactEvaluations',{}, ...
        'exactEvaluationFraction',{}, ...
        'boundSeconds',{},'exactSeconds',{});

    scans = cell(cfg.cb.maxAcceptedMoves+1,1);

    totalExactEvaluations = 0;
    totalCandidatesSeen = 0;
    totalBoundSeconds = 0;
    totalExactSeconds = 0;

    converged = false;
    stopReason = 'MAX_ACCEPTED_MOVES';

    tTotal = tic;

    for iter = 1:(cfg.cb.maxAcceptedMoves+1)
        scan = safe_best_block_scan( ...
            current,cmaxBound,inst,cfg,mode,iter);

        scans{iter} = compact_scan_for_storage(scan);

        totalExactEvaluations = ...
            totalExactEvaluations+scan.exactEvaluations;

        totalCandidatesSeen = ...
            totalCandidatesSeen+scan.totalCandidates;

        totalBoundSeconds = ...
            totalBoundSeconds+scan.boundSeconds;

        totalExactSeconds = ...
            totalExactSeconds+scan.exactSeconds;

        % A safe scan has proven the best candidate-family gain.
        if scan.bestGain <= cfg.cb.improvementTolerance
            converged = true;
            stopReason = 'PROVEN_NO_POSITIVE_BLOCK';
            scans = scans(1:iter);
            break;
        end

        % The (maxMoves+1)-th scan is only used to check whether the safety
        % cap was reached before convergence. Do not accept another move.
        if iter > cfg.cb.maxAcceptedMoves
            converged = false;
            stopReason = 'MAX_ACCEPTED_MOVES_WITH_POSITIVE_GAIN_REMAINING';
            scans = scans(1:iter);
            break;
        end

        bestSol = scan.bestSolution;

        if isempty(bestSol)
            error('PSAMA:CBMissingBestSolution', ...
                'Positive proven gain but no best exact solution is stored.');
        end

        before = current;
        current = bestSol.decoded;

        if current.cost.total >= ...
                before.cost.total-cfg.cb.improvementTolerance
            error('PSAMA:CBNonImprovingAcceptance', ...
                'Attempted to accept a non-improving exact block.');
        end

        if current.makespan > ...
                cmaxBound+cfg.decoder.tolerance
            error('PSAMA:CBCmaxViolation', ...
                'Accepted exact block exceeded preserved Cmax.');
        end

        % Identify block operations from accepted candidate ID via exact entry.
        e = scan.entries(scan.bestEntryIndex);
        acceptedCandidate = find_entry_candidate_ops( ...
            before,cmaxBound,inst,cfg,e.candidateId);

        startShift = ...
            current.op.start(acceptedCandidate.opIds) - ...
            before.op.start(acceptedCandidate.opIds);

        speedShift = ...
            current.op.speed(acceptedCandidate.opIds) - ...
            before.op.speed(acceptedCandidate.opIds);

        align = count_tariff_aligned_events( ...
            bestSol.starts,bestSol.durations,inst);

        a.iteration = iter;
        a.candidateId = e.candidateId;
        a.blockLength = e.blockLength;
        a.boundRank = e.boundRank;

        a.preTEC = before.cost.total;
        a.postTEC = current.cost.total;
        a.gain = before.cost.total-current.cost.total;

        a.gainPctOfInitial = ...
            100*a.gain/max(initialTEC,eps);

        a.cumulativeGainPct = ...
            100*(initialTEC-current.cost.total)/max(initialTEC,eps);

        a.movedOperations = sum( ...
            abs(startShift)>cfg.decoder.tolerance);

        a.speedChangedOperations = sum( ...
            abs(speedShift)>cfg.decoder.tolerance);

        a.tariffAlignedFraction = align.anyAlignedFraction;

        a.totalCandidates = scan.totalCandidates;
        a.exactEvaluations = scan.exactEvaluations;
        a.exactEvaluationFraction = scan.exactEvaluationFraction;

        a.boundSeconds = scan.boundSeconds;
        a.exactSeconds = scan.exactSeconds;

        accepted(end+1,1) = a; %#ok<AGROW>
    end

    elapsed = toc(tTotal);

    if any(current.op.finish > cmaxBound+cfg.decoder.tolerance)
        error('PSAMA:CBFinalCmaxBound', ...
            'Final sequential schedule violates preserved Cmax bound.');
    end

    validate_schedule(current,inst,cfg,true);

    out.mode = mode;
    out.initial = initial;
    out.final = current;

    out.initialTEC = initialTEC;
    out.finalTEC = current.cost.total;
    out.cmaxBound = cmaxBound;

    out.accepted = accepted;
    out.scans = scans;

    out.acceptedMoves = numel(accepted);
    out.converged = converged;
    out.stopReason = stopReason;

    out.totalGain = initialTEC-current.cost.total;
    out.totalGainPct = 100*out.totalGain/max(initialTEC,eps);

    out.totalExactEvaluations = totalExactEvaluations;
    out.totalCandidatesSeen = totalCandidatesSeen;

    if totalCandidatesSeen>0
        out.aggregateExactEvaluationFraction = ...
            totalExactEvaluations/totalCandidatesSeen;
    else
        out.aggregateExactEvaluationFraction = 0;
    end

    out.totalBoundSeconds = totalBoundSeconds;
    out.totalExactSeconds = totalExactSeconds;
    out.elapsedSeconds = elapsed;
end

function candidate = find_entry_candidate_ops( ...
    current,cmaxBound,inst,cfg,candidateId)
% Re-enumerate cheap candidate metadata deterministically.

    candidates = enumerate_cb_blocks( ...
        current,cmaxBound,inst,cfg);

    ids = {candidates.candidateId};
    idx = find(strcmp(ids,candidateId),1);

    if isempty(idx)
        error('PSAMA:CBCandidateReplay', ...
            'Accepted candidate ID cannot be replayed: %s',candidateId);
    end

    candidate = candidates(idx);
end
