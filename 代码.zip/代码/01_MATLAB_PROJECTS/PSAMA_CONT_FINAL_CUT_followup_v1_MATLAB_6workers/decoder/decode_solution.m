function decoded = decode_solution(chromosome, inst, cfg)
%DECODE_SOLUTION Deterministic common decoder for all future algorithms.
%
% Representation:
%   chromosome = [FS | OS | MS | VS]
%
% FS: actual factory IDs by job
% OS: job occurrence sequence; kth occurrence of job j means operation k
% MS: actual machine IDs in fixed [job,operation] order
% VS: actual speed values in fixed [job,operation] order
%
% Decoder:
%   Giffler-Thompson-style active schedule generation.
%   Among currently available next operations, find the minimum earliest
%   finish operation p*. Let M* be its assigned machine. Build a conflict
%   set from currently available operations assigned to M* whose earliest
%   start is earlier than EF(p*). Select the conflict operation with the
%   earliest OS occurrence position.
%
% This is deterministic and is shared by Full / Baseline / Ablations.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    if cfg.decoder.validateChromosome
        validate_chromosome(chromosome, inst, true);
    end

    parts = split_chromosome(chromosome, inst);

    J = inst.size.numJobs;
    F = inst.size.numFactories;
    Mvec = inst.size.numMachinesPerFactory(:)';
    maxM = max(Mvec);
    totalOps = inst.size.totalOperations;
    opsPerJob = inst.size.operationsPerJob(:);

    % --------------------------------------------------------------
    % OS occurrence position for every job-operation pair.
    % --------------------------------------------------------------
    maxOps = inst.size.maxOperationsPerJob;
    osPriority = nan(J, maxOps);
    occurrence = zeros(J, 1);

    for pos = 1:numel(parts.OS)
        j = parts.OS(pos);
        occurrence(j) = occurrence(j) + 1;
        o = occurrence(j);
        osPriority(j, o) = pos;
    end

    % --------------------------------------------------------------
    % Preallocate operation-level decoded schedule.
    % Every vector is indexed by global operation ID g.
    % --------------------------------------------------------------
    op.globalId = (1:totalOps)';
    op.job = inst.map.globalToJob(:);
    op.operation = inst.map.globalToOperation(:);
    op.factory = nan(totalOps, 1);
    op.machine = nan(totalOps, 1);
    op.speed = nan(totalOps, 1);
    op.baseTime = nan(totalOps, 1);
    op.duration = nan(totalOps, 1);
    op.start = nan(totalOps, 1);
    op.finish = nan(totalOps, 1);
    op.osPriority = nan(totalOps, 1);

    machineSchedules = cell(F, maxM);
    for f = 1:F
        for m = 1:maxM
            machineSchedules{f,m} = zeros(0,1);
        end
    end

    factoryMakespan = zeros(1, F);

    % --------------------------------------------------------------
    % Decode each factory independently because every job stays in its
    % assigned factory for all operations.
    % --------------------------------------------------------------
    for f = 1:F
        jobs = find(parts.FS == f);
        if isempty(jobs)
            continue;
        end

        machineAvail = zeros(1, Mvec(f));
        jobReady = zeros(J, 1);
        nextOp = ones(J, 1);

        targetCount = sum(opsPerJob(jobs));
        scheduledCount = 0;

        while scheduledCount < targetCount
            % Candidate rows:
            % [job op g machine speed base duration ES EF OSpriority]
            C = zeros(numel(jobs), 10);
            nC = 0;

            for q = 1:numel(jobs)
                j = jobs(q);
                o = nextOp(j);

                if o > opsPerJob(j)
                    continue;
                end

                g = inst.map.opGlobalIndex(j, o);
                machine = parts.MS(g);
                speed = parts.VS(g);

                baseTime = inst.process.baseTimeDense(f, j, o, machine);
                if isnan(baseTime)
                    error('PSAMA:DecoderIllegalMachine', ...
                        ['Decoder encountered an ineligible machine despite ' ...
                         'chromosome validation: f=%d,j=%d,o=%d,m=%d.'], ...
                         f,j,o,machine);
                end

                duration = processing_duration(baseTime, speed, inst);
                ES = max(jobReady(j), machineAvail(machine));
                EF = ES + duration;

                nC = nC + 1;
                C(nC,:) = [j, o, g, machine, speed, baseTime, ...
                           duration, ES, EF, osPriority(j,o)];
            end

            C = C(1:nC,:);
            if isempty(C)
                error('PSAMA:DecoderDeadlock', ...
                    'No available operation but unscheduled operations remain.');
            end

            % Earliest finish p*. MATLAB min returns the first row on ties;
            % jobs are traversed in ascending job ID, making this deterministic.
            [EFstar, starIdx] = min(C(:,9));
            Mstar = C(starIdx,4);

            % Giffler-Thompson conflict set.
            conflictMask = (C(:,4) == Mstar) & (C(:,8) < EFstar);

            if any(conflictMask)
                idx = find(conflictMask);
                [~, local] = min(C(idx,10)); % smallest OS priority
                selectedIdx = idx(local);
            else
                selectedIdx = starIdx;
            end

            row = C(selectedIdx,:);

            j = row(1);
            o = row(2);
            g = row(3);
            machine = row(4);
            speed = row(5);
            baseTime = row(6);
            duration = row(7);
            startTime = row(8);
            finishTime = row(9);

            op.factory(g) = f;
            op.machine(g) = machine;
            op.speed(g) = speed;
            op.baseTime(g) = baseTime;
            op.duration(g) = duration;
            op.start(g) = startTime;
            op.finish(g) = finishTime;
            op.osPriority(g) = row(10);

            machineSchedules{f,machine}(end+1,1) = g;

            machineAvail(machine) = finishTime;
            jobReady(j) = finishTime;
            nextOp(j) = o + 1;

            scheduledCount = scheduledCount + 1;
            factoryMakespan(f) = max(factoryMakespan(f), finishTime);
        end
    end

    decoded.chromosome = chromosome(:)';
    decoded.parts = parts;
    decoded.op = op;
    decoded.machineSchedules = machineSchedules;
    decoded.factoryMakespan = factoryMakespan;
    decoded.makespan = max(factoryMakespan);
    decoded.decoderMethod = cfg.decoder.method;
    decoded.totalOperations = totalOps;

    if any(isnan(op.start)) || any(isnan(op.finish))
        error('PSAMA:IncompleteDecode', ...
            'At least one operation was not scheduled.');
    end
end
