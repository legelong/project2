function report = validate_chromosome(chromosome, inst, throwOnError)
%VALIDATE_CHROMOSOME Validate one [FS|OS|MS|VS] solution.
%
% Checks:
%   - exact chromosome length;
%   - factory IDs;
%   - OS occurrence counts;
%   - factory-conditional machine eligibility;
%   - speed membership.
%
% report = validate_chromosome(chromosome, inst, false)
% validate_chromosome(chromosome, inst, true)

    if nargin < 3
        throwOnError = true;
    end

    errors = {};

    chromosome = chromosome(:)';
    if numel(chromosome) ~= inst.encoding.totalLength
        errors{end+1} = sprintf( ...
            'Length mismatch: got %d, expected %d.', ...
            numel(chromosome), inst.encoding.totalLength);
        report = finish_report(errors, throwOnError);
        return;
    end

    if any(~isfinite(chromosome))
        errors{end+1} = 'Chromosome contains non-finite values.';
        report = finish_report(errors, throwOnError);
        return;
    end

    parts = split_chromosome(chromosome, inst);

    J = inst.size.numJobs;
    F = inst.size.numFactories;
    opsPerJob = inst.size.operationsPerJob(:);

    % --------------------------------------------------------------
    % FS
    % --------------------------------------------------------------
    fsInteger = all(parts.FS == round(parts.FS));
    fsRange = all(parts.FS >= 1) && all(parts.FS <= F);

    if ~fsInteger
        errors{end+1} = 'FS must contain integer factory IDs.';
    end
    if ~fsRange
        errors{end+1} = sprintf('FS contains IDs outside 1..%d.', F);
    end

    % --------------------------------------------------------------
    % OS
    % --------------------------------------------------------------
    osInteger = all(parts.OS == round(parts.OS));
    osRange = all(parts.OS >= 1) && all(parts.OS <= J);

    if ~osInteger
        errors{end+1} = 'OS must contain integer job IDs.';
    end
    if ~osRange
        errors{end+1} = sprintf('OS contains job IDs outside 1..%d.', J);
    end

    if osInteger && osRange
        counts = accumarray(parts.OS(:), 1, [J, 1]);
        if any(counts ~= opsPerJob)
            bad = find(counts ~= opsPerJob, 1, 'first');
            errors{end+1} = sprintf( ...
                'OS occurrence count mismatch for job %d: got %d, expected %d.', ...
                bad, counts(bad), opsPerJob(bad));
        end
    end

    % --------------------------------------------------------------
    % MS and VS use fixed job-operation global indexing
    % --------------------------------------------------------------
    msInteger = all(parts.MS == round(parts.MS));
    if ~msInteger
        errors{end+1} = 'MS must contain integer actual machine IDs.';
    end

    speedLevels = inst.speed.levels(:)';

    % Only inspect factory-conditional machine feasibility if FS is safe
    % to use as a MATLAB index.
    if fsInteger && fsRange
      for g = 1:inst.size.totalOperations
        j = inst.map.globalToJob(g);
        o = inst.map.globalToOperation(g);
        f = parts.FS(j);

        machine = parts.MS(g);
        eligible = inst.process.eligibleMachines{f, j, o};

        if ~ismember(machine, eligible)
            errors{end+1} = sprintf( ...
                ['Illegal machine at global op %d (job %d, op %d, factory %d): ' ...
                 'machine %g is not in %s.'], ...
                g, j, o, f, machine, mat2str(eligible));
            break;
        end

        speed = parts.VS(g);
        if ~any(abs(speedLevels - speed) <= 1e-12)
            errors{end+1} = sprintf( ...
                ['Illegal speed at global op %d (job %d, op %d): ' ...
                 '%g is not in %s.'], ...
                g, j, o, speed, mat2str(speedLevels));
            break;
        end
      end
    end

    report = finish_report(errors, throwOnError);
end

function report = finish_report(errors, throwOnError)
    report.ok = isempty(errors);
    report.errors = errors;

    if throwOnError && ~report.ok
        error('PSAMA:InvalidChromosome', '%s', strjoin(errors, newline));
    end
end
