function parts = split_chromosome(chromosome, inst)
%SPLIT_CHROMOSOME Split [FS | OS | MS | VS] using the common schema.
%
% MS stores ACTUAL machine IDs.
% VS stores ACTUAL speed values from inst.speed.levels.

    chromosome = chromosome(:)';

    Lfs = inst.encoding.lengthFS;
    Los = inst.encoding.lengthOS;
    Lms = inst.encoding.lengthMS;
    Lvs = inst.encoding.lengthVS;

    expected = Lfs + Los + Lms + Lvs;
    if numel(chromosome) ~= expected
        error('PSAMA:ChromosomeLength', ...
            'Chromosome length is %d; expected %d.', ...
            numel(chromosome), expected);
    end

    p1 = Lfs;
    p2 = p1 + Los;
    p3 = p2 + Lms;

    parts.FS = chromosome(1:p1);
    parts.OS = chromosome(p1+1:p2);
    parts.MS = chromosome(p2+1:p3);
    parts.VS = chromosome(p3+1:end);
end
