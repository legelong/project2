function idx = select_diverse_archive_points(objectives,maxPoints)
%SELECT_DIVERSE_ARCHIVE_POINTS Deterministic farthest-point objective sampling.
%
% Always tries to include:
%   minimum-Cmax endpoint
%   minimum-TEC endpoint
%
% Remaining points maximize the minimum normalized Euclidean distance to the
% already selected set.

    n = size(objectives,1);

    if n==0
        idx = zeros(0,1);
        return;
    end

    K = min(maxPoints,n);

    if n<=K
        idx = (1:n)';
        return;
    end

    lo = min(objectives,[],1);
    hi = max(objectives,[],1);
    span = hi-lo;
    span(span<=1e-12) = 1;

    Z = (objectives-lo)./span;

    [~,iC] = min(objectives(:,1));
    [~,iT] = min(objectives(:,2));

    idx = unique([iC;iT],'stable');

    while numel(idx)<K
        remaining = setdiff((1:n)',idx,'stable');

        minDist = inf(numel(remaining),1);

        for s = 1:numel(idx)
            d = sqrt(sum((Z(remaining,:)-Z(idx(s),:)).^2,2));
            minDist = min(minDist,d);
        end

        best = max(minDist);
        ties = find(abs(minDist-best)<=1e-12);

        % Stable deterministic tie break: smallest archive row.
        candidateRows = remaining(ties);
        [~,k] = min(candidateRows);
        idx(end+1,1) = candidateRows(k); %#ok<AGROW>
    end
end
