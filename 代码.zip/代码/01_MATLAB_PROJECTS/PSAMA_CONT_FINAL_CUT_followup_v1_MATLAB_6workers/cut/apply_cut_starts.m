function out = apply_cut_starts(decoded,starts,inst,cfg)
%APPLY_CUT_STARTS Apply global start times without changing discrete decisions.

    out = decoded;

    starts = round(starts(:));

    out.op.start = starts;
    out.op.finish = starts+out.op.duration(:);

    F = inst.size.numFactories;
    fm = zeros(1,F);

    for f = 1:F
        ids = find(out.op.factory==f);

        if ~isempty(ids)
            fm(f) = max(out.op.finish(ids));
        end
    end

    out.factoryMakespan = fm;
    out.makespan = max(out.op.finish);

    out.cost = compute_tec(out,inst);
    out.objectives = [out.makespan,out.cost.total];

    validate_schedule(out,inst,cfg,true);
end
