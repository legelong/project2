function [lo,hi,arcs] = cut_temporal_bounds(decoded,inst,deadline,cfg)
%CUT_TEMPORAL_BOUNDS Propagate integer start-time lower/upper bounds.

    n = inst.size.totalOperations;

    duration = decoded.op.duration(:);
    lo = zeros(n,1);
    hi = deadline-duration;

    if any(hi<0)
        error('PSAMA:CUTDeadlineTooSmall', ...
            'CUT deadline is smaller than an operation duration.');
    end

    arcs = build_cut_temporal_arcs(decoded,inst);

    maxPass = n+1;

    for pass = 1:maxPass
        changed = false;

        for r = 1:size(arcs,1)
            i = arcs(r,1);
            j = arcs(r,2);
            lag = arcs(r,3);

            v = lo(i)+lag;
            if v>lo(j)
                lo(j) = v;
                changed = true;
            end

            v = hi(j)-lag;
            if v<hi(i)
                hi(i) = v;
                changed = true;
            end
        end

        if any(lo>hi+cfg.decoder.tolerance)
            error('PSAMA:CUTInfeasibleBounds', ...
                'CUT deadline/precedence system is infeasible.');
        end

        if ~changed
            lo = round(lo);
            hi = round(hi);
            return;
        end
    end

    error('PSAMA:CUTPositiveTemporalCycle', ...
        'Temporal bound propagation did not converge.');
end
