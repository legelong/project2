function result = solve_cut_retime(decoded,inst,cfg,deadline)
%SOLVE_CUT_RETIME MATLAB min-cut implementation of fixed-speed global CUT.
%
% No Python call is made.
%
% Requires MATLAB maxflow/digraph.
%
% Optimality scope:
%   fixed factory/machine/order/speed/duration;
%   integer/common-grid start times;
%   deadline supplied by caller.

    if nargin<4 || isempty(deadline)
        deadline = decoded.makespan;
    end

    % maxflow is dispatched as a digraph method in many MATLAB releases.
    % A standalone exist('maxflow','file') test can therefore be false even
    % when maxflow(G,s,t) is available. Capability is smoke-tested by the
    % launcher/self-check instead.
    tAll = tic;

    net = build_cut_network(decoded,inst,cfg,deadline);

    tSolve = tic;

    G = digraph( ...
        net.from,net.to,net.capacity,net.nNodes);

    [mf,~,cs,~] = maxflow(G,net.source,net.sink);

    flowSeconds = toc(tSolve);

    reach = false(net.nNodes,1);
    reach(cs) = true;

    starts = net.lo;

    for g = 1:inst.size.totalOperations
        L = net.lengths(g);

        if L<=0
            continue;
        end

        nodes = (net.offsets(g)+1:net.offsets(g+1))';
        selected = reach(nodes);

        if any(diff(double(selected))>0)
            error('PSAMA:CUTThresholdPrefixViolation', ...
                'Source-side threshold set is not a prefix.');
        end

        starts(g) = starts(g)+sum(selected);
    end

    starts = round(starts);

    out = apply_cut_starts(decoded,starts,inst,cfg);

    directMilli = compute_tec_milli(decoded,starts,inst);
    networkMilli = net.constant+mf;

    if cfg.cut.verifyDirectCost && ...
       abs(directMilli-networkMilli)>1e-6
        error('PSAMA:CUTCostCertificateMismatch', ...
            'Direct milli-cost and min-cut reconstruction differ.');
    end

    if abs(1000*out.cost.total-directMilli)>1e-5
        error('PSAMA:CUTMATLABEvaluatorMismatch', ...
            'CUT milli-cost and compute_tec disagree.');
    end

    % Verify deadline / precedence directly.
    if any(starts+decoded.op.duration(:)>deadline+cfg.decoder.tolerance)
        error('PSAMA:CUTDeadlineViolation', ...
            'CUT returned a schedule beyond the supplied deadline.');
    end

    for r = 1:size(net.arcs,1)
        i = net.arcs(r,1);
        j = net.arcs(r,2);
        lag = net.arcs(r,3);

        if starts(j)<starts(i)+lag-cfg.decoder.tolerance
            error('PSAMA:CUTTemporalViolation', ...
                'CUT returned a temporal-arc violation.');
        end
    end

    result.decoded = out;
    result.starts = starts;

    result.totalTEC = out.cost.total;
    result.costMilli = directMilli;

    result.deadline = deadline;
    result.flowValue = mf;
    result.cutCostMilli = networkMilli;
    result.constantMilli = net.constant;

    result.nodes = net.nNodes;
    result.thresholdNodes = net.nThreshold;
    result.edges = numel(net.capacity);

    result.flowSeconds = flowSeconds;
    result.totalSeconds = toc(tAll);

    result.certificateValid = ...
        abs(directMilli-networkMilli)<=1e-6;
end
