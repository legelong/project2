function price = cut_price_milli(horizon,tariff)
%CUT_PRICE_MILLI Integer milli-price for unit intervals [t,t+1).

    horizon = round(horizon);

    if horizon < 0
        error('PSAMA:CUTBadHorizon','CUT horizon must be nonnegative.');
    end

    price = zeros(horizon,1);

    valley = round(1000*tariff.valleyPrice);
    flat = round(1000*tariff.flatPrice);
    peak = round(1000*tariff.peakPrice);

    for t = 0:horizon-1
        h = mod(t,round(tariff.period));

        isValley = ...
            (h>=tariff.valleyIntervals(1,1) && h<tariff.valleyIntervals(1,2)) || ...
            (h>=tariff.valleyIntervals(2,1) && h<tariff.valleyIntervals(2,2));

        isPeak = ...
            h>=tariff.peakIntervals(1,1) && h<tariff.peakIntervals(1,2);

        if isValley
            price(t+1) = valley;
        elseif isPeak
            price(t+1) = peak;
        else
            price(t+1) = flat;
        end
    end
end
