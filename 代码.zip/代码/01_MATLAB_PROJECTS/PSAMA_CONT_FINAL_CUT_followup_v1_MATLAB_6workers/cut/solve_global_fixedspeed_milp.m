function result = solve_global_fixedspeed_milp(decoded,inst,cfg,deadline)
%SOLVE_GLOBAL_FIXEDSPEED_MILP Independent time-indexed MILP cross-check.
%
% Used only by run_selfcheck. The bridge experiment itself uses CUT/maxflow.

    if exist('intlinprog','file')~=2
        error('PSAMA:MissingOptimizationToolbox', ...
            'intlinprog is required for the independent CUT self-check.');
    end

    [lo,hi,arcs] = cut_temporal_bounds(decoded,inst,deadline,cfg);

    priceMilli = cut_price_milli(deadline,inst.tariff);
    costs = cut_unary_costs(decoded,lo,hi,priceMilli,inst);

    n = inst.size.totalOperations;

    varIdx = cell(n,1);
    starts = cell(n,1);

    totalVars = 0;

    for g = 1:n
        t = (lo(g):hi(g))';
        starts{g} = t;

        varIdx{g} = (totalVars+1:totalVars+numel(t))';
        totalVars = totalVars+numel(t);
    end

    c = zeros(totalVars,1);

    for g = 1:n
        c(varIdx{g}) = costs{g};
    end

    % One-hot equality.
    er = [];
    ec = [];
    ev = [];

    for g = 1:n
        idx = varIdx{g};

        er = [er;repmat(g,numel(idx),1)]; %#ok<AGROW>
        ec = [ec;idx]; %#ok<AGROW>
        ev = [ev;ones(numel(idx),1)]; %#ok<AGROW>
    end

    Aeq = sparse(er,ec,ev,n,totalVars);
    beq = ones(n,1);

    % Precedence:
    % E[start_i] + lag <= E[start_j].
    ir = [];
    ic = [];
    iv = [];
    b = zeros(size(arcs,1),1);

    for r = 1:size(arcs,1)
        i = arcs(r,1);
        j = arcs(r,2);
        lag = arcs(r,3);

        ii = varIdx{i};
        jj = varIdx{j};

        ir = [ir; ...
            repmat(r,numel(ii),1); ...
            repmat(r,numel(jj),1)]; %#ok<AGROW>

        ic = [ic;ii;jj]; %#ok<AGROW>

        iv = [iv; ...
            starts{i}+lag; ...
            -starts{j}]; %#ok<AGROW>
    end

    A = sparse(ir,ic,iv,size(arcs,1),totalVars);

    options = optimoptions('intlinprog', ...
        'Display','off', ...
        'RelativeGapTolerance',cfg.cut.milpRelativeGapTolerance, ...
        'AbsoluteGapTolerance',cfg.cut.milpAbsoluteGapTolerance, ...
        'MaxTime',cfg.cut.milpMaxSolveSeconds);

    tSolve = tic;

    [x,fval,exitflag,output] = intlinprog( ...
        c,1:totalVars,A,b,Aeq,beq, ...
        zeros(totalVars,1),ones(totalVars,1),options);

    solveSeconds = toc(tSolve);

    if isempty(x)
        error('PSAMA:CUTMilpNoSolution', ...
            'Independent fixed-speed MILP returned no incumbent.');
    end

    s = zeros(n,1);

    for g = 1:n
        idx = varIdx{g};
        [mx,k] = max(x(idx));

        if mx<0.5
            error('PSAMA:CUTMilpRecover', ...
                'Could not recover MILP start for operation %d.',g);
        end

        s(g) = starts{g}(k);
    end

    out = apply_cut_starts(decoded,s,inst,cfg);

    if abs(1000*out.cost.total-fval)>1e-5
        error('PSAMA:CUTMilpCostMismatch', ...
            'MILP objective and direct evaluator differ.');
    end

    result.decoded = out;
    result.starts = s;
    result.totalTEC = out.cost.total;
    result.objectiveMilli = fval;
    result.exitflag = exitflag;
    result.relativeGap = getfield_default(output,'relativegap',NaN); %#ok<GFLD>
    result.solveSeconds = solveSeconds;
    result.exactCertified = exitflag==1;
end

function v = getfield_default(S,name,defaultValue)
    if isstruct(S) && isfield(S,name)
        v = S.(name);
    else
        v = defaultValue;
    end
end
