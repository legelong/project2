function arcs = build_cut_temporal_arcs(decoded,inst)
%BUILD_CUT_TEMPORAL_ARCS Fixed job + machine precedence arcs.
%
% Each row:
%   [predecessor, successor, minimum start lag]
%
% Lag equals predecessor duration.

    arcs = zeros(0,3);

    % Job arcs.
    for j = 1:inst.size.numJobs
        nOps = inst.size.operationsPerJob(j);

        for o = 1:nOps-1
            a = inst.map.opGlobalIndex(j,o);
            b = inst.map.opGlobalIndex(j,o+1);

            arcs(end+1,:) = [a,b,decoded.op.duration(a)]; %#ok<AGROW>
        end
    end

    % Fixed machine-order arcs.
    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = decoded.machineSchedules{f,m};
            ids = ids(:);

            for q = 1:numel(ids)-1
                a = ids(q);
                b = ids(q+1);

                arcs(end+1,:) = [a,b,decoded.op.duration(a)]; %#ok<AGROW>
            end
        end
    end

    if ~isempty(arcs)
        arcs = unique(arcs,'rows','stable');
    end
end
