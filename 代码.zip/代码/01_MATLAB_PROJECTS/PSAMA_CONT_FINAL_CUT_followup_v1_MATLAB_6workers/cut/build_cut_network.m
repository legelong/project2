function net = build_cut_network(decoded,inst,cfg,deadline)
%BUILD_CUT_NETWORK Minimum-weight closure network for fixed-speed retiming.
%
% Threshold x_{i,t}=1 iff start_i >= t, for t=lo_i+1,...,hi_i.
%
% Source-side threshold nodes represent selected thresholds.

    deadline = round(deadline);

    priceMilli = cut_price_milli(deadline,inst.tariff);

    [lo,hi,arcs] = cut_temporal_bounds( ...
        decoded,inst,deadline,cfg);

    costs = cut_unary_costs( ...
        decoded,lo,hi,priceMilli,inst);

    nOps = inst.size.totalOperations;

    lengths = hi-lo;
    offsets = zeros(nOps+1,1);
    offsets(2:end) = cumsum(lengths);

    nThreshold = offsets(end);
    source = nThreshold+1;
    sink = nThreshold+2;
    nNodes = nThreshold+2;

    weights = zeros(nThreshold,1);

    for g = 1:nOps
        if lengths(g)>0
            ids = offsets(g)+1:offsets(g+1);
            weights(ids) = diff(costs{g});
        end
    end

    infinity = sum(abs(weights))+1;

    fromChunks = {};
    toChunks = {};
    capChunks = {};
    cc = 0;

    neg = find(weights<0);
    pos = find(weights>0);

    if ~isempty(neg)
        cc=cc+1;
        fromChunks{cc} = source*ones(numel(neg),1);
        toChunks{cc} = neg;
        capChunks{cc} = -weights(neg);
    end

    if ~isempty(pos)
        cc=cc+1;
        fromChunks{cc} = pos;
        toChunks{cc} = sink*ones(numel(pos),1);
        capChunks{cc} = weights(pos);
    end

    % Threshold nesting x_{i,t} => x_{i,t-1}.
    for g = 1:nOps
        L = lengths(g);

        if L>=2
            nodes = (offsets(g)+1:offsets(g+1))';

            cc=cc+1;
            fromChunks{cc} = nodes(2:end);
            toChunks{cc} = nodes(1:end-1);
            capChunks{cc} = infinity*ones(L-1,1);
        end
    end

    % Temporal implication:
    % start_j >= start_i + lag
    % x_{i,t} => x_{j,t+lag}.
    for r = 1:size(arcs,1)
        i = arcs(r,1);
        j = arcs(r,2);
        lag = arcs(r,3);

        begin = max(lo(i)+1,lo(j)-lag+1);

        if begin>hi(i)
            continue;
        end

        t = (begin:hi(i))';
        target = t+lag;

        if any(target>hi(j))
            error('PSAMA:CUTBoundPropagationFailure', ...
                'Successor threshold exceeds propagated upper bound.');
        end

        nodeI = offsets(i)+(t-lo(i));
        nodeJ = offsets(j)+(target-lo(j));

        keep = nodeI~=nodeJ;

        if any(keep)
            cc=cc+1;
            fromChunks{cc} = nodeI(keep);
            toChunks{cc} = nodeJ(keep);
            capChunks{cc} = infinity*ones(sum(keep),1);
        end
    end

    if cc==0
        from = zeros(0,1);
        to = zeros(0,1);
        capacity = zeros(0,1);
    else
        from = vertcat(fromChunks{:});
        to = vertcat(toChunks{:});
        capacity = vertcat(capChunks{:});
    end

    % Aggregate duplicate directed edges exactly.
    A = sparse(from,to,capacity,nNodes,nNodes);
    [from,to,capacity] = find(A);

    baseConstant = 0;

    for g = 1:nOps
        baseConstant = baseConstant+costs{g}(1);
    end

    constant = baseConstant+sum(weights(weights<0));

    net.from = from;
    net.to = to;
    net.capacity = capacity;

    net.nNodes = nNodes;
    net.nThreshold = nThreshold;
    net.source = source;
    net.sink = sink;

    net.lo = lo;
    net.hi = hi;
    net.lengths = lengths;
    net.offsets = offsets;
    net.arcs = arcs;

    net.costs = costs;
    net.weights = weights;
    net.infinity = infinity;
    net.constant = constant;

    net.deadline = deadline;
    net.priceMilli = priceMilli;
end
