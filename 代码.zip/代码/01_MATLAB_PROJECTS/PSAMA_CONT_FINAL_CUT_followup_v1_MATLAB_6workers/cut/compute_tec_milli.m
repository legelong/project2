function costMilli = compute_tec_milli(decoded,starts,inst)
%COMPUTE_TEC_MILLI Direct exact integer-price TEC evaluator.

    starts = round(starts(:));
    durations = decoded.op.duration(:);

    finish = starts+durations;
    horizon = max(finish);

    price = cut_price_milli(horizon,inst.tariff);
    prefix = [0;cumsum(double(price(:)))];

    work = 0;

    for g = 1:inst.size.totalOperations
        p = processing_power(decoded.op.speed(g),inst);

        work = work + p * ...
            (prefix(finish(g)+1)-prefix(starts(g)+1));
    end

    idle = 0;

    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = decoded.machineSchedules{f,m};
            ids = ids(:);

            for q = 1:numel(ids)-1
                a = ids(q);
                b = ids(q+1);

                if starts(b)<finish(a)
                    error('PSAMA:CUTDirectOverlap', ...
                        'Direct CUT evaluator found machine overlap.');
                end

                idle = idle + inst.speed.idlePower * ...
                    (prefix(starts(b)+1)-prefix(finish(a)+1));
            end
        end
    end

    costMilli = work+idle;
end
