function costs = cut_unary_costs(decoded,lo,hi,priceMilli,inst)
%CUT_UNARY_COSTS Exact separable start-time cost in milli-price units.
%
% Implements the endpoint decomposition used by CUT:
%
% c_i(t) =
%   (P_i - P0*hasMachineSuccessor_i) * A(t+d_i)
%   -
%   (P_i - P0*hasMachinePredecessor_i) * A(t)
%
% where A(.) is the cumulative milli-price integral.

    n = inst.size.totalOperations;

    prefix = [0;cumsum(double(priceMilli(:)))];

    hasPrev = zeros(n,1);
    hasNext = zeros(n,1);

    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = decoded.machineSchedules{f,m};
            ids = ids(:);

            for q = 1:numel(ids)-1
                hasNext(ids(q)) = 1;
                hasPrev(ids(q+1)) = 1;
            end
        end
    end

    costs = cell(n,1);

    P0 = inst.speed.idlePower;

    for g = 1:n
        t = (lo(g):hi(g))';
        d = decoded.op.duration(g);
        p = processing_power(decoded.op.speed(g),inst);

        Aend = prefix(t+d+1);
        Astart = prefix(t+1);

        costs{g} = ...
            (p-P0*hasNext(g)).*Aend ...
            - ...
            (p-P0*hasPrev(g)).*Astart;
    end
end
