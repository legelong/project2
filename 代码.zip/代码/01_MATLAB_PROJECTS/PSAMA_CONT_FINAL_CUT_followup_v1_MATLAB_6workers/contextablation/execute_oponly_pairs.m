function [lsPop,archive,model,summary,eventLog,nfeUsed] = ...
    execute_oponly_pairs( ...
        selected,archive,inst,cfg,model,generation,nfeBeforeBatch)
%EXECUTE_OPONLY_PAIRS Parent-reward update with zero solution context.

    lsPop = empty_population_like(inst);
    eventLog = empty_oponly_event_log();
    nfeUsed = 0;

    zeroContext = cfg.contextAblation.zeroContext;

    K = cfg.operators.count;
    summary.selectedByOperator = zeros(K,1);
    summary.positiveRewardByOperator = zeros(K,1);
    summary.rewardByOperator = zeros(K,1);
    summary.archiveChanges = 0;

    for k = 1:numel(selected)
        pair = selected(k);
        nfeBefore = nfeBeforeBatch+nfeUsed;

        [childObjective,childDecoded] = ...
            evaluate_solution(pair.child,inst,cfg);
        nfeUsed = nfeUsed+1;

        rParent = compute_parent_dominance_reward( ...
            pair.sourceObjective,childObjective);

        [rSet,setDetail,~] = compute_set_level_reward( ...
            archive.objectives,childObjective,cfg);

        childPop = empty_population_like(inst);
        childPop = append_evaluated_child( ...
            childPop,pair.child,childObjective,childDecoded);

        archive = update_external_archive(archive,childPop,cfg);
        lsPop = append_evaluated_child( ...
            lsPop,pair.child,childObjective,childDecoded);

        model = linucb_update( ...
            model,pair.operatorId,zeroContext,rParent,cfg);

        a = pair.operatorId;
        summary.selectedByOperator(a) = summary.selectedByOperator(a)+1;
        summary.rewardByOperator(a) = ...
            summary.rewardByOperator(a)+rParent;

        if rParent > 0
            summary.positiveRewardByOperator(a) = ...
                summary.positiveRewardByOperator(a)+1;
        end

        if setDetail.archiveChanged
            summary.archiveChanges = summary.archiveChanges+1;
        end

        e.generation = generation;
        e.nfeBefore = nfeBefore;
        e.nfeAfter = nfeBefore+1;
        e.sourceIndex = pair.sourceIndex;
        e.operatorId = pair.operatorId;
        e.predictedMean = pair.predictedMean;
        e.uncertainty = pair.uncertainty;
        e.pairScore = pair.score;
        e.sourceObjective = pair.sourceObjective;
        e.childObjective = childObjective;
        e.parentReward = rParent;
        e.setGain = rSet;
        e.archiveChanged = setDetail.archiveChanged;
        e.enteredNextPopulationF1 = false;

        eventLog(end+1,1) = e; %#ok<AGROW>
    end

    lsPop.nfe = nfeUsed;
end
