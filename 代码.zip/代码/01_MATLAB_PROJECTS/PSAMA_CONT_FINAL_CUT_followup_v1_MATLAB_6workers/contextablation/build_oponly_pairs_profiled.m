function [pairs,profile] = build_oponly_pairs_profiled( ...
    pop,pool,archive,inst,cfg,model)
%BUILD_OPONLY_PAIRS_PROFILED Joint candidate pairs without solution context.
%
% This is the clean information ablation:
%
% FINAL_JOINT:
%   x = [1; actual 8-D context]
%
% OPONLY_JOINT:
%   x = [1; zeros(8,1)]
%
% The LinUCB model dimension, ridge, alpha, per-operator separation, operator
% proposals, pair set, and Joint allocator remain unchanged.
%
% Consequently, all feasible pairs using the same operator have the same model
% score before the random tie key. Solution identity has no learned value.

    if isempty(archive) || isempty(archive.objectives)
        error('PSAMA:EmptyArchive', ...
            'Operator-only allocation requires a nonempty archive.');
    end

    zeroContext = cfg.contextAblation.zeroContext;
    catalog = operator_catalog(cfg);

    template = struct( ...
        'sourceIndex',NaN, ...
        'sourceType','', ...
        'recoveryScore',NaN, ...
        'sourceObjective',[], ...
        'operatorId',NaN, ...
        'operatorName','', ...
        'context',[], ...
        'score',NaN, ...
        'predictedMean',NaN, ...
        'uncertainty',NaN, ...
        'tieKey',NaN, ...
        'child',[], ...
        'operatorMeta',[]);

    pairs = repmat(template,0,1);

    profile.contextTime = 0;
    profile.operatorProposalTime = 0;
    profile.scoringTime = 0;
    profile.sources = numel(pool.indices);
    profile.operatorAttempts = 0;
    profile.feasiblePairs = 0;

    for q = 1:numel(pool.indices)
        idx = pool.indices(q);

        if isempty(pop.decoded{idx})
            error('PSAMA:MissingDecodedCache', ...
                'Pair construction requires decoded schedules.');
        end

        decoded = pop.decoded{idx};
        objective = pop.objectives(idx,:);

        for opId = 1:cfg.operators.count
            profile.operatorAttempts = profile.operatorAttempts+1;

            t = tic;
            [child,meta] = apply_operator( ...
                opId,pop.chromosomes(idx,:),decoded,inst,cfg);
            profile.operatorProposalTime = ...
                profile.operatorProposalTime+toc(t);

            if ~meta.changed
                continue;
            end

            t = tic;
            [score,mu,u] = linucb_score( ...
                model,opId,zeroContext,cfg);
            profile.scoringTime = profile.scoringTime+toc(t);

            item = template;
            item.sourceIndex = idx;
            item.sourceType = pool.sourceType{q};
            item.recoveryScore = pool.recoveryScore(q);
            item.sourceObjective = objective;
            item.operatorId = opId;
            item.operatorName = catalog(opId).name;
            item.context = zeroContext;
            item.score = score;
            item.predictedMean = mu;
            item.uncertainty = u;

            if cfg.learning.randomTieBreak
                item.tieKey = rand();
            else
                item.tieKey = opId;
            end

            item.child = child;
            item.operatorMeta = meta;

            pairs(end+1,1) = item; %#ok<AGROW>
        end
    end

    profile.feasiblePairs = numel(pairs);
end
