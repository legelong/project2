function B = compute_schedule_tou_breakdown(decoded,inst)
%COMPUTE_SCHEDULE_TOU_BREAKDOWN Processing+idle energy/cost by TOU band.

    procE = zeros(1,3);
    idleE = zeros(1,3);

    for g = 1:inst.size.totalOperations
        power = processing_power(decoded.op.speed(g),inst);

        band = integrate_energy_by_tariff_band( ...
            power,decoded.op.start(g),decoded.op.duration(g),inst.tariff);

        procE = procE+[band.valley,band.flat,band.peak];
    end

    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = decoded.machineSchedules{f,m};

            if isempty(ids)
                continue;
            end

            ids = ids(:);

            for q = 1:numel(ids)-1
                a = ids(q);
                b = ids(q+1);

                idleStart = decoded.op.finish(a);
                idleDuration = decoded.op.start(b)-idleStart;

                if idleDuration < -1e-9
                    error('PSAMA:BreakdownOverlap', ...
                        'Negative machine idle interval.');
                end

                idleDuration = max(0,idleDuration);

                band = integrate_energy_by_tariff_band( ...
                    inst.speed.idlePower,idleStart,idleDuration,inst.tariff);

                idleE = idleE+[band.valley,band.flat,band.peak];
            end
        end
    end

    prices = [ ...
        inst.tariff.valleyPrice, ...
        inst.tariff.flatPrice, ...
        inst.tariff.peakPrice];

    procCost = procE.*prices;
    idleCost = idleE.*prices;
    totalE = procE+idleE;
    totalCost = procCost+idleCost;

    B.processingEnergy.valley = procE(1);
    B.processingEnergy.flat = procE(2);
    B.processingEnergy.peak = procE(3);
    B.processingEnergy.total = sum(procE);

    B.idleEnergy.valley = idleE(1);
    B.idleEnergy.flat = idleE(2);
    B.idleEnergy.peak = idleE(3);
    B.idleEnergy.total = sum(idleE);

    B.totalEnergy.valley = totalE(1);
    B.totalEnergy.flat = totalE(2);
    B.totalEnergy.peak = totalE(3);
    B.totalEnergy.total = sum(totalE);

    B.processingCost.valley = procCost(1);
    B.processingCost.flat = procCost(2);
    B.processingCost.peak = procCost(3);
    B.processingCost.total = sum(procCost);

    B.idleCost.valley = idleCost(1);
    B.idleCost.flat = idleCost(2);
    B.idleCost.peak = idleCost(3);
    B.idleCost.total = sum(idleCost);

    B.totalCost.valley = totalCost(1);
    B.totalCost.flat = totalCost(2);
    B.totalCost.peak = totalCost(3);
    B.totalCost.total = sum(totalCost);

    exact = compute_tec(decoded,inst);

    if abs(B.totalCost.total-exact.total)>1e-8
        error('PSAMA:BreakdownCostMismatch', ...
            'Band decomposition does not match compute_tec.');
    end
end
