function report = validate_instance(inst, throwOnError)
%VALIDATE_INSTANCE Validate one unified PSA-MA instance structure.
%
% report = validate_instance(inst, false)
% validate_instance(inst, true)  % throws if invalid

    if nargin < 2
        throwOnError = true;
    end

    errors = {};
    warnings = {};

    requiredTop = {'meta','size','process','map','encoding','speed','tariff','stats'};
    for i = 1:numel(requiredTop)
        if ~isfield(inst, requiredTop{i})
            errors{end+1} = sprintf('Missing top-level field: %s', requiredTop{i}); %#ok<AGROW>
        end
    end

    if ~isempty(errors)
        report = finish_report(errors, warnings, throwOnError);
        return;
    end

    J = inst.size.numJobs;
    F = inst.size.numFactories;
    opsPerJob = inst.size.operationsPerJob(:);
    Mvec = inst.size.numMachinesPerFactory(:)';

    if J <= 0 || F <= 0
        errors{end+1} = 'Number of jobs/factories must be positive.';
    end

    if numel(opsPerJob) ~= J || any(opsPerJob <= 0)
        errors{end+1} = 'operationsPerJob must contain one positive entry per job.';
    end

    if numel(Mvec) ~= F || any(Mvec <= 0)
        errors{end+1} = 'numMachinesPerFactory must contain one positive entry per factory.';
    end

    if inst.size.totalOperations ~= sum(opsPerJob)
        errors{end+1} = 'totalOperations does not equal sum(operationsPerJob).';
    end

    if inst.encoding.lengthFS ~= J || ...
       inst.encoding.lengthOS ~= inst.size.totalOperations || ...
       inst.encoding.lengthMS ~= inst.size.totalOperations || ...
       inst.encoding.lengthVS ~= inst.size.totalOperations || ...
       inst.encoding.totalLength ~= J + 3*inst.size.totalOperations
        errors{end+1} = 'Chromosome segment lengths are inconsistent with problem size.';
    end

    maxOps = inst.size.maxOperationsPerJob;
    maxM = max(Mvec);

    expectedDenseSize = [F, J, maxOps, maxM];
    if ~isequal(size4(inst.process.eligibleMask), expectedDenseSize)
        errors{end+1} = sprintf( ...
            'eligibleMask size mismatch. Expected [%s], found [%s].', ...
            num2str(expectedDenseSize), num2str(size4(inst.process.eligibleMask)));
    end

    if ~isequal(size4(inst.process.baseTimeDense), expectedDenseSize)
        errors{end+1} = 'baseTimeDense size mismatch.';
    end

    if isempty(errors)
        for f = 1:F
            M = Mvec(f);
            for j = 1:J
                for o = 1:opsPerJob(j)
                    machineIds = inst.process.eligibleMachines{f,j,o};
                    pTimes = inst.process.baseTimeByEligible{f,j,o};

                    if isempty(machineIds)
                        errors{end+1} = sprintf( ...
                            'Empty eligible-machine set at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                        continue;
                    end

                    if numel(machineIds) ~= numel(pTimes)
                        errors{end+1} = sprintf( ...
                            'Machine/time length mismatch at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                    end

                    if numel(unique(machineIds)) ~= numel(machineIds)
                        errors{end+1} = sprintf( ...
                            'Duplicate machine ID at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                    end

                    if any(machineIds < 1) || any(machineIds > M)
                        errors{end+1} = sprintf( ...
                            'Machine ID out of range at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                    end

                    if any(~isfinite(pTimes)) || any(pTimes <= 0)
                        errors{end+1} = sprintf( ...
                            'Invalid baseline time at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                    end

                    denseMask = reshape(inst.process.eligibleMask(f,j,o,:), 1, []);
                    denseTime = reshape(inst.process.baseTimeDense(f,j,o,:), 1, []);

                    expectedMask = false(1, maxM);
                    expectedMask(machineIds) = true;

                    if ~isequal(denseMask, expectedMask)
                        errors{end+1} = sprintf( ...
                            'Cell/dense eligibility mismatch at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                    end

                    if any(denseTime(machineIds) ~= pTimes)
                        errors{end+1} = sprintf( ...
                            'Cell/dense processing-time mismatch at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                    end

                    inactive = ~expectedMask;
                    if any(~isnan(denseTime(inactive)))
                        errors{end+1} = sprintf( ...
                            'Ineligible machines must have NaN base time at f=%d,j=%d,o=%d.', f,j,o); %#ok<AGROW>
                    end
                end
            end
        end
    end

    % Validate global operation mapping.
    totalOps = inst.size.totalOperations;
    if numel(inst.map.globalToJob) ~= totalOps || ...
       numel(inst.map.globalToOperation) ~= totalOps
        errors{end+1} = 'Global operation mapping has wrong length.';
    else
        seen = false(totalOps,1);
        for j = 1:J
            for o = 1:opsPerJob(j)
                g = inst.map.opGlobalIndex(j,o);
                if g < 1 || g > totalOps
                    errors{end+1} = sprintf( ...
                        'Invalid global operation index for j=%d,o=%d.',j,o); %#ok<AGROW>
                else
                    seen(g) = true;
                    if inst.map.globalToJob(g) ~= j || ...
                       inst.map.globalToOperation(g) ~= o
                        errors{end+1} = sprintf( ...
                            'Global operation mapping is not bijective at g=%d.',g); %#ok<AGROW>
                    end
                end
            end
        end
        if ~all(seen)
            errors{end+1} = 'Not every global operation index is used exactly once.';
        end
    end

    % Speed model.
    speeds = inst.speed.levels(:)';
    if isempty(speeds) || any(~isfinite(speeds)) || any(speeds <= 0)
        errors{end+1} = 'Speed levels must be finite positive values.';
    end
    if numel(unique(speeds)) ~= numel(speeds)
        errors{end+1} = 'Speed levels must be unique.';
    end
    if inst.speed.processingPowerCoefficient <= 0 || inst.speed.idlePower < 0
        errors{end+1} = 'Power parameters are invalid.';
    end
    if inst.speed.minDuration <= 0
        errors{end+1} = 'Minimum duration must be positive.';
    end

    % Tariff model.
    if inst.tariff.period <= 0 || inst.tariff.flatPrice <= 0
        errors{end+1} = 'Tariff period and flat price must be positive.';
    end

    intervalSets = {inst.tariff.valleyIntervals, inst.tariff.peakIntervals};
    intervalNames = {'valley','peak'};
    for q = 1:numel(intervalSets)
        X = intervalSets{q};
        if size(X,2) ~= 2
            errors{end+1} = sprintf('%sIntervals must be N-by-2.', intervalNames{q}); %#ok<AGROW>
        else
            if any(X(:,1) < 0) || any(X(:,2) > inst.tariff.period) || ...
               any(X(:,1) >= X(:,2))
                errors{end+1} = sprintf('Invalid %s tariff interval.', intervalNames{q}); %#ok<AGROW>
            end
        end
    end

    if intervals_overlap(inst.tariff.valleyIntervals, inst.tariff.peakIntervals)
        errors{end+1} = 'Valley and peak tariff intervals overlap.';
    end

    if inst.stats.totalEligibleAlternatives ~= nnz(inst.process.eligibleMask)
        errors{end+1} = 'totalEligibleAlternatives statistic is inconsistent.';
    end

    if ~inst.stats.processingTimesVaryAcrossFactories && F > 1
        warnings{end+1} = ...
            'Processing times do not vary across factories; instance may be homogeneous.'; %#ok<AGROW>
    end

    report = finish_report(errors, warnings, throwOnError);
end

function s = size4(A)
    s = size(A);
    if numel(s) < 4
        s(end+1:4) = 1;
    elseif numel(s) > 4
        s = s(1:4);
    end
end

function tf = intervals_overlap(A, B)
    tf = false;
    for i = 1:size(A,1)
        for j = 1:size(B,1)
            if max(A(i,1), B(j,1)) < min(A(i,2), B(j,2))
                tf = true;
                return;
            end
        end
    end
end

function report = finish_report(errors, warnings, throwOnError)
    report.ok = isempty(errors);
    report.errors = errors;
    report.warnings = warnings;

    if throwOnError && ~report.ok
        message = strjoin(errors, newline);
        error('PSAMA:InvalidInstance', '%s', message);
    end
end
