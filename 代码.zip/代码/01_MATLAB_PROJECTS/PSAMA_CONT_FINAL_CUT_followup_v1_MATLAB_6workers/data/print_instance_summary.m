function print_instance_summary(inst)
%PRINT_INSTANCE_SUMMARY Human-readable confirmation of parsed data.

    fprintf('\n========== PSA-MA Instance Summary ==========\n');
    fprintf('Name                    : %s\n', inst.meta.name);
    fprintf('Source                  : %s\n', inst.meta.sourceFile);
    fprintf('Jobs                    : %d\n', inst.size.numJobs);
    fprintf('Factories               : %d\n', inst.size.numFactories);
    fprintf('Machines / factory      : %s\n', mat2str(inst.size.numMachinesPerFactory));
    fprintf('Operations / job        : min %d, max %d\n', ...
        min(inst.size.operationsPerJob), max(inst.size.operationsPerJob));
    fprintf('Total operations        : %d\n', inst.size.totalOperations);
    fprintf('Eligible machines / op  : min %d, max %d\n', ...
        inst.stats.minEligibleMachineCount, ...
        inst.stats.maxEligibleMachineCount);
    fprintf('Baseline processing time: min %g, max %g\n', ...
        inst.stats.minBaselineProcessingTime, ...
        inst.stats.maxBaselineProcessingTime);
    fprintf('Total alternatives      : %d\n', ...
        inst.stats.totalEligibleAlternatives);
    fprintf('Sum baseline times      : %.0f\n', ...
        inst.stats.sumBaselineProcessingTimes);
    fprintf('Shared eligibility      : %s\n', ...
        yesno(inst.stats.eligibilitySharedAcrossFactories));
    fprintf('Factory PT heterogeneity: %s\n', ...
        yesno(inst.stats.processingTimesVaryAcrossFactories));
    fprintf('Speed levels            : %s\n', mat2str(inst.speed.levels));
    fprintf('TOU valley price        : %.3f\n', inst.tariff.valleyPrice);
    fprintf('TOU flat price          : %.3f\n', inst.tariff.flatPrice);
    fprintf('TOU peak price          : %.3f\n', inst.tariff.peakPrice);
    fprintf('Valley intervals        : %s\n', mat2str(inst.tariff.valleyIntervals));
    fprintf('Peak intervals          : %s\n', mat2str(inst.tariff.peakIntervals));
    fprintf('Genome length           : %d = %d + %d + %d + %d\n', ...
        inst.encoding.totalLength, ...
        inst.encoding.lengthFS, inst.encoding.lengthOS, ...
        inst.encoding.lengthMS, inst.encoding.lengthVS);
    fprintf('=============================================\n\n');
end

function s = yesno(tf)
    if tf
        s = 'YES';
    else
        s = 'NO';
    end
end
