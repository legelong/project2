function [names, paths] = list_dhfjsp_instances(instanceDir)
%LIST_DHFJSP_INSTANCES List the 20 benchmark DHFJSP files in natural order.
%
% realworld.txt is intentionally excluded because it is not one of the
% 20 benchmark instances used in the main numerical study.

    D = dir(fullfile(instanceDir, '*.txt'));

    names = {};
    paths = {};
    keys = [];

    for i = 1:numel(D)
        [~, name, ~] = fileparts(D(i).name);

        token = regexp(name, '^(\d+)J(\d+)F$', 'tokens', 'once');
        if isempty(token)
            continue;
        end

        J = str2double(token{1});
        F = str2double(token{2});

        names{end+1,1} = name; %#ok<AGROW>
        paths{end+1,1} = fullfile(instanceDir, D(i).name); %#ok<AGROW>
        keys(end+1,:) = [J, F]; %#ok<AGROW>
    end

    if isempty(names)
        return;
    end

    [~, order] = sortrows(keys, [1,2]);
    names = names(order);
    paths = paths(order);
end
