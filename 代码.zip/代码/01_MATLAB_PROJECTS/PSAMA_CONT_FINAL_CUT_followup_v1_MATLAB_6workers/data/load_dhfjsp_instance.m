function inst = load_dhfjsp_instance(filePath, cfg)
%LOAD_DHFJSP_INSTANCE Robust reader for the current 20 DHFJSP *.txt files.
%
% File structure actually used by the supplied data:
%   line 1:  numJobs  numFactories  numMachinesPerFactory
%
% Then exactly F*J blocks. Each block starts with:
%   factoryId  jobId  numOperations
%
% followed by numOperations lines:
%   operationId  numEligibleMachines  machine1 time1 machine2 time2 ...
%
% Unlike the legacy DataReadDHFJSP.m, this reader:
%   1) does not rely on integer-position skipping;
%   2) validates factory/job/operation IDs explicitly;
%   3) supports factory-specific eligible-machine sets;
%   4) creates one common dense representation for all later algorithms.
%
% Usage:
%   cfg  = make_shared_config('...\instance');
%   inst = load_dhfjsp_instance('...\instance\10J2F.txt', cfg);

    if nargin < 2 || isempty(cfg)
        cfg = make_shared_config();
    end

    if ~isfile(filePath)
        error('PSAMA:FileNotFound', 'Instance file not found: %s', filePath);
    end

    fid = fopen(filePath, 'r');
    if fid < 0
        error('PSAMA:OpenFailed', 'Cannot open instance file: %s', filePath);
    end
    cleaner = onCleanup(@() fclose(fid));

    headerLine = next_nonempty_line(fid);
    if isempty(headerLine)
        error('PSAMA:EmptyFile', 'Instance file is empty: %s', filePath);
    end

    header = parse_integer_line(headerLine);
    if numel(header) < 3
        error('PSAMA:BadHeader', ...
              'First non-empty line must contain J F M: %s', filePath);
    end

    J = header(1);
    F = header(2);
    M = header(3);

    if J <= 0 || F <= 0 || M <= 0
        error('PSAMA:BadHeaderValue', 'J, F, and M must all be positive.');
    end

    seenBlock = false(F, J);
    opsPerJob = zeros(J, 1);

    % Temporary representation:
    % tempMachines{f,j}{o} -> machine IDs
    % tempTimes{f,j}{o}    -> baseline processing times aligned with IDs
    tempMachines = cell(F, J);
    tempTimes = cell(F, J);

    expectedBlocks = F * J;

    for block = 1:expectedBlocks
        blockLine = next_nonempty_line(fid);
        if isempty(blockLine)
            error('PSAMA:UnexpectedEOF', ...
                  'Unexpected EOF while reading block %d/%d in %s.', ...
                  block, expectedBlocks, filePath);
        end

        blockHeader = parse_integer_line(blockLine);
        if numel(blockHeader) ~= 3
            error('PSAMA:BadBlockHeader', ...
                  ['Each job/factory block header must contain exactly ' ...
                   '[factoryId jobId numOperations]. File: %s; line: %s'], ...
                  filePath, blockLine);
        end

        f = blockHeader(1);
        j = blockHeader(2);
        nOps = blockHeader(3);

        if f < 1 || f > F || j < 1 || j > J || nOps <= 0
            error('PSAMA:BadBlockValue', ...
                  'Invalid block header [%d %d %d] in %s.', ...
                  f, j, nOps, filePath);
        end

        if seenBlock(f, j)
            error('PSAMA:DuplicateBlock', ...
                  'Duplicate block for factory %d, job %d.', f, j);
        end
        seenBlock(f, j) = true;

        if opsPerJob(j) == 0
            opsPerJob(j) = nOps;
        elseif opsPerJob(j) ~= nOps
            error('PSAMA:InconsistentOperations', ...
                  ['Job %d has %d operations in an earlier factory but %d ' ...
                   'operations in factory %d.'], ...
                  j, opsPerJob(j), nOps, f);
        end

        opMachines = cell(1, nOps);
        opTimes = cell(1, nOps);

        for o = 1:nOps
            opLine = next_nonempty_line(fid);
            if isempty(opLine)
                error('PSAMA:UnexpectedEOF', ...
                      'Unexpected EOF at factory %d, job %d, operation %d.', ...
                      f, j, o);
            end

            row = parse_integer_line(opLine);
            if numel(row) < 4
                error('PSAMA:BadOperationLine', ...
                      'Operation line too short: %s', opLine);
            end

            opId = row(1);
            K = row(2);

            if opId ~= o
                error('PSAMA:OperationOrder', ...
                      ['Expected operation ID %d but found %d ' ...
                       '(factory %d, job %d).'], o, opId, f, j);
            end

            if K <= 0
                error('PSAMA:NoEligibleMachine', ...
                      'Operation (%d,%d,%d) has no eligible machine.', ...
                      f, j, o);
            end

            expectedLength = 2 + 2*K;
            if numel(row) ~= expectedLength
                error('PSAMA:BadOperationLength', ...
                      ['Operation (%d,%d,%d): K=%d requires %d integers, ' ...
                       'but %d were found.'], ...
                      f, j, o, K, expectedLength, numel(row));
            end

            machineIds = row(3:2:end);
            processingTimes = row(4:2:end);

            if numel(unique(machineIds)) ~= numel(machineIds)
                error('PSAMA:DuplicateMachine', ...
                      'Duplicate eligible machine in operation (%d,%d,%d).', ...
                      f, j, o);
            end

            if any(machineIds < 1) || any(machineIds > M)
                error('PSAMA:MachineOutOfRange', ...
                      ['Machine ID outside 1..%d in operation ' ...
                       '(factory %d, job %d, operation %d).'], ...
                      M, f, j, o);
            end

            if any(processingTimes <= 0)
                error('PSAMA:BadProcessingTime', ...
                      'Non-positive processing time in (%d,%d,%d).', ...
                      f, j, o);
            end

            opMachines{o} = machineIds(:)';
            opTimes{o} = processingTimes(:)';
        end

        tempMachines{f, j} = opMachines;
        tempTimes{f, j} = opTimes;
    end

    % There should be no additional non-empty data.
    extraLine = next_nonempty_line(fid);
    if ~isempty(extraLine)
        error('PSAMA:ExtraData', ...
              'Unexpected extra non-empty data after F*J blocks: %s', extraLine);
    end

    if ~all(seenBlock(:))
        error('PSAMA:MissingBlock', ...
              'At least one factory/job block is missing from %s.', filePath);
    end

    if any(opsPerJob <= 0)
        error('PSAMA:MissingJob', 'At least one job has no operation data.');
    end

    maxOps = max(opsPerJob);
    totalOps = sum(opsPerJob);

    eligibleMachines = cell(F, J, maxOps);
    baseTimeByEligible = cell(F, J, maxOps);

    eligibleMask = false(F, J, maxOps, M);
    baseTimeDense = nan(F, J, maxOps, M);

    minCandidates = inf;
    maxCandidates = -inf;
    minBaseTime = inf;
    maxBaseTime = -inf;

    for f = 1:F
        for j = 1:J
            for o = 1:opsPerJob(j)
                machineIds = tempMachines{f, j}{o};
                pTimes = tempTimes{f, j}{o};

                eligibleMachines{f, j, o} = machineIds;
                baseTimeByEligible{f, j, o} = pTimes;

                eligibleMask(f, j, o, machineIds) = true;
                for k = 1:numel(machineIds)
                    baseTimeDense(f, j, o, machineIds(k)) = pTimes(k);
                end

                minCandidates = min(minCandidates, numel(machineIds));
                maxCandidates = max(maxCandidates, numel(machineIds));
                minBaseTime = min(minBaseTime, min(pTimes));
                maxBaseTime = max(maxBaseTime, max(pTimes));
            end
        end
    end

    % Global operation indexing in fixed [job ascending, operation ascending]
    % order. This will later be shared by MS/VS chromosome segments.
    opGlobalIndex = zeros(J, maxOps);
    globalToJob = zeros(totalOps, 1);
    globalToOperation = zeros(totalOps, 1);

    g = 0;
    for j = 1:J
        for o = 1:opsPerJob(j)
            g = g + 1;
            opGlobalIndex(j, o) = g;
            globalToJob(g) = j;
            globalToOperation(g) = o;
        end
    end

    [~, instanceName, ext] = fileparts(filePath);

    inst.meta.name = instanceName;
    inst.meta.sourceFile = filePath;
    inst.meta.sourceExtension = ext;
    inst.meta.sourceFormat = 'DHFJSP_TXT_FJO_BLOCKS';
    inst.meta.schemaVersion = cfg.project.schemaVersion;

    inst.size.numJobs = J;
    inst.size.numFactories = F;
    inst.size.numMachinesPerFactory = M * ones(1, F);
    inst.size.maxOperationsPerJob = maxOps;
    inst.size.operationsPerJob = opsPerJob;
    inst.size.totalOperations = totalOps;

    inst.process.eligibleMachines = eligibleMachines;
    inst.process.baseTimeByEligible = baseTimeByEligible;
    inst.process.eligibleMask = eligibleMask;
    inst.process.baseTimeDense = baseTimeDense;

    inst.map.opGlobalIndex = opGlobalIndex;
    inst.map.globalToJob = globalToJob;
    inst.map.globalToOperation = globalToOperation;

    % Chromosome segment lengths are part of the COMMON problem definition,
    % not algorithm-specific settings.
    inst.encoding.lengthFS = J;
    inst.encoding.lengthOS = totalOps;
    inst.encoding.lengthMS = totalOps;
    inst.encoding.lengthVS = totalOps;
    inst.encoding.totalLength = J + 3*totalOps;

    % Attach the shared problem settings. No algorithm should redefine these.
    inst.speed.levels = cfg.problem.speedLevels(:)';
    inst.speed.processingPowerCoefficient = ...
        cfg.problem.processingPowerCoefficient;
    inst.speed.idlePower = cfg.problem.idlePower;
    inst.speed.durationRounding = cfg.problem.durationRounding;
    inst.speed.minDuration = cfg.problem.minDuration;

    inst.tariff = cfg.tariff;

    inst.stats.minEligibleMachineCount = minCandidates;
    inst.stats.maxEligibleMachineCount = maxCandidates;
    inst.stats.minBaselineProcessingTime = minBaseTime;
    inst.stats.maxBaselineProcessingTime = maxBaseTime;
    inst.stats.totalEligibleAlternatives = nnz(eligibleMask);
    inst.stats.sumBaselineProcessingTimes = ...
        sum(baseTimeDense(eligibleMask));

    inst.stats.eligibilitySharedAcrossFactories = ...
        check_shared_eligibility(eligibleMachines, F, J, opsPerJob);

    inst.stats.processingTimesVaryAcrossFactories = ...
        check_processing_time_heterogeneity( ...
            eligibleMachines, baseTimeByEligible, F, J, opsPerJob);

    % Validate immediately: corrupted input must fail before any algorithm runs.
    validate_instance(inst, true);
end

function values = parse_integer_line(line)
    values = sscanf(line, '%d')';
end

function line = next_nonempty_line(fid)
    line = '';
    while true
        raw = fgetl(fid);
        if ~ischar(raw)
            return;
        end
        raw = strtrim(raw);
        if ~isempty(raw)
            line = raw;
            return;
        end
    end
end

function tf = check_shared_eligibility(eligibleMachines, F, J, opsPerJob)
    tf = true;
    for j = 1:J
        for o = 1:opsPerJob(j)
            reference = eligibleMachines{1, j, o};
            for f = 2:F
                if ~isequal(reference, eligibleMachines{f, j, o})
                    tf = false;
                    return;
                end
            end
        end
    end
end

function tf = check_processing_time_heterogeneity( ...
    eligibleMachines, baseTimeByEligible, F, J, opsPerJob)

    tf = false;

    if F <= 1
        return;
    end

    for j = 1:J
        for o = 1:opsPerJob(j)
            refMachines = eligibleMachines{1, j, o};
            refTimes = baseTimeByEligible{1, j, o};

            for f = 2:F
                machinesF = eligibleMachines{f, j, o};
                timesF = baseTimeByEligible{f, j, o};

                if ~isequal(refMachines, machinesF) || ~isequal(refTimes, timesF)
                    tf = true;
                    return;
                end
            end
        end
    end
end
