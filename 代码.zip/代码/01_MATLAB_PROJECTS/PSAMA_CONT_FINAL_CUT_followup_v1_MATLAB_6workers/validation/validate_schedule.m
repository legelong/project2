function report = validate_schedule(decoded, inst, cfg, throwOnError)
%VALIDATE_SCHEDULE Independent feasibility/objective consistency checker.
%
% Checks:
%   1. every operation scheduled exactly once;
%   2. job factory consistency;
%   3. machine eligibility;
%   4. speed validity;
%   5. processing duration consistency;
%   6. technological precedence;
%   7. no overlap on each physical (factory,machine);
%   8. factory/system makespan consistency;
%   9. TEC recomputation consistency.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end
    if nargin < 4
        throwOnError = true;
    end

    tol = cfg.decoder.tolerance;
    errors = {};

    totalOps = inst.size.totalOperations;
    J = inst.size.numJobs;
    F = inst.size.numFactories;
    Mvec = inst.size.numMachinesPerFactory(:)';
    opsPerJob = inst.size.operationsPerJob(:);

    op = decoded.op;

    vectors = {'globalId','job','operation','factory','machine', ...
               'speed','baseTime','duration','start','finish','osPriority'};

    for i = 1:numel(vectors)
        name = vectors{i};
        if ~isfield(op, name) || numel(op.(name)) ~= totalOps
            errors{end+1} = sprintf( ...
                'Operation vector "%s" missing or wrong length.', name); %#ok<AGROW>
        end
    end

    if ~isempty(errors)
        report = finish_report(errors, throwOnError);
        return;
    end

    % --------------------------------------------------------------
    % Per-operation checks
    % --------------------------------------------------------------
    for g = 1:totalOps
        j = inst.map.globalToJob(g);
        o = inst.map.globalToOperation(g);
        f = decoded.parts.FS(j);

        if op.globalId(g) ~= g || op.job(g) ~= j || op.operation(g) ~= o
            errors{end+1} = sprintf( ...
                'Operation mapping mismatch at global op %d.', g); %#ok<AGROW>
        end

        if op.factory(g) ~= f
            errors{end+1} = sprintf( ...
                'Factory mismatch at global op %d.', g); %#ok<AGROW>
        end

        eligible = inst.process.eligibleMachines{f,j,o};
        if ~ismember(op.machine(g), eligible)
            errors{end+1} = sprintf( ...
                'Ineligible machine at global op %d.', g); %#ok<AGROW>
        end

        if ~any(abs(inst.speed.levels - op.speed(g)) <= tol)
            errors{end+1} = sprintf( ...
                'Illegal speed at global op %d.', g); %#ok<AGROW>
        end

        expectedBase = inst.process.baseTimeDense(f,j,o,op.machine(g));
        if abs(op.baseTime(g) - expectedBase) > tol
            errors{end+1} = sprintf( ...
                'Baseline processing time mismatch at global op %d.', g); %#ok<AGROW>
        end

        expectedDuration = processing_duration( ...
            expectedBase, op.speed(g), inst);

        if abs(op.duration(g) - expectedDuration) > tol
            errors{end+1} = sprintf( ...
                'Duration mismatch at global op %d.', g); %#ok<AGROW>
        end

        if op.start(g) < -tol
            errors{end+1} = sprintf( ...
                'Negative start time at global op %d.', g); %#ok<AGROW>
        end

        if abs(op.finish(g) - (op.start(g) + op.duration(g))) > tol
            errors{end+1} = sprintf( ...
                'Finish=start+duration violated at global op %d.', g); %#ok<AGROW>
        end
    end

    % --------------------------------------------------------------
    % Job technological precedence
    % --------------------------------------------------------------
    for j = 1:J
        for o = 2:opsPerJob(j)
            gPrev = inst.map.opGlobalIndex(j,o-1);
            gCurr = inst.map.opGlobalIndex(j,o);

            if op.start(gCurr) < op.finish(gPrev) - tol
                errors{end+1} = sprintf( ...
                    'Job precedence violated: J%d O%d starts before O%d finishes.', ...
                    j,o,o-1); %#ok<AGROW>
            end
        end
    end

    % --------------------------------------------------------------
    % Machine schedule: uniqueness + no overlap
    % --------------------------------------------------------------
    seen = zeros(totalOps,1);

    for f = 1:F
        for m = 1:Mvec(f)
            ids = decoded.machineSchedules{f,m};
            if isempty(ids)
                continue;
            end

            ids = ids(:);
            if any(ids < 1) || any(ids > totalOps) || any(ids ~= round(ids))
                errors{end+1} = sprintf( ...
                    'Invalid global operation ID on factory %d machine %d.', ...
                    f,m); %#ok<AGROW>
                continue;
            end

            seen(ids) = seen(ids) + 1;

            [~, order] = sort(op.start(ids), 'ascend');
            ids = ids(order);

            for q = 1:numel(ids)
                g = ids(q);
                if op.factory(g) ~= f || op.machine(g) ~= m
                    errors{end+1} = sprintf( ...
                        'Machine schedule membership mismatch for op %d.', g); %#ok<AGROW>
                end
            end

            for q = 1:numel(ids)-1
                g1 = ids(q);
                g2 = ids(q+1);

                if op.start(g2) < op.finish(g1) - tol
                    errors{end+1} = sprintf( ...
                        ['Machine overlap: factory %d machine %d, ' ...
                         'op %d and op %d.'], ...
                         f,m,g1,g2); %#ok<AGROW>
                end
            end
        end
    end

    if any(seen ~= 1)
        bad = find(seen ~= 1, 1, 'first');
        errors{end+1} = sprintf( ...
            'Global operation %d appears %d times in machine schedules.', ...
            bad, seen(bad)); %#ok<AGROW>
    end

    % --------------------------------------------------------------
    % Makespan consistency
    % --------------------------------------------------------------
    factoryMakespan = zeros(1,F);
    for f = 1:F
        ids = find(op.factory == f);
        if ~isempty(ids)
            factoryMakespan(f) = max(op.finish(ids));
        end
    end

    if any(abs(factoryMakespan - decoded.factoryMakespan) > tol)
        errors{end+1} = 'Factory makespan vector is inconsistent.';
    end

    systemMakespan = max(op.finish);
    if abs(systemMakespan - decoded.makespan) > tol
        errors{end+1} = 'System makespan is inconsistent.';
    end

    % --------------------------------------------------------------
    % Objective consistency
    % --------------------------------------------------------------
    if isfield(decoded, 'cost')
        cost2 = compute_tec(decoded, inst);
        if abs(decoded.cost.processing - cost2.processing) > 1e-8 || ...
           abs(decoded.cost.idle - cost2.idle) > 1e-8 || ...
           abs(decoded.cost.total - cost2.total) > 1e-8
            errors{end+1} = 'Stored TEC does not match independent recomputation.';
        end
    end

    if isfield(decoded, 'objectives')
        if abs(decoded.objectives(1) - systemMakespan) > tol
            errors{end+1} = 'Stored objective-1 does not match makespan.';
        end

        cost2 = compute_tec(decoded, inst);
        if abs(decoded.objectives(2) - cost2.total) > 1e-8
            errors{end+1} = 'Stored objective-2 does not match TEC.';
        end
    end

    report = finish_report(errors, throwOnError);
end

function report = finish_report(errors, throwOnError)
    report.ok = isempty(errors);
    report.errors = errors;

    if throwOnError && ~report.ok
        error('PSAMA:InvalidSchedule', '%s', strjoin(errors, newline));
    end
end
