function report = audit_config_fields()
%AUDIT_CONFIG_FIELDS Static check for cfg.section.field references.
%
% This is a lightweight development safeguard. It scans project MATLAB files
% and reports referenced configuration-field names that are not assigned in
% make_shared_config.m.

    cfgFile = which('make_shared_config');
    projectRoot = fileparts(fileparts(cfgFile));

    configText = fileread(cfgFile);

    defTokens = regexp(configText, ...
        'cfg\.([A-Za-z]\w*)\.([A-Za-z]\w*)\s*=', ...
        'tokens');

    defined = strings(numel(defTokens),1);
    for i = 1:numel(defTokens)
        defined(i) = string(defTokens{i}{1}) + "." + string(defTokens{i}{2});
    end
    defined = unique(defined);

    files = dir(fullfile(projectRoot,'**','*.m'));
    referenced = strings(0,1);

    for i = 1:numel(files)
        txt = fileread(fullfile(files(i).folder,files(i).name));

        % Remove MATLAB comments before static reference scanning so example
        % text inside comments cannot create false missing-field reports.
        lines = regexp(txt,'\r\n|\n|\r','split');
        for lineIdx = 1:numel(lines)
            percent = strfind(lines{lineIdx},'%');
            if ~isempty(percent)
                lines{lineIdx} = lines{lineIdx}(1:percent(1)-1);
            end
        end
        txtNoComments = strjoin(lines,newline);

        refTokens = regexp(txtNoComments, ...
            'cfg\.([A-Za-z]\w*)\.([A-Za-z]\w*)', ...
            'tokens');

        for k = 1:numel(refTokens)
            referenced(end+1,1) = ...
                string(refTokens{k}{1}) + "." + string(refTokens{k}{2}); %#ok<AGROW>
        end
    end

    referenced = unique(referenced);
    missing = setdiff(referenced,defined);

    report.ok = isempty(missing);
    report.missing = missing;
    report.numDefined = numel(defined);
    report.numReferenced = numel(referenced);

    if ~report.ok
        disp(missing);
        error('PSAMA:MissingConfigField', ...
            'Static cfg-field audit found missing shared-config fields.');
    end

    fprintf('[PASS] Config-field audit: %d referenced fields covered.\n', ...
        report.numReferenced);
end
