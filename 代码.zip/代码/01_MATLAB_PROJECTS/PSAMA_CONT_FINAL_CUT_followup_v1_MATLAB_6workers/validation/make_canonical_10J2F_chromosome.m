function chromosome = make_canonical_10J2F_chromosome(inst)
%MAKE_CANONICAL_10J2F_CHROMOSOME Fixed regression chromosome.

    assert(inst.size.numJobs == 10);
    assert(inst.size.numFactories == 2);
    assert(all(inst.size.operationsPerJob == 5));

    J = inst.size.numJobs;
    totalOps = inst.size.totalOperations;

    FS = repmat([1 2],1,J/2);

    OS = [];
    for o = 1:5
        OS = [OS,1:J]; %#ok<AGROW>
    end

    MS = zeros(1,totalOps);
    VS = zeros(1,totalOps);

    for g = 1:totalOps
        j = inst.map.globalToJob(g);
        o = inst.map.globalToOperation(g);
        f = FS(j);

        eligible = inst.process.eligibleMachines{f,j,o};
        MS(g) = min(eligible);
        VS(g) = o;
    end

    chromosome = [FS,OS,MS,VS];
end
