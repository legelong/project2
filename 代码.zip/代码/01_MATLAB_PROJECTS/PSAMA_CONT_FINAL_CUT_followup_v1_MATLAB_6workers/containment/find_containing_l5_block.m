function parent = find_containing_l5_block(child,current,cmaxBound)
%FIND_CONTAINING_L5_BLOCK Canonical L5 parent for a contiguous L3 block.
%
% Returns:
%   parent.exists = false if the machine schedule has <5 operations.
%
% Canonical parent start:
%   q = clamp(p-1, 1, n-4)
%
% This centers the L3 inside L5 when possible and is deterministic.

    if child.length~=3
        error('PSAMA:ContainmentChildLength', ...
            'Containment mapper expects an L3 child.');
    end

    ids = current.machineSchedules{child.factory,child.machine};
    ids = ids(:);

    n = numel(ids);
    p = child.machineStartPosition;

    parent.exists = false;

    if n<5
        return;
    end

    q = min(max(p-1,1),n-4);
    parentOps = ids(q:q+4);

    if ~all(ismember(child.opIds(:),parentOps))
        error('PSAMA:ContainmentMapFailure', ...
            'Canonical L5 parent does not contain the L3 child.');
    end

    if q>1
        prevOp = ids(q-1);
    else
        prevOp = NaN;
    end

    if q+4<n
        nextOp = ids(q+5);
    else
        nextOp = NaN;
    end

    parent.exists = true;
    parent.candidateId = sprintf( ...
        'F%d_M%d_P%d_L5',child.factory,child.machine,q);
    parent.factory = child.factory;
    parent.machine = child.machine;
    parent.length = 5;
    parent.machineStartPosition = q;
    parent.opIds = parentOps(:)';
    parent.machinePositions = q:(q+4);
    parent.prevMachineOp = prevOp;
    parent.nextMachineOp = nextOp;
    parent.cmaxBound = cmaxBound;

    % The exact solver does not use these fields, but common tooling expects
    % candidate structs to have them.
    parent.selectionScore = NaN;
    parent.scoreSlackNorm = NaN;
    parent.scoreEventFraction = NaN;
    parent.scoreExpensiveExposure = NaN;
end
