function candidates = enumerate_containment_reduced_blocks( ...
    current,cmaxBound,inst,cfg)
%ENUMERATE_CONTAINMENT_REDUCED_BLOCKS Exact nonredundant L3/L5 family.
%
% Keep:
%   every L5 block
%   L3 blocks only on machine sequences with 3 or 4 operations
%
% Drop:
%   every L3 block on a machine sequence with >=5 operations
%
% Those dropped L3 neighborhoods are contained in at least one L5 neighborhood.

    allCandidates = enumerate_cb_blocks( ...
        current,cmaxBound,inst,cfg);

    keep = false(numel(allCandidates),1);

    for i = 1:numel(allCandidates)
        c = allCandidates(i);

        if c.length==5
            keep(i) = true;
            continue;
        end

        if c.length~=3
            error('PSAMA:UnexpectedBlockLength', ...
                'Expected only L3/L5 candidates.');
        end

        ids = current.machineSchedules{c.factory,c.machine};

        if numel(ids)<5
            keep(i) = true;
        end
    end

    candidates = allCandidates(keep);
end
