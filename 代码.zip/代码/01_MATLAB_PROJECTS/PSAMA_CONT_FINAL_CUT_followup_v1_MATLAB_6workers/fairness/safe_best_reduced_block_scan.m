function scan = safe_best_reduced_block_scan( ...
    current,cmaxBound,inst,cfg,mode,iteration)

    mode = upper(char(mode));

    if ~strcmp(mode,'CB_RETIME') && ~strcmp(mode,'CB_JOINT')
        error('PSAMA:FairnessRefineMode','Unknown mode: %s',mode);
    end

    candidates = enumerate_containment_reduced_blocks( ...
        current,cmaxBound,inst,cfg);

    n = numel(candidates);

    scan.iteration = iteration;
    scan.mode = mode;
    scan.totalCandidates = n;
    scan.exactEvaluations = 0;
    scan.exactEvaluationFraction = 0;
    scan.boundSeconds = 0;
    scan.exactSeconds = 0;
    scan.bestGain = 0;
    scan.bestSolution = [];
    scan.bestCandidateId = '';
    scan.bestBlockLength = NaN;
    scan.bestBoundRank = NaN;
    scan.stopReason = 'NO_CANDIDATES';

    if n==0, return; end

    gainUB = zeros(n,1);
    tBound = tic;

    for i = 1:n
        U = compute_cb_gain_upper_bound( ...
            candidates(i),current,inst,cfg,mode);
        gainUB(i) = U.GainUpperBound;
    end

    scan.boundSeconds = toc(tBound);

    L = [candidates.length]';
    f = [candidates.factory]';
    m = [candidates.machine]';
    p = [candidates.machineStartPosition]';

    key = [-gainUB,-L,f,m,p];
    [~,ord] = sortrows(key,[1 2 3 4 5]);

    candidates = candidates(ord);
    gainUB = gainUB(ord);

    bestGain = 0;
    bestSolution = [];
    bestId = '';
    bestLength = NaN;
    bestRank = NaN;
    stopReason = 'EXHAUSTED';

    for i = 1:n
        if gainUB(i) <= bestGain+cfg.cb.improvementTolerance
            stopReason = 'BOUND_CERTIFIED';
            break;
        end

        if strcmp(mode,'CB_RETIME')
            solverMode = 'RETIME_ONLY';
        else
            solverMode = 'JOINT';
        end

        sol = solve_block_speed_time_milp( ...
            current,candidates(i),inst,cfg,solverMode);

        if cfg.cb.requireExact && ~sol.exactCertified
            error('PSAMA:FairnessBlockNotExact', ...
                'A required exact block was not certified.');
        end

        scan.exactEvaluations = scan.exactEvaluations+1;
        scan.exactSeconds = scan.exactSeconds+sol.solveSeconds;

        gain = max(0,current.cost.total-sol.totalTEC);

        if gain > gainUB(i)+cfg.block.objectiveTolerance
            error('PSAMA:FairnessUpperBoundViolation', ...
                'Exact gain exceeded safe upper bound.');
        end

        if gain > bestGain+cfg.cb.improvementTolerance
            bestGain = gain;
            bestSolution = sol;
            bestId = candidates(i).candidateId;
            bestLength = candidates(i).length;
            bestRank = i;
        end
    end

    scan.bestGain = bestGain;
    scan.bestSolution = bestSolution;
    scan.bestCandidateId = bestId;
    scan.bestBlockLength = bestLength;
    scan.bestBoundRank = bestRank;
    scan.stopReason = stopReason;
    scan.exactEvaluationFraction = scan.exactEvaluations/max(n,1);
end
