function snapshots = update_archive_snapshots( ...
    snapshots,archive,nfe,generation,targets)
%UPDATE_ARCHIVE_SNAPSHOTS Save objective-only archive checkpoints once crossed.

    if isempty(snapshots)
        snapshots = struct('targetNFE',{},'actualNFE',{}, ...
            'generation',{},'objectives',{});
    end

    existing = [];
    if ~isempty(snapshots)
        existing = [snapshots.targetNFE];
    end

    for target = targets
        if nfe >= target && ~ismember(target,existing)
            item.targetNFE = target;
            item.actualNFE = nfe;
            item.generation = generation;
            item.objectives = archive.objectives;

            snapshots(end+1,1) = item; %#ok<AGROW>
            existing(end+1) = target; %#ok<AGROW>
        end
    end
end
