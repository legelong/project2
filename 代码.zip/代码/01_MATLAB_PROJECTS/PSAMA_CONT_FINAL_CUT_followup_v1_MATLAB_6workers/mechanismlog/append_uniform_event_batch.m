function L = append_uniform_event_batch(L,E)
%APPEND_UNIFORM_EVENT_BATCH Append no-learning events numerically.

    if isempty(E)
        return;
    end

    n0 = numel(L.operatorId);
    n = numel(E);
    idx = (n0+1):(n0+n);

    L.generation(idx,1) = uint16([E.generation]');
    L.nfeBefore(idx,1) = uint32([E.nfeBefore]');
    L.nfeAfter(idx,1) = uint32([E.nfeAfter]');
    L.sourceIndex(idx,1) = uint16([E.sourceIndex]');
    L.operatorId(idx,1) = uint8([E.operatorId]');

    L.pairScore(idx,1) = single([E.pairScore]');

    for k = 1:n
        L.sourceObjective(idx(k),:) = single(E(k).sourceObjective(:)');
        L.childObjective(idx(k),:) = single(E(k).childObjective(:)');
    end

    L.parentReward(idx,1) = single([E.parentReward]');
    L.setGain(idx,1) = single([E.setGain]');
    L.archiveChanged(idx,1) = logical([E.archiveChanged]');
    L.enteredNextPopulationF1(idx,1) = ...
        logical([E.enteredNextPopulationF1]');
end
