function L = empty_uniform_compact_log()
%EMPTY_UNIFORM_COMPACT_LOG Compact numeric no-learning mechanism log.

    L.generation = zeros(0,1,'uint16');
    L.nfeBefore = zeros(0,1,'uint32');
    L.nfeAfter = zeros(0,1,'uint32');
    L.sourceIndex = zeros(0,1,'uint16');
    L.operatorId = zeros(0,1,'uint8');

    L.pairScore = zeros(0,1,'single');
    L.sourceObjective = zeros(0,2,'single');
    L.childObjective = zeros(0,2,'single');

    L.parentReward = zeros(0,1,'single');
    L.setGain = zeros(0,1,'single');
    L.archiveChanged = false(0,1);
    L.enteredNextPopulationF1 = false(0,1);
end
