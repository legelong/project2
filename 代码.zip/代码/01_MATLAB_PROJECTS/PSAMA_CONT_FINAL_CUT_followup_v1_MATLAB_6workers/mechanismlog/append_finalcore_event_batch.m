function L = append_finalcore_event_batch(L,E,cfg)
%APPEND_FINALCORE_EVENT_BATCH Append selected events numerically.

    if isempty(E)
        return;
    end

    n0 = numel(L.operatorId);
    n = numel(E);
    idx = (n0+1):(n0+n);

    L.generation(idx,1) = uint16([E.generation]');
    L.nfeBefore(idx,1) = uint32([E.nfeBefore]');
    L.nfeAfter(idx,1) = uint32([E.nfeAfter]');
    L.sourceIndex(idx,1) = uint16([E.sourceIndex]');
    L.operatorId(idx,1) = uint8([E.operatorId]');

    for k = 1:n
        L.context(idx(k),:) = single(E(k).context(:)');
        L.sourceObjective(idx(k),:) = single(E(k).sourceObjective(:)');
        L.childObjective(idx(k),:) = single(E(k).childObjective(:)');
    end

    L.predictedMean(idx,1) = single([E.predictedMean]');
    L.uncertainty(idx,1) = single([E.uncertainty]');
    L.explorationTerm(idx,1) = ...
        single(cfg.learning.alpha.*[E.uncertainty]');
    L.pairScore(idx,1) = single([E.pairScore]');

    L.parentReward(idx,1) = single([E.parentReward]');
    L.setGain(idx,1) = single([E.setGain]');
    L.archiveChanged(idx,1) = logical([E.archiveChanged]');
    L.enteredNextPopulationF1(idx,1) = ...
        logical([E.enteredNextPopulationF1]');
end
