function cost = compute_block_affected_cost( ...
    starts,durations,speeds,block,original,inst)
%COMPUTE_BLOCK_AFFECTED_COST Variable TEC contribution around one block.
%
% Includes:
%   processing cost of all block operations
%   idle gap from fixed previous machine op -> first block op (if present)
%   internal machine idle gaps
%   idle gap last block op -> fixed next machine op (if present)
%
% All other schedule cost is constant.

    starts = starts(:);
    durations = durations(:);
    speeds = speeds(:);

    L = numel(block.opIds);

    if numel(starts)~=L || numel(durations)~=L || numel(speeds)~=L
        error('PSAMA:BlockCostDimension', ...
            'Block cost vector dimensions do not match block length.');
    end

    cost = 0;

    for q = 1:L
        power = processing_power(speeds(q),inst);

        cost = cost + integrate_tou_cost( ...
            power,starts(q),durations(q),inst.tariff);
    end

    if ~isnan(block.prevMachineOp)
        prevFinish = original.op.finish(block.prevMachineOp);
        gap = starts(1)-prevFinish;

        if gap < -1e-9
            cost = inf;
            return;
        end

        cost = cost + integrate_tou_cost( ...
            inst.speed.idlePower,prevFinish,max(0,gap),inst.tariff);
    end

    for q = 1:L-1
        finishQ = starts(q)+durations(q);
        gap = starts(q+1)-finishQ;

        if gap < -1e-9
            cost = inf;
            return;
        end

        cost = cost + integrate_tou_cost( ...
            inst.speed.idlePower,finishQ,max(0,gap),inst.tariff);
    end

    if ~isnan(block.nextMachineOp)
        lastFinish = starts(end)+durations(end);
        nextStart = original.op.start(block.nextMachineOp);
        gap = nextStart-lastFinish;

        if gap < -1e-9
            cost = inf;
            return;
        end

        cost = cost + integrate_tou_cost( ...
            inst.speed.idlePower,lastFinish,max(0,gap),inst.tariff);
    end
end
