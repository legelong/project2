function graph = build_fixed_order_graph_general( ...
    decoded,inst,cmaxBound,cfg)
%BUILD_FIXED_ORDER_GRAPH_GENERAL Fixed DAG analysis for schedules with waiting.
%
% Unlike the original build_schedule_graph, this function does NOT require
% decoded.start to equal the earliest-start schedule.
%
% Machine arcs follow the stored machineSchedules order exactly.
% Latest times are computed relative to the supplied global Cmax bound.

    n = inst.size.totalOperations;
    preds = cell(n,1);
    succs = cell(n,1);

    % Job arcs.
    for j = 1:inst.size.numJobs
        for o = 2:inst.size.operationsPerJob(j)
            a = inst.map.opGlobalIndex(j,o-1);
            b = inst.map.opGlobalIndex(j,o);

            preds{b}(end+1) = a;
            succs{a}(end+1) = b;
        end
    end

    % Fixed machine-order arcs.
    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = decoded.machineSchedules{f,m};
            ids = ids(:);

            for q = 1:numel(ids)-1
                a = ids(q);
                b = ids(q+1);

                preds{b}(end+1) = a;
                succs{a}(end+1) = b;
            end
        end
    end

    % Remove accidental duplicate arcs.
    for g = 1:n
        if ~isempty(preds{g}), preds{g} = unique(preds{g},'stable'); end
        if ~isempty(succs{g}), succs{g} = unique(succs{g},'stable'); end
    end

    % Kahn topological order.
    indegree = zeros(n,1);

    for g = 1:n
        indegree(g) = numel(preds{g});
    end

    ready = find(indegree==0)';
    order = zeros(n,1);
    count = 0;

    while ~isempty(ready)
        g = ready(1);
        ready(1) = [];

        count = count+1;
        order(count) = g;

        for s = succs{g}
            indegree(s) = indegree(s)-1;

            if indegree(s)==0
                ready(end+1) = s; %#ok<AGROW>
                ready = sort(ready);
            end
        end
    end

    if count ~= n
        error('PSAMA:FixedOrderCycle', ...
            'Fixed job+machine precedence graph contains a cycle.');
    end

    ES = zeros(n,1);
    EF = zeros(n,1);

    for q = 1:n
        g = order(q);

        if isempty(preds{g})
            ES(g) = 0;
        else
            ES(g) = max(EF(preds{g}));
        end

        EF(g) = ES(g)+decoded.op.duration(g);
    end

    earliestMakespan = max(EF);

    if earliestMakespan > cmaxBound+cfg.decoder.tolerance
        error('PSAMA:CmaxBoundInfeasible', ...
            'Current fixed order/durations cannot satisfy the supplied Cmax bound.');
    end

    LF = cmaxBound*ones(n,1);
    LS = zeros(n,1);

    for q = n:-1:1
        g = order(q);

        if isempty(succs{g})
            LF(g) = cmaxBound;
        else
            LF(g) = min(LS(succs{g}));
        end

        LS(g) = LF(g)-decoded.op.duration(g);
    end

    slack = LS-ES;
    slack(abs(slack)<=cfg.decoder.tolerance) = 0;

    if any(slack < -cfg.decoder.tolerance)
        error('PSAMA:NegativeFixedOrderSlack', ...
            'Negative structural slack under supplied Cmax bound.');
    end

    % Verify current intentional-wait schedule respects the same DAG and bound.
    if decoded.makespan > cmaxBound+cfg.decoder.tolerance
        error('PSAMA:CurrentScheduleCmax', ...
            'Current schedule exceeds the preserved baseline Cmax bound.');
    end

    for a = 1:n
        for b = succs{a}
            if decoded.op.start(b) < ...
                    decoded.op.finish(a)-cfg.decoder.tolerance
                error('PSAMA:CurrentScheduleArcViolation', ...
                    'Current schedule violates fixed-order precedence.');
            end
        end
    end

    if any(decoded.op.start < ES-cfg.decoder.tolerance) || ...
       any(decoded.op.start > LS+cfg.decoder.tolerance)
        error('PSAMA:CurrentScheduleOutsideWindow', ...
            'Current schedule lies outside fixed-order ES/LS windows.');
    end

    graph.predecessors = preds;
    graph.successors = succs;
    graph.topologicalOrder = order;

    graph.earliestStart = ES;
    graph.earliestFinish = EF;
    graph.latestStart = LS;
    graph.latestFinish = LF;
    graph.slack = slack;

    graph.earliestMakespan = earliestMakespan;
    graph.makespan = cmaxBound;
    graph.cmaxBound = cmaxBound;
    graph.criticalMask = slack <= cfg.features.criticalTolerance;
end
