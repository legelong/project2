function out = solve_block_speed_time_milp( ...
    current,block,inst,cfg,mode)
%SOLVE_BLOCK_SPEED_TIME_MILP Exact sequential block oracle.

    if exist('intlinprog','file')~=2
        error('PSAMA:MissingOptimizationToolbox', ...
            'Sequential block oracle requires intlinprog.');
    end

    model = build_block_speed_time_milp( ...
        current,block,inst,cfg,mode);

    options = optimoptions('intlinprog', ...
        'Display','off', ...
        'RelativeGapTolerance',cfg.block.relativeGapTolerance, ...
        'AbsoluteGapTolerance',cfg.block.absoluteGapTolerance, ...
        'MaxTime',cfg.block.maxSolveSeconds);

    tSolve = tic;

    [x,fval,exitflag,output] = intlinprog( ...
        model.c,model.intcon, ...
        model.A,model.b, ...
        model.Aeq,model.beq, ...
        model.lb,model.ub,options);

    runtime = toc(tSolve);

    if isempty(x)
        error('PSAMA:BlockMILPNoIncumbent', ...
            '%s block MILP returned no feasible incumbent.',mode);
    end

    L = numel(block.opIds);
    starts = zeros(L,1);
    speeds = zeros(L,1);
    durations = zeros(L,1);

    for q = 1:L
        idx = model.varIndices{q};
        [mx,loc] = max(x(idx));

        if mx < 0.5
            error('PSAMA:BlockMILPRecover', ...
                'Could not recover block decision for local op %d.',q);
        end

        starts(q) = model.candidateStart{q}(loc);
        speeds(q) = model.candidateSpeed{q}(loc);
        durations(q) = model.candidateDuration{q}(loc);
    end

    decoded = apply_block_schedule( ...
        current,block,speeds,starts,inst,cfg);

    affected = compute_block_affected_cost( ...
        starts,durations,speeds,block,current,inst);

    currentAffected = compute_block_affected_cost( ...
        current.op.start(block.opIds), ...
        current.op.duration(block.opIds), ...
        current.op.speed(block.opIds), ...
        block,current,inst);

    predictedTotal = ...
        current.cost.total-currentAffected+affected;

    if abs(predictedTotal-decoded.cost.total)>cfg.block.objectiveTolerance
        error('PSAMA:BlockAffectedCostMismatch', ...
            'Affected-cost reconstruction and full TEC evaluator differ.');
    end

    cmaxBound = model.info.originalCmax;

    if decoded.makespan > cmaxBound+cfg.decoder.tolerance
        error('PSAMA:BlockCmaxViolation', ...
            'Sequential block move exceeded preserved baseline Cmax.');
    end

    if exitflag==1
        status = 'OPTIMAL_CERTIFIED';
    elseif exitflag==0
        status = 'TIME_LIMIT_OR_EARLY_STOP';
    else
        status = sprintf('EXITFLAG_%d',exitflag);
    end

    out.mode = upper(char(mode));
    out.decoded = decoded;
    out.starts = starts;
    out.speeds = speeds;
    out.durations = durations;

    out.totalTEC = decoded.cost.total;
    out.affectedCost = affected;
    out.currentAffectedCost = currentAffected;

    out.numBinaryVariables = model.numBinaryVariables;
    out.solveSeconds = runtime;
    out.exitflag = exitflag;
    out.status = status;
    out.relativeGap = output_field(output,'relativegap',NaN);
    out.absoluteGap = output_field(output,'absolutegap',NaN);
    out.linearObjective = fval;
    out.exactCertified = exitflag==1;
end

function value = output_field(S,name,defaultValue)
    if isstruct(S) && isfield(S,name)
        value = S.(name);
    else
        value = defaultValue;
    end
end
