function times = tariff_change_times(maxTime,tariff)
%TARIFF_CHANGE_TIMES All configured TOU price-change times on [0,maxTime].

    base = unique([ ...
        0; ...
        tariff.period; ...
        tariff.valleyIntervals(:); ...
        tariff.peakIntervals(:)]);

    cycles = 0:tariff.period:(maxTime+tariff.period);

    times = [];

    for c = cycles
        times = [times;c+base]; %#ok<AGROW>
    end

    times = unique(times);
    times = times(times>=0 & times<=maxTime);
end
