function model = build_block_speed_time_milp( ...
    current,block,inst,cfg,mode)
%BUILD_BLOCK_SPEED_TIME_MILP Exact integer-time block MILP.
%
% mode:
%   RETIME_ONLY : current block speeds fixed
%   JOINT       : all speed levels + start times
%
% The preserved Cmax bound comes from block.cmaxBound.

    if abs(cfg.block.timeGrid-1)>1e-12
        error('PSAMA:BlockGrid', ...
            'v1 sequential block oracle requires integer timeGrid=1.');
    end

    mode = upper(string(mode));

    if mode~="RETIME_ONLY" && mode~="JOINT"
        error('PSAMA:BlockMILPMode', ...
            'Unknown block MILP mode: %s',mode);
    end

    info = build_block_constraints(current,block,inst,cfg);

    opIds = info.opIds;
    L = numel(opIds);
    Cmax = round(info.originalCmax);

    candidateStart = cell(L,1);
    candidateSpeed = cell(L,1);
    candidateDuration = cell(L,1);
    varIndices = cell(L,1);

    totalVars = 0;

    for q = 1:L
        g = opIds(q);

        if mode=="RETIME_ONLY"
            speeds = current.op.speed(g);
        else
            speeds = inst.speed.levels(:)';
        end

        startsQ = [];
        speedsQ = [];
        durationsQ = [];

        for v = speeds
            d = processing_duration(current.op.baseTime(g),v,inst);

            lo = ceil(info.externalRelease(q)-1e-12);
            hi = floor(min( ...
                Cmax-d, ...
                info.externalDeadline(q)-d)+1e-12);

            if hi < lo
                continue;
            end

            times = (lo:hi)';

            startsQ = [startsQ;times]; %#ok<AGROW>
            speedsQ = [speedsQ;repmat(v,numel(times),1)]; %#ok<AGROW>
            durationsQ = [durationsQ;repmat(d,numel(times),1)]; %#ok<AGROW>
        end

        if isempty(startsQ)
            error('PSAMA:EmptyBlockCandidateSet', ...
                'No feasible speed/start candidate for block op %d.',g);
        end

        candidateStart{q} = startsQ;
        candidateSpeed{q} = speedsQ;
        candidateDuration{q} = durationsQ;

        count = numel(startsQ);
        varIndices{q} = (totalVars+1:totalVars+count)';
        totalVars = totalVars+count;
    end

    if totalVars > cfg.block.maxBinaryVariables
        error('PSAMA:BlockMILPTooLarge', ...
            'Block MILP has %d binaries; safety cap is %d.', ...
            totalVars,cfg.block.maxBinaryVariables);
    end

    c = zeros(totalVars,1);
    Pidle = inst.speed.idlePower;

    for q = 1:L
        idx = varIndices{q};
        tt = candidateStart{q};
        vv = candidateSpeed{q};
        dd = candidateDuration{q};

        for z = 1:numel(idx)
            t = tt(z);
            v = vv(z);
            d = dd(z);

            workMinusIdle = processing_power(v,inst)-Pidle;

            value = integrate_tou_cost( ...
                workMinusIdle,t,d,inst.tariff);

            if q==1 && isnan(block.prevMachineOp)
                value = value - integrate_tou_cost( ...
                    Pidle,0,t,inst.tariff);
            end

            if q==L && isnan(block.nextMachineOp)
                value = value + integrate_tou_cost( ...
                    Pidle,0,t+d,inst.tariff);
            end

            c(idx(z)) = value;
        end
    end

    % One-hot per operation.
    eqRows = [];
    eqCols = [];
    eqVals = [];

    for q = 1:L
        idx = varIndices{q};

        eqRows = [eqRows;repmat(q,numel(idx),1)]; %#ok<AGROW>
        eqCols = [eqCols;idx]; %#ok<AGROW>
        eqVals = [eqVals;ones(numel(idx),1)]; %#ok<AGROW>
    end

    Aeq = sparse(eqRows,eqCols,eqVals,L,totalVars);
    beq = ones(L,1);

    % Internal precedence finish(a)<=start(b).
    arcs = info.internalArcs;

    ineqRows = [];
    ineqCols = [];
    ineqVals = [];
    b = zeros(size(arcs,1),1);

    for r = 1:size(arcs,1)
        a = arcs(r,1);
        bb = arcs(r,2);

        idxA = varIndices{a};
        idxB = varIndices{bb};

        finishA = candidateStart{a}+candidateDuration{a};
        startB = candidateStart{bb};

        ineqRows = [ineqRows; ...
            repmat(r,numel(idxA),1); ...
            repmat(r,numel(idxB),1)]; %#ok<AGROW>

        ineqCols = [ineqCols;idxA;idxB]; %#ok<AGROW>
        ineqVals = [ineqVals;finishA;-startB]; %#ok<AGROW>
    end

    A = sparse(ineqRows,ineqCols,ineqVals,size(arcs,1),totalVars);

    % Current decision must remain available.
    currentIndex = zeros(L,1);

    for q = 1:L
        g = opIds(q);

        match = ...
            abs(candidateStart{q}-current.op.start(g))<1e-12 & ...
            abs(candidateSpeed{q}-current.op.speed(g))<1e-12;

        loc = find(match,1);

        if isempty(loc)
            error('PSAMA:CurrentBlockDecisionMissing', ...
                'Current block decision absent for op %d.',g);
        end

        currentIndex(q) = varIndices{q}(loc);
    end

    model.mode = char(mode);
    model.info = info;
    model.block = block;

    model.candidateStart = candidateStart;
    model.candidateSpeed = candidateSpeed;
    model.candidateDuration = candidateDuration;
    model.varIndices = varIndices;

    model.numBinaryVariables = totalVars;
    model.internalArcs = arcs;

    model.c = c;
    model.intcon = 1:totalVars;
    model.A = A;
    model.b = b;
    model.Aeq = Aeq;
    model.beq = beq;
    model.lb = zeros(totalVars,1);
    model.ub = ones(totalVars,1);

    model.currentIndex = currentIndex;
end
