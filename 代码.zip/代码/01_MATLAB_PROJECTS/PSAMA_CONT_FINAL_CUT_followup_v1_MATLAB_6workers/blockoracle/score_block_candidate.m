function detail = score_block_candidate( ...
    opIds,decoded,graph,inst,cfg)
%SCORE_BLOCK_CANDIDATE Original-schedule-only structural score.
%
% No oracle result enters this score.

    L = numel(opIds);
    Cmax = max(graph.makespan,1);

    slackNorm = sum(graph.slack(opIds))/(L*Cmax);

    events = tariff_change_times( ...
        graph.makespan+max(decoded.op.duration(opIds)),inst.tariff);

    eventHit = false(L,1);
    expensive = zeros(L,1);

    low = inst.tariff.valleyPrice;
    high = inst.tariff.peakPrice;
    denom = max(high-low,eps);

    for q = 1:L
        g = opIds(q);

        lo = graph.earliestStart(g);
        hi = graph.latestStart(g);
        d = decoded.op.duration(g);

        eventStarts = [events;events-d];
        eventHit(q) = any(eventStarts>=lo-1e-12 & eventStarts<=hi+1e-12);

        avgTariff = integrate_tou_cost( ...
            1,decoded.op.start(g),d,inst.tariff)/max(d,eps);

        expensive(q) = min(1,max(0,(avgTariff-low)/denom));
    end

    eventFraction = mean(eventHit);
    expensiveExposure = mean(expensive);

    score = ...
        cfg.block.scoreSlackWeight*slackNorm + ...
        cfg.block.scoreTariffEventWeight*eventFraction + ...
        cfg.block.scoreExpensiveExposureWeight*expensiveExposure;

    detail.score = score;
    detail.slackNorm = slackNorm;
    detail.eventFraction = eventFraction;
    detail.expensiveExposure = expensiveExposure;
    detail.totalSlack = sum(graph.slack(opIds));
    detail.meanSlack = mean(graph.slack(opIds));
end
