function decoded = apply_block_schedule( ...
    original,block,speeds,starts,inst,cfg)
%APPLY_BLOCK_SCHEDULE Rebuild a complete feasible schedule after block changes.

    decoded = original;

    opIds = block.opIds(:);
    speeds = speeds(:);
    starts = starts(:);

    if numel(opIds)~=numel(speeds) || numel(opIds)~=numel(starts)
        error('PSAMA:BlockApplyDimension', ...
            'Block decision dimensions do not match.');
    end

    for q = 1:numel(opIds)
        g = opIds(q);
        decoded.op.speed(g) = speeds(q);
        decoded.op.duration(g) = processing_duration( ...
            decoded.op.baseTime(g),speeds(q),inst);
        decoded.op.start(g) = starts(q);
        decoded.op.finish(g) = starts(q)+decoded.op.duration(g);

        decoded.parts.VS(g) = speeds(q);

        n = inst.size.totalOperations;
        J = inst.size.numJobs;
        vsStart = J + 2*n;
        decoded.chromosome(vsStart+g) = speeds(q);
    end

    F = inst.size.numFactories;
    fm = zeros(1,F);

    for f = 1:F
        ids = find(decoded.op.factory==f);

        if ~isempty(ids)
            fm(f) = max(decoded.op.finish(ids));
        end
    end

    decoded.factoryMakespan = fm;
    decoded.makespan = max(decoded.op.finish);

    decoded.cost = compute_tec(decoded,inst);
    decoded.objectives = [decoded.makespan,decoded.cost.total];

    validate_schedule(decoded,inst,cfg,true);
end
