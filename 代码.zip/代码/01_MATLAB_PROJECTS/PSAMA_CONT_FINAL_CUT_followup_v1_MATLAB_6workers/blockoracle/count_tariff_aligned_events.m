function D = count_tariff_aligned_events(starts,durations,inst)
%COUNT_TARIFF_ALIGNED_EVENTS Count starts/finishes on TOU change boundaries.

    starts = starts(:);
    durations = durations(:);
    finishes = starts+durations;

    maxT = max(finishes)+inst.tariff.period;
    events = tariff_change_times(maxT,inst.tariff);

    tol = 1e-9;

    startAligned = false(numel(starts),1);
    finishAligned = false(numel(starts),1);

    for q = 1:numel(starts)
        startAligned(q) = any(abs(events-starts(q))<=tol);
        finishAligned(q) = any(abs(events-finishes(q))<=tol);
    end

    D.startAlignedCount = sum(startAligned);
    D.finishAlignedCount = sum(finishAligned);
    D.anyAlignedOperationCount = sum(startAligned | finishAligned);
    D.anyAlignedFraction = mean(startAligned | finishAligned);
end
