function info = build_block_constraints(current,block,inst,cfg)
%BUILD_BLOCK_CONSTRAINTS Internal arcs + fixed outside release/deadline.
%
% Supports intentional waiting and a preserved baseline Cmax bound.

    if isfield(block,'cmaxBound') && ~isempty(block.cmaxBound)
        cmaxBound = block.cmaxBound;
    else
        cmaxBound = current.makespan;
    end

    graph = build_fixed_order_graph_general( ...
        current,inst,cmaxBound,cfg);

    opIds = block.opIds(:);
    L = numel(opIds);

    localIndex = zeros(inst.size.totalOperations,1);
    localIndex(opIds) = 1:L;

    externalRelease = zeros(L,1);
    externalDeadline = cmaxBound*ones(L,1);

    internalArcs = zeros(0,2);

    for q = 1:L
        g = opIds(q);

        preds = graph.predecessors{g};

        for k = 1:numel(preds)
            p = preds(k);
            lp = localIndex(p);

            if lp > 0
                internalArcs(end+1,:) = [lp,q]; %#ok<AGROW>
            else
                externalRelease(q) = max( ...
                    externalRelease(q),current.op.finish(p));
            end
        end

        succ = graph.successors{g};

        for k = 1:numel(succ)
            s = succ(k);
            ls = localIndex(s);

            if ls > 0
                internalArcs(end+1,:) = [q,ls]; %#ok<AGROW>
            else
                externalDeadline(q) = min( ...
                    externalDeadline(q),current.op.start(s));
            end
        end
    end

    if ~isempty(internalArcs)
        internalArcs = unique(internalArcs,'rows','stable');
    end

    topoGlobal = graph.topologicalOrder(:);
    mask = ismember(topoGlobal,opIds);
    topoOps = topoGlobal(mask);

    topoLocal = zeros(numel(topoOps),1);

    for q = 1:numel(topoOps)
        topoLocal(q) = localIndex(topoOps(q));
    end

    info.graph = graph;
    info.opIds = opIds;
    info.localIndex = localIndex;
    info.internalArcs = internalArcs;
    info.externalRelease = externalRelease;
    info.externalDeadline = externalDeadline;
    info.topologicalLocalOrder = topoLocal;
    info.originalCmax = cmaxBound;
end
