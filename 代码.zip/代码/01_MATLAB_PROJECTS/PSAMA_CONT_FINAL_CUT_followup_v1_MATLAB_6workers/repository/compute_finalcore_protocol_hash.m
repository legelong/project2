function [hash,signature] = compute_finalcore_protocol_hash(cfg,expCfg)
%COMPUTE_FINALCORE_PROTOCOL_HASH Stable protocol fingerprint.

    S.algorithmVersion = cfg.project.algorithmVersion;
    S.instances = expCfg.instances;
    S.numRuns = expCfg.numRuns;
    S.maxNFE = expCfg.maxNFE;

    S.populationSize = cfg.evolution.populationSize;
    S.crossoverProbability = cfg.evolution.crossoverProbability;
    S.segmentMutationProbability = cfg.evolution.segmentMutationProbability;
    S.localSearchRatio = cfg.experiment.localSearchRatio;

    S.alpha = cfg.learning.alpha;
    S.ridgeLambda = cfg.learning.ridgeLambda;
    S.sourceMode = 'F1';
    S.rewardMode = 'PARENT';
    S.operatorNames = cfg.operators.names;

    S.speedLevels = cfg.problem.speedLevels;
    S.processingPowerCoefficient = cfg.problem.processingPowerCoefficient;
    S.idlePower = cfg.problem.idlePower;

    S.flatPrice = cfg.tariff.flatPrice;
    S.valleyMultiplier = cfg.tariff.valleyMultiplier;
    S.peakMultiplier = cfg.tariff.peakMultiplier;
    S.valleyIntervals = cfg.tariff.valleyIntervals;
    S.peakIntervals = cfg.tariff.peakIntervals;

    S.decoder = cfg.decoder.method;
    S.baseSeed = cfg.experiment.baseSeed;

    signature = jsonencode(S);

    try
        md = javaMethod('getInstance', ...
            'java.security.MessageDigest','MD5');
        md.update(uint8(signature));
        bytes = uint8(md.digest());
        hash = lower(reshape(dec2hex(bytes,2).',1,[]));
    catch
        % Deterministic lightweight fallback if JVM hashing is unavailable.
        u = double(uint8(signature));
        weights = mod((1:numel(u))*1315423911,2147483647);
        checksum = mod(sum(mod(u.*weights,2147483647)),2147483647);
        hash = sprintf('fallback_%010u',uint32(checksum));
    end
end
