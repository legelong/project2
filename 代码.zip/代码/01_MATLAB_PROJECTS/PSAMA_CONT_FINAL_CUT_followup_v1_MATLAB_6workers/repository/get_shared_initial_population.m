function X = get_shared_initial_population(inst,instanceName,runIndex,seed,cfg)
%GET_SHARED_INITIAL_POPULATION Persist/reuse one exact initial population.
%
% All repair variants for the same instance/run read the exact same X.

    root = fullfile(cfg.project.root,'initial_populations',instanceName);

    if ~isfolder(root)
        mkdir(root);
    end

    file = fullfile(root,sprintf('run_%02d_seed_%d.mat',runIndex,seed));

    if isfile(file)
        S = load(file,'X','meta');
        X = S.X;

        assert(size(X,1) == cfg.evolution.populationSize);
        assert(size(X,2) == inst.encoding.totalLength);
        return;
    end

    rng(seed,'twister');
    X = initialize_population(inst,cfg,cfg.evolution.populationSize);

    meta.instanceName = instanceName;
    meta.runIndex = runIndex;
    meta.seed = seed;
    meta.populationSize = cfg.evolution.populationSize;
    meta.algorithmVersion = cfg.project.algorithmVersion;

    save(file,'X','meta','-v7');
end
