function report = validate_followup_sources(cfg,expCfg)
%VALIDATE_FOLLOWUP_SOURCES Strict audit of the 400 embedded predecessor raws.

    root = fullfile(cfg.project.root,'source_results', ...
        cfg.repository.sourceTag,'raw');

    expectedHash = '';
    checked = 0;

    fprintf('[Source audit] Validating 400 predecessor run files...\n');

    for ii = 1:numel(expCfg.instances)
        inst = expCfg.instances{ii};

        for rr = 1:expCfg.numRuns
            file = fullfile(root,inst,sprintf('run_%02d.mat',rr));

            if ~isfile(file)
                error('PSAMA:FollowupSourceMissing', ...
                    'Missing predecessor raw: %s',file);
            end

            S = load(file,'record');
            R = S.record;

            expectedSeed = cfg.experiment.baseSeed+rr-1;

            if ~isfield(R,'complete') || ~R.complete
                error('PSAMA:FollowupSourceIncomplete', ...
                    'Incomplete predecessor raw: %s',file);
            end

            if ~strcmp(R.summary.instance,inst) || ...
               R.summary.run~=rr || ...
               R.summary.seed~=expectedSeed
                error('PSAMA:FollowupSourceIdentity', ...
                    'Instance/run/seed mismatch: %s',file);
            end

            if R.summary.stage1NFE~=10000
                error('PSAMA:FollowupSourceNFE', ...
                    'Expected 10000-NFE predecessor: %s',file);
            end

            if isempty(expectedHash)
                expectedHash = R.summary.configHash;
            elseif ~strcmp(R.summary.configHash,expectedHash)
                error('PSAMA:FollowupSourceHash', ...
                    'Mixed predecessor config hashes detected.');
            end

            if ~isfield(R,'followup') || ...
               ~isfield(R.followup,'contSelectedChromosomes') || ...
               ~isfield(R.followup,'contSelectedObjectives')
                error('PSAMA:FollowupMaterialMissing', ...
                    'CONT_FINAL chromosomes were not saved: %s',file);
            end

            if ~isfield(R.fronts,'FINAL') || ...
               ~isfield(R.fronts,'CONT_FINAL')
                error('PSAMA:FollowupFrontMissing', ...
                    'Required formal fronts missing: %s',file);
            end

            X = R.followup.contSelectedChromosomes;
            F = R.followup.contSelectedObjectives;

            if isempty(X) || isempty(F)
                error('PSAMA:FollowupEmptySelection', ...
                    'Empty continuation representative set: %s',file);
            end

            if size(X,1)~=size(F,1)
                error('PSAMA:FollowupSelectionSize', ...
                    'Chromosome/objective count mismatch: %s',file);
            end

            if size(X,1)>cfg.refinement.maxRepresentativePoints
                error('PSAMA:FollowupTooManyPoints', ...
                    'Follow-up selection exceeds frozen max 8.');
            end

            checked = checked+1;
        end
    end

    report.checked = checked;
    report.configHash = expectedHash;

    fprintf('[PASS] Source audit: %d compatible run files.\n',checked);
end
