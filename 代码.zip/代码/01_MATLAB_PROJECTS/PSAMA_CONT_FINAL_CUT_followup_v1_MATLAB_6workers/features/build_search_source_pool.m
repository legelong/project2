function pool = build_search_source_pool(pop,inst,cfg)
%BUILD_SEARCH_SOURCE_POOL F1 + high-recovery F2.
%
% No new objective evaluation is allowed here. All decoded schedules must come
% from the common population evaluation cache.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    if isempty(pop.fronts)
        pop = assign_rank_and_crowding(pop);
    end

    if isempty(pop.fronts) || isempty(pop.fronts{1})
        error('PSAMA:NoF1','Population has no first nondominated front.');
    end

    f1 = pop.fronts{1}(:);
    recovery = score_f2_recovery(pop,inst,cfg);
    f2Selected = recovery.selectedIndices(:);

    indices = [f1;f2Selected];

    sourceType = cell(numel(indices),1);
    sourceType(1:numel(f1)) = {'F1'};
    sourceType(numel(f1)+1:end) = {'F2-recovery'};

    recoveryScore = nan(numel(indices),1);
    recoveryScore(1:numel(f1)) = 1;

    for q = 1:numel(f2Selected)
        idx = f2Selected(q);
        pos = find(recovery.indices == idx,1,'first');

        if ~isempty(pos)
            recoveryScore(numel(f1)+q) = recovery.scores(pos);
        end
    end

    pool.indices = indices;
    pool.sourceType = sourceType;
    pool.recoveryScore = recoveryScore;
    pool.f1Indices = f1;
    pool.f2SelectedIndices = f2Selected;
    pool.recovery = recovery;
end
