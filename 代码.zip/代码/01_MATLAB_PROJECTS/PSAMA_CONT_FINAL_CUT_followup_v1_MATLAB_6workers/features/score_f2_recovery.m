function recovery = score_f2_recovery(pop,inst,cfg)
%SCORE_F2_RECOVERY Score all F2 members relative to the current F1.
%
% Requires pop.rank/fronts and cached decoded schedules.
% This function prepares the search-source mechanism for later steps but does
% NOT yet perform local search.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    if isempty(pop.fronts)
        pop = assign_rank_and_crowding(pop);
    end

    if numel(pop.fronts) < 2 || isempty(pop.fronts{2})
        recovery.indices = [];
        recovery.scores = [];
        recovery.details = {};
        recovery.selectedIndices = [];
        return;
    end

    f1 = pop.fronts{1};
    f2 = pop.fronts{2};

    f1Chromosomes = pop.chromosomes(f1,:);
    f1Objectives = pop.objectives(f1,:);

    scores = zeros(numel(f2),1);
    details = cell(numel(f2),1);

    for q = 1:numel(f2)
        idx = f2(q);

        if isempty(pop.decoded{idx})
            error('PSAMA:MissingDecodedCache', ...
                ['Official recovery scoring requires the decoded schedule ' ...
                 'cached during the common objective evaluation. Re-decoding ' ...
                 'inside feature scoring is intentionally forbidden so that ' ...
                 'CPU/NFE accounting cannot be hidden.']);
        end
        decoded = pop.decoded{idx};

        detail = compute_recovery_potential( ...
            pop.chromosomes(idx,:), ...
            pop.objectives(idx,:), ...
            decoded, ...
            f1Chromosomes, ...
            f1Objectives, ...
            inst,cfg);

        scores(q) = detail.score;
        details{q} = detail;
    end

    nSelect = max(1,ceil(cfg.recovery.f2TopFraction*numel(f2)));
    orderTable = [-scores(:),f2(:)];
    [~,order] = sortrows(orderTable,[1 2]);

    recovery.indices = f2(:);
    recovery.scores = scores;
    recovery.details = details;
    recovery.selectedIndices = f2(order(1:nSelect));
end
