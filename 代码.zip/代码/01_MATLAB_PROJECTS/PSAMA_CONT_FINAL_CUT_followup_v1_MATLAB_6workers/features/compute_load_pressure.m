function metrics = compute_load_pressure(decoded,inst,cfg)
%COMPUTE_LOAD_PRESSURE Physical-machine load pressure.
%
% IMPORTANT: (factory,machine) identifies one physical machine.
% Zero-load machines ARE included.
%
% rawPressure = variance(load)/(mean(load)^2+eps)
% normalizedPressure = raw/(1+raw)

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    loads = [];
    labels = zeros(0,2);

    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = decoded.machineSchedules{f,m};
            loadValue = 0;

            if ~isempty(ids)
                loadValue = sum(decoded.op.duration(ids));
            end

            loads(end+1,1) = loadValue; %#ok<AGROW>
            labels(end+1,:) = [f,m]; %#ok<AGROW>
        end
    end

    mu = mean(loads);
    varianceValue = var(loads,1); % population variance

    raw = varianceValue / ...
        (mu^2 + cfg.features.loadPressureEpsilon);

    normalized = raw / (1+raw);

    maxLoad = max(loads);
    busiestIdx = find(abs(loads-maxLoad) <= 1e-12,1,'first');

    metrics.machineLoads = loads;
    metrics.machineLabels = labels;
    metrics.meanLoad = mu;
    metrics.varianceLoad = varianceValue;
    metrics.rawPressure = raw;
    metrics.normalizedPressure = normalized;
    metrics.busiestFactory = labels(busiestIdx,1);
    metrics.busiestMachine = labels(busiestIdx,2);
    metrics.busiestLoad = maxLoad;
end
