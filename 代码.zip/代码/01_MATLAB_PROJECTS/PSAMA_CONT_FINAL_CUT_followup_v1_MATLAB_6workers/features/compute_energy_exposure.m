function exposure = compute_energy_exposure(decoded,inst)
%COMPUTE_ENERGY_EXPOSURE Processing-energy exposure by TOU period.
%
% The 8-D context uses processing peak-energy share:
%   peakExposure = peak processing energy / total processing energy.

    E = [0,0,0]; % valley flat peak

    for g = 1:inst.size.totalOperations
        power = processing_power(decoded.op.speed(g),inst);

        band = integrate_energy_by_tariff_band( ...
            power,decoded.op.start(g),decoded.op.duration(g),inst.tariff);

        E = E + [band.valley,band.flat,band.peak];
    end

    total = sum(E);

    if total <= 0
        shares = [0,0,0];
    else
        shares = E/total;
    end

    exposure.valleyEnergy = E(1);
    exposure.flatEnergy = E(2);
    exposure.peakEnergy = E(3);
    exposure.totalProcessingEnergy = total;

    exposure.valleyShare = shares(1);
    exposure.flatShare = shares(2);
    exposure.peakShare = shares(3);
    exposure.peakExposure = shares(3);
end
