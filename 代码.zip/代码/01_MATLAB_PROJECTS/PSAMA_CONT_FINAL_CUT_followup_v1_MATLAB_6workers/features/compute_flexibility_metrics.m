function flex = compute_flexibility_metrics(decoded,inst,critical,loadMetrics)
%COMPUTE_FLEXIBILITY_METRICS Machine and critical-path flexibility.
%
% machineFlexibility:
%   fraction of operations on the busiest physical machine that have more
%   than one eligible machine in their assigned factory.
%
% sequenceFlexibility:
%   among all unordered operation pairs on one deterministic critical path,
%   fraction belonging to different jobs.
%
% combinedFlexibility:
%   mean(machineFlexibility,sequenceFlexibility), in [0,1].

    f = loadMetrics.busiestFactory;
    m = loadMetrics.busiestMachine;

    ids = decoded.machineSchedules{f,m};

    if isempty(ids)
        machineFlex = 0;
    else
        movable = 0;

        for q = 1:numel(ids)
            g = ids(q);
            j = decoded.op.job(g);
            o = decoded.op.operation(g);

            eligible = inst.process.eligibleMachines{f,j,o};
            if numel(eligible) > 1
                movable = movable + 1;
            end
        end

        machineFlex = movable / numel(ids);
    end

    path = critical.onePath;
    n = numel(path);

    if n < 2
        seqFlex = 0;
        pairCount = 0;
        reorderable = 0;
    else
        pairCount = n*(n-1)/2;
        reorderable = 0;

        for a = 1:n-1
            ja = decoded.op.job(path(a));
            for b = a+1:n
                jb = decoded.op.job(path(b));
                if ja ~= jb
                    reorderable = reorderable + 1;
                end
            end
        end

        seqFlex = reorderable / pairCount;
    end

    flex.machineFlexibility = machineFlex;
    flex.sequenceFlexibility = seqFlex;
    flex.combinedFlexibility = 0.5*(machineFlex+seqFlex);
    flex.pathPairCount = pairCount;
    flex.reorderablePairCount = reorderable;
end
