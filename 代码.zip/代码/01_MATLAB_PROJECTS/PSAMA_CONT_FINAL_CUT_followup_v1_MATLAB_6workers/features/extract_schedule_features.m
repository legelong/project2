function feat = extract_schedule_features(decoded,inst,cfg)
%EXTRACT_SCHEDULE_FEATURES Decision/schedule/energy features.
%
% No objective evaluation is performed here. It consumes the decoded schedule
% already produced by the common evaluator.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    critical = analyze_critical_structure(decoded,inst,cfg);
    loadMetrics = compute_load_pressure(decoded,inst,cfg);
    flexibility = compute_flexibility_metrics( ...
        decoded,inst,critical,loadMetrics);
    exposure = compute_energy_exposure(decoded,inst);

    slack = critical.graph.slack;
    tol = cfg.features.criticalTolerance;

    positiveSlack = slack > tol;

    feat.loadPressureRaw = loadMetrics.rawPressure;
    feat.loadPressure = loadMetrics.normalizedPressure;

    % Multi-critical-path robust definition: all zero-slack operations.
    feat.criticalPressure = critical.criticalOperationRatio;

    feat.machineFlexibility = flexibility.machineFlexibility;
    feat.sequenceFlexibility = flexibility.sequenceFlexibility;
    feat.flexibility = flexibility.combinedFlexibility;

    feat.positiveSlackFraction = mean(positiveSlack);
    feat.meanSlack = mean(slack);
    feat.normalizedMeanSlack = ...
        mean(slack) / max(critical.graph.makespan,1);

    feat.peakExposure = exposure.peakExposure;
    feat.valleyExposure = exposure.valleyShare;
    feat.flatExposure = exposure.flatShare;

    feat.processingEnergy = exposure.totalProcessingEnergy;

    feat.numCriticalOperations = critical.numCriticalOperations;
    feat.oneCriticalPathLength = numel(critical.onePath);
    feat.criticalPath = critical.onePath;

    feat.busiestFactory = loadMetrics.busiestFactory;
    feat.busiestMachine = loadMetrics.busiestMachine;
    feat.busiestMachineLoad = loadMetrics.busiestLoad;

    feat.details.critical = critical;
    feat.details.load = loadMetrics;
    feat.details.flexibility = flexibility;
    feat.details.energyExposure = exposure;
end
