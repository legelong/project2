function energy = integrate_energy_by_tariff_band( ...
    power,startTime,duration,tariff)
%INTEGRATE_ENERGY_BY_TARIFF_BAND Energy split into valley/flat/peak periods.
%
% Energy here is power*time. Electricity PRICE is not multiplied in.

    if duration <= 0 || power <= 0
        energy.valley = 0;
        energy.flat = 0;
        energy.peak = 0;
        energy.total = 0;
        return;
    end

    boundaries = [0; ...
                  tariff.valleyIntervals(:); ...
                  tariff.peakIntervals(:); ...
                  tariff.period];
    boundaries = sort(unique(boundaries(:)));

    energy.valley = 0;
    energy.flat = 0;
    energy.peak = 0;

    t = startTime;
    tEnd = startTime + duration;
    tol = 1e-12;

    while t < tEnd-tol
        h = mod(t,tariff.period);

        candidate = boundaries(boundaries > h+tol);
        if isempty(candidate)
            nextBoundary = t + (tariff.period-h);
        else
            nextBoundary = t + (candidate(1)-h);
        end

        segmentEnd = min(tEnd,nextBoundary);
        dt = segmentEnd-t;

        price = tou_price_at_time(t,tariff);

        if abs(price-tariff.valleyPrice) <= tol
            energy.valley = energy.valley + power*dt;
        elseif abs(price-tariff.peakPrice) <= tol
            energy.peak = energy.peak + power*dt;
        else
            energy.flat = energy.flat + power*dt;
        end

        t = segmentEnd;
    end

    energy.total = energy.valley+energy.flat+energy.peak;
end
