function [distance,components] = decision_distance(chromA,chromB,inst)
%DECISION_DISTANCE Equal-weight structural distance over FS/OS/MS/VS.
%
% Each component is normalized Hamming distance in [0,1].
% The total is their arithmetic mean.

    a = split_chromosome(chromA,inst);
    b = split_chromosome(chromB,inst);

    components.FS = mean(a.FS ~= b.FS);
    components.OS = mean(a.OS ~= b.OS);
    components.MS = mean(a.MS ~= b.MS);
    components.VS = mean(abs(a.VS-b.VS) > 1e-12);

    distance = mean([ ...
        components.FS, ...
        components.OS, ...
        components.MS, ...
        components.VS]);
end
