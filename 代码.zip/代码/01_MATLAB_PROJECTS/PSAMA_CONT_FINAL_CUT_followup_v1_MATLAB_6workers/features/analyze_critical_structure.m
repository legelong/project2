function critical = analyze_critical_structure(decoded,inst,cfg)
%ANALYZE_CRITICAL_STRUCTURE Zero-slack set + one deterministic critical path.
%
% Critical pressure later uses ALL zero-slack operations, avoiding the
% instability caused by arbitrarily choosing one path when multiple critical
% paths exist.
%
% Sequence-flexibility calculation may use `onePath`.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    graph = build_schedule_graph(decoded,inst,cfg);
    tol = cfg.features.criticalTolerance;

    criticalIds = find(graph.criticalMask);

    terminal = find( ...
        graph.criticalMask & ...
        abs(graph.earliestFinish-graph.makespan) <= tol);

    if isempty(terminal)
        error('PSAMA:NoCriticalTerminal', ...
            'No zero-slack terminal operation found.');
    end

    % Deterministic terminal: smallest global ID.
    current = min(terminal);
    pathReverse = current;

    while true
        p = graph.predecessors{current};

        if isempty(p)
            break;
        end

        tight = p( ...
            graph.criticalMask(p) & ...
            abs(graph.earliestFinish(p)-graph.earliestStart(current)) <= tol);

        if isempty(tight)
            break;
        end

        % Prefer the predecessor closest in time; break ties by global ID.
        key = [-graph.earliestStart(tight), tight(:)];
        [~,order] = sortrows(key,[1 2]);
        current = tight(order(1));
        pathReverse(end+1) = current; %#ok<AGROW>
    end

    onePath = fliplr(pathReverse);

    critical.graph = graph;
    critical.criticalIds = criticalIds(:)';
    critical.onePath = onePath(:)';
    critical.numCriticalOperations = numel(criticalIds);
    critical.criticalOperationRatio = ...
        numel(criticalIds) / inst.size.totalOperations;
end
