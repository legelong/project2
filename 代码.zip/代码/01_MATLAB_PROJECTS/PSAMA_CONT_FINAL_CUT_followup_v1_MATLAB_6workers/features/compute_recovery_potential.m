function result = compute_recovery_potential( ...
    candidateChromosome,candidateObjective,candidateDecoded, ...
    f1Chromosomes,f1Objectives,inst,cfg)
%COMPUTE_RECOVERY_POTENTIAL Step-4 near-Pareto recovery score.
%
% RP = geometric mean(
%          Pareto proximity,
%          adjustment flexibility,
%          structural novelty )
%
% proximity  = 1/(1+normalized objective-space distance to F1)
% flexibility = Step-4 combined machine/sequence flexibility
% novelty    = minimum decision-space distance to an F1 solution
%
% No tuned weights are introduced in the minimum definition.

    if nargin < 7 || isempty(cfg)
        cfg = make_shared_config();
    end

    if isempty(f1Chromosomes) || isempty(f1Objectives)
        error('F1 reference set must be nonempty.');
    end

    geometry = compute_pareto_geometry(candidateObjective,f1Objectives);
    schedule = extract_schedule_features(candidateDecoded,inst,cfg);

    novelty = inf;
    nearestDecisionIndex = NaN;

    for i = 1:size(f1Chromosomes,1)
        d = decision_distance( ...
            candidateChromosome,f1Chromosomes(i,:),inst);

        if d < novelty
            novelty = d;
            nearestDecisionIndex = i;
        end
    end

    novelty = min(max(novelty,0),1);

    c = cfg.recovery.minimumComponent;

    proximity = min(max(geometry.proximity,0),1);
    flexibility = min(max(schedule.flexibility,0),1);

    rp = ( ...
        max(proximity,c) * ...
        max(flexibility,c) * ...
        max(novelty,c) )^(1/3);

    % If a true component is exactly zero, preserve the intended zero score.
    if proximity == 0 || flexibility == 0 || novelty == 0
        rp = 0;
    end

    result.score = rp;
    result.proximity = proximity;
    result.flexibility = flexibility;
    result.novelty = novelty;
    result.objectiveDistanceToF1 = geometry.distanceToFront;
    result.nearestDecisionF1Index = nearestDecisionIndex;
end
