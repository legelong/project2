function graph = build_schedule_graph(decoded,inst,cfg)
%BUILD_SCHEDULE_GRAPH Build fixed-schedule precedence graph.
%
% Directed arcs:
%   1. technological job precedence;
%   2. consecutive operation order on each physical (factory,machine).
%
% From this DAG, earliest/latest times and total slack are recomputed
% independently of the stored decoded start/finish arrays.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    n = inst.size.totalOperations;
    preds = cell(n,1);
    succs = cell(n,1);

    % Job arcs.
    for j = 1:inst.size.numJobs
        for o = 2:inst.size.operationsPerJob(j)
            a = inst.map.opGlobalIndex(j,o-1);
            b = inst.map.opGlobalIndex(j,o);
            preds{b}(end+1) = a;
            succs{a}(end+1) = b;
        end
    end

    % Machine arcs.
    for f = 1:inst.size.numFactories
        for m = 1:inst.size.numMachinesPerFactory(f)
            ids = decoded.machineSchedules{f,m};
            if numel(ids) <= 1
                continue;
            end

            ids = ids(:);
            sortKey = [decoded.op.start(ids), decoded.op.finish(ids), ids];
            [~,order] = sortrows(sortKey,[1 2 3]);
            ids = ids(order);

            for q = 1:numel(ids)-1
                a = ids(q);
                b = ids(q+1);
                preds{b}(end+1) = a;
                succs{a}(end+1) = b;
            end
        end
    end

    % Topological order is consistent with positive-duration schedule starts.
    ids = (1:n)';
    sortKey = [decoded.op.start(:),decoded.op.finish(:),ids];
    [~,order] = sortrows(sortKey,[1 2 3]);

    ES = zeros(n,1);
    EF = zeros(n,1);

    for q = 1:n
        g = order(q);
        if isempty(preds{g})
            ES(g) = 0;
        else
            ES(g) = max(EF(preds{g}));
        end
        EF(g) = ES(g) + decoded.op.duration(g);
    end

    tol = cfg.features.criticalTolerance;

    if max(abs(ES-decoded.op.start)) > tol || ...
       max(abs(EF-decoded.op.finish)) > tol
        error('PSAMA:GraphScheduleMismatch', ...
            ['Graph-derived earliest schedule does not match the common ' ...
             'active decoder.']);
    end

    Cmax = max(EF);
    LF = Cmax * ones(n,1);
    LS = zeros(n,1);

    for q = n:-1:1
        g = order(q);

        if isempty(succs{g})
            LF(g) = Cmax;
        else
            LF(g) = min(LS(succs{g}));
        end

        LS(g) = LF(g) - decoded.op.duration(g);
    end

    slack = LS - ES;
    slack(abs(slack) <= tol) = 0;

    graph.predecessors = preds;
    graph.successors = succs;
    graph.topologicalOrder = order;
    graph.earliestStart = ES;
    graph.earliestFinish = EF;
    graph.latestStart = LS;
    graph.latestFinish = LF;
    graph.slack = slack;
    graph.makespan = Cmax;
    graph.criticalMask = slack <= tol;
end
