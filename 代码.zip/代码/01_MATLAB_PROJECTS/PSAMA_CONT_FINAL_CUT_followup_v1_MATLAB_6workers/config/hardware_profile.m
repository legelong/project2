function hw = hardware_profile()
%HARDWARE_PROFILE Saved execution profile for the current laptop.
%
% Target machine:
%   Intel Core i9-12900H
%   NVIDIA RTX 3070 Ti Laptop GPU
%
% MATLAB's current local Processes profile reports a maximum of 6 workers,
% so the project default is fixed to 6.
%
% Current PSA-MA implementation is CPU-oriented; GPU is not used.

    hw.name = 'ROG Strix Scar 17 / i9-12900H / RTX3070Ti Laptop';
    hw.defaultWorkers = 6;
    hw.useGPU = false;

    try
        hw.parallelProfile = parallel.defaultClusterProfile;
    catch
        hw.parallelProfile = 'Processes';
    end

    hw.reason = [ ...
        '6 workers match the current MATLAB local-cluster worker limit ' ...
        'and avoid serial fallback while retaining useful laptop thermal headroom.'];
end
