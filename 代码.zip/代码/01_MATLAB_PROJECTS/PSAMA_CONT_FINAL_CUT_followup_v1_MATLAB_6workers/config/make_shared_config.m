function cfg = make_shared_config(instanceDir)
%MAKE_SHARED_CONFIG Strong follow-up control: CONT_FINAL -> CUT.
%
% This project does NOT rerun Stage-I or the matched continuation.
%
% It reuses the immediately preceding completed formal experiment:
%
%   formal20_cut_cbj1_cut_v1
%
% The formal run files saved <=8 diverse CONT_FINAL archive chromosomes under:
%
%   record.followup.contSelectedChromosomes
%
% For each saved continuation schedule this follow-up:
%
%   1) re-decodes the chromosome;
%   2) verifies the saved CONT_FINAL objective;
%   3) uses that schedule's own decoded Cmax as deadline;
%   4) applies global fixed-speed exact CUT;
%   5) augments the original CONT_FINAL front.
%
% New strong control:
%
%   CONT_CUT = CONT_FINAL + CUT-refined continuation representatives
%
% This is deliberately a STRONGER, slightly over-budget control:
%
%   extra computation =
%       original CONT_FINAL actual wall time
%       + follow-up CUT wall time.
%
% It is therefore not called an exactly matched-time comparison.
%
% Main comparison:
%
%   FINAL vs CONT_CUT
%
% If FINAL remains superior, the speed-refinement layer has strong evidence
% against "continue structural search and then apply the same exact timing
% cleanup".

    thisFile = mfilename('fullpath');
    projectRoot = fileparts(fileparts(thisFile));

    if nargin < 1 || isempty(instanceDir)
        instanceDir = fullfile(projectRoot,'datasets','DHFJSP');
    end

    cfg.project.name = 'PSA-MA';
    cfg.project.algorithmVersion = 'PSAMA_CONT_FINAL_CUT_Followup_v1';
    cfg.project.step = 'cont-final-cut-strong-control';
    cfg.project.schemaVersion = 'PSAMA-SCHEMA-CONT-FINAL-CUT-1.0';
    cfg.project.root = projectRoot;

    cfg.paths.dhfjspInstanceDir = instanceDir;

    cfg.problem.speedLevels = [1,2,3,4,5];
    cfg.problem.processingPowerCoefficient = 4.0;
    cfg.problem.idlePower = 1.0;
    cfg.problem.durationRounding = 'floor';
    cfg.problem.minDuration = 1;

    cfg.tariff.period = 24.0;
    cfg.tariff.flatPrice = 0.52;
    cfg.tariff.valleyMultiplier = 0.30;
    cfg.tariff.peakMultiplier = 1.70;
    cfg.tariff.valleyIntervals = [0,6;11,14];
    cfg.tariff.peakIntervals = [16,23];
    cfg.tariff.valleyPrice = cfg.tariff.flatPrice*cfg.tariff.valleyMultiplier;
    cfg.tariff.peakPrice = cfg.tariff.flatPrice*cfg.tariff.peakMultiplier;
    cfg.tariff.idleCostPolicy = 'BETWEEN_CONSECUTIVE_OPERATIONS_ONLY';

    cfg.decoder.method = 'GT_ACTIVE_OS_PRIORITY';
    cfg.decoder.tolerance = 1e-9;
    cfg.decoder.validateChromosome = true;
    cfg.decoder.validateSchedule = true;

    % Compatibility fields required by inherited decode/common utilities.
    cfg.initialization.mode = 'HYBRID_SHARED';
    cfg.initialization.heuristicFraction = 0.70;
    cfg.initialization.lowSpeedFraction = 0.60;

    cfg.evolution.populationSize = 100;
    cfg.evolution.crossoverProbability = 0.80;
    cfg.evolution.segmentMutationProbability = 0.15;
    cfg.evolution.tournamentSize = 2;
    cfg.evolution.archiveMaxSize = 500;
    cfg.evolution.cacheDecoded = true;

    cfg.experiment.baseSeed = 20262201;
    cfg.experiment.localSearchRatio = 0.20;
    cfg.experiment.budgetMode = 'NFE';

    cfg.features.criticalTolerance = 1e-8;
    cfg.features.loadPressureEpsilon = 1e-12;
    cfg.features.contextDimension = 8;

    cfg.recovery.f2TopFraction = 0.30;
    cfg.recovery.minimumComponent = 1e-12;

    cfg.operators.names = { ...
        'A1_LowLoadMachineReassignment', ...
        'A2_CriticalSpeedUp', ...
        'A3_CriticalPathSwap', ...
        'A4_N6CriticalBlockInsertion', ...
        'A5_NoncriticalSlowDown', ...
        'A6_CriticalShortestTimeMachine'};
    cfg.operators.count = numel(cfg.operators.names);
    cfg.operators.maxRandomTrials = 30;

    cfg.setReward.referencePoint = [1.1,1.1];
    cfg.setReward.gapWeight = 0.10;
    cfg.setReward.includeBoundaryGaps = true;

    cfg.learning.method = 'LINUCB_PER_OPERATOR';
    cfg.learning.contextDimension = cfg.features.contextDimension;
    cfg.learning.useIntercept = true;
    cfg.learning.featureDimension = cfg.learning.contextDimension+1;
    cfg.learning.ridgeLambda = 1.0;
    cfg.learning.alpha = 0.20;
    cfg.learning.rewardClip = [];
    cfg.learning.randomTieBreak = true;
    cfg.learning.fillLocalBudget = true;

    cfg.contextAblation.zeroContext = zeros(1,cfg.features.contextDimension);

    cfg.uniform.score = 0.0;
    cfg.uniform.predictedMean = NaN;
    cfg.uniform.uncertainty = NaN;
    cfg.uniform.useRandomTieBreak = true;

    cfg.paretoDiagnosis.sparseQuantile = 0.75;
    cfg.paretoDiagnosis.denseQuantile = 0.25;
    cfg.paretoDiagnosis.kneeQuantile = 0.85;

    cfg.logging.enabled = false;
    cfg.logging.snapshotNFE = [];
    cfg.logging.saveArchiveSnapshots = false;
    cfg.logging.compactNumeric = true;

    cfg.repository.previousProject = '';
    cfg.repository.sourceTag = 'formal20_cut_cbj1_cut_v1';

    % Inherited block fields for config-audit compatibility.
    cfg.cb.blockLengths = [3,5];
    cfg.cb.improvementTolerance = 1e-6;
    cfg.cb.maxAcceptedMoves = 1;
    cfg.cb.requireExact = true;

    cfg.block.scoreSlackWeight = 0.45;
    cfg.block.scoreTariffEventWeight = 0.35;
    cfg.block.scoreExpensiveExposureWeight = 0.20;
    cfg.block.timeGrid = 1;
    cfg.block.maxSolveSeconds = 300;
    cfg.block.relativeGapTolerance = 0;
    cfg.block.absoluteGapTolerance = 1e-8;
    cfg.block.objectiveTolerance = 1e-6;
    cfg.block.maxBinaryVariables = 250000;

    % CUT.
    cfg.cut.priceScale = 1000;
    cfg.cut.requireMaxflow = true;
    cfg.cut.verifyDirectCost = true;
    cfg.cut.verifyCutCertificate = true;

    cfg.cut.milpMaxSolveSeconds = 180;
    cfg.cut.milpRelativeGapTolerance = 0;
    cfg.cut.milpAbsoluteGapTolerance = 1e-8;

    cfg.refinement.maxRepresentativePoints = 8;
    cfg.refinement.hvReferencePoint = [1.1,1.1];

    cfg.statistics.alpha = 0.05;
    cfg.statistics.primaryMetrics = {'HV','IGD'};
    cfg.statistics.primaryContrast = 'FINAL_vs_CONT_CUT';

    cfg.followup.parallelWorkers = 6;

    % Compatibility only for inherited continuation utility; this follow-up
    % never launches a continuation.
    cfg.fairness.continuationGenerationCap = 500;
end
