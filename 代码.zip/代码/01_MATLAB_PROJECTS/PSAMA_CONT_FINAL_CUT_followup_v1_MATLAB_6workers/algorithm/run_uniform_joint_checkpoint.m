function out = run_uniform_joint_checkpoint( ...
    instanceName,runIndex,seed,cfg,options,variant)

    instanceFile = fullfile(cfg.paths.dhfjspInstanceDir,[instanceName '.txt']);
    inst = load_dhfjsp_instance(instanceFile,cfg);

    N = cfg.evolution.populationSize;
    localBudget = max(0,ceil(cfg.experiment.localSearchRatio*N));

    X = get_shared_initial_population(inst,instanceName,runIndex,seed,cfg);

    tRun = tic;

    pop = evaluate_population(X,inst,cfg);
    nfe = pop.nfe;
    pop = assign_rank_and_crowding(pop);
    archive = update_external_archive([],pop,cfg);

    generation = 0;
    snapshots = [];
    log = empty_uniform_compact_log();

    history.generation = 0;
    history.nfe = nfe;
    history.archiveSize = size(archive.objectives,1);
    history.localEvaluations = 0;
    history.budgetShortfall = 0;
    history.uniqueSelectedSources = 0;
    history.maxPairsPerSource = 0;
    history.pairBuildTime = 0;
    history.selectionTime = 0;

    snapshots = update_archive_snapshots( ...
        snapshots,archive,nfe,generation,cfg.logging.snapshotNFE);

    while nfe < options.maxNFE
        rng(seed+100000+generation,'twister');

        remaining = options.maxNFE-nfe;
        nGlobal = min(N,remaining);
        if nGlobal<=0, break; end

        globalX = make_offspring(pop,inst,cfg,nGlobal);
        globalOffspring = evaluate_population(globalX,inst,cfg);
        nfe = nfe+globalOffspring.nfe;

        sourcePop = merge_populations(pop,globalOffspring);
        sourcePop = assign_rank_and_crowding(sourcePop);
        archive = update_external_archive(archive,globalOffspring,cfg);

        remaining = options.maxNFE-nfe;
        B = min(localBudget,remaining);

        rng(seed+200000+generation,'twister');

        [lsPop,archive,diag,eventLog,lsNFE] = ...
            local_search_uniform_joint( ...
                sourcePop,archive,inst,cfg,B,variant,generation+1,nfe);

        nfe = nfe+lsNFE;

        if size(lsPop.chromosomes,1)>0
            merged = merge_populations(sourcePop,lsPop);
        else
            merged = sourcePop;
        end

        pop = environmental_selection(merged,N);
        pop = assign_rank_and_crowding(pop);

        if ~isempty(eventLog)
            f1Idx = [];
            if ~isempty(pop.fronts), f1Idx = pop.fronts{1}; end

            for k = 1:numel(eventLog)
                child = lsPop.chromosomes(k,:);
                inPop = find(ismember(pop.chromosomes,child,'rows'));

                if isempty(inPop) || isempty(f1Idx)
                    eventLog(k).enteredNextPopulationF1 = false;
                else
                    eventLog(k).enteredNextPopulationF1 = ...
                        any(ismember(inPop,f1Idx));
                end
            end

            log = append_uniform_event_batch(log,eventLog);
        end

        generation = generation+1;

        snapshots = update_archive_snapshots( ...
            snapshots,archive,nfe,generation,cfg.logging.snapshotNFE);

        history.generation(end+1,1) = generation; %#ok<AGROW>
        history.nfe(end+1,1) = nfe; %#ok<AGROW>
        history.archiveSize(end+1,1) = size(archive.objectives,1); %#ok<AGROW>
        history.localEvaluations(end+1,1) = lsNFE; %#ok<AGROW>
        history.budgetShortfall(end+1,1) = diag.budgetShortfall; %#ok<AGROW>
        history.uniqueSelectedSources(end+1,1) = diag.uniqueSelectedSources; %#ok<AGROW>
        history.maxPairsPerSource(end+1,1) = diag.maxPairsPerSource; %#ok<AGROW>
        history.pairBuildTime(end+1,1) = diag.pairBuildTime; %#ok<AGROW>
        history.selectionTime(end+1,1) = diag.selectionTime; %#ok<AGROW>
    end

    out.result.instanceName = instanceName;
    out.result.algorithmVersion = cfg.project.algorithmVersion;
    out.result.variant = variant;
    out.result.runIndex = runIndex;
    out.result.seed = seed;
    out.result.archive.chromosomes = archive.chromosomes;
    out.result.archive.objectives = archive.objectives;
    out.result.finalPopulationObjectives = pop.objectives;
    out.result.mechanismLog = log;
    out.result.archiveSnapshots = snapshots;
    out.result.history = history;
    out.result.generations = generation;
    out.result.nfe = nfe;
    out.result.elapsedSeconds = toc(tRun);
    out.result.options = options;

    out.state.instanceName = instanceName;
    out.state.runIndex = runIndex;
    out.state.seed = seed;
    out.state.generation = generation;
    out.state.nfe = nfe;
    out.state.pop = pop;
    out.state.archive = archive;
end
