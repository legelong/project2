function cont = continue_uniform_joint_walltime_snapshots( ...
    checkpoint,targetSeconds,inst,cfg,variant)
%CONTINUE_UNIFORM_JOINT_WALLTIME_SNAPSHOTS One continuation path, 3 targets.
%
% targetSeconds must be nondecreasing. Each snapshot is recorded at the first
% COMPLETE generation boundary whose elapsed time reaches/exceeds the target.
%
% This avoids re-running the prefix separately for CBJ1/CBJ2/CBJ3 fairness.

    targetSeconds = double(targetSeconds(:));

    if any(~isfinite(targetSeconds)) || any(targetSeconds<0)
        error('PSAMA:BadContinuationTargets', ...
            'Continuation targets must be finite and nonnegative.');
    end

    if any(diff(targetSeconds)<-1e-12)
        error('PSAMA:NonmonotoneContinuationTargets', ...
            'Continuation targets must be nondecreasing.');
    end

    N = cfg.evolution.populationSize;
    localBudget = max(0,ceil(cfg.experiment.localSearchRatio*N));

    pop = checkpoint.pop;
    archive = checkpoint.archive;

    generation = checkpoint.generation;
    nfeStart = checkpoint.nfe;
    nfe = nfeStart;
    seed = checkpoint.seed;

    T = numel(targetSeconds);

    snapshots = cell(T,1);
    actualSeconds = nan(T,1);
    generationsAt = nan(T,1);
    nfeAt = nan(T,1);

    nextTarget = 1;
    generationsAdded = 0;

    tCont = tic;

    while nextTarget<=T
        if generationsAdded >= cfg.fairness.continuationGenerationCap
            break;
        end

        rng(seed+100000+generation,'twister');

        globalX = make_offspring(pop,inst,cfg,N);
        globalOffspring = evaluate_population(globalX,inst,cfg);
        nfe = nfe+globalOffspring.nfe;

        sourcePop = merge_populations(pop,globalOffspring);
        sourcePop = assign_rank_and_crowding(sourcePop);
        archive = update_external_archive(archive,globalOffspring,cfg);

        rng(seed+200000+generation,'twister');

        [lsPop,archive,~,~,lsNFE] = ...
            local_search_uniform_joint( ...
                sourcePop,archive,inst,cfg,localBudget,variant, ...
                generation+1,nfe);

        nfe = nfe+lsNFE;

        if size(lsPop.chromosomes,1)>0
            merged = merge_populations(sourcePop,lsPop);
        else
            merged = sourcePop;
        end

        pop = environmental_selection(merged,N);
        pop = assign_rank_and_crowding(pop);

        generation = generation+1;
        generationsAdded = generationsAdded+1;

        elapsed = toc(tCont);

        while nextTarget<=T && ...
              elapsed >= targetSeconds(nextTarget)-1e-12

            snap.archive.chromosomes = archive.chromosomes;
            snap.archive.objectives = archive.objectives;
            snap.finalPopulationObjectives = pop.objectives;
            snap.elapsedSeconds = elapsed;
            snap.generation = generation;
            snap.nfe = nfe;

            snapshots{nextTarget} = snap;
            actualSeconds(nextTarget) = elapsed;
            generationsAt(nextTarget) = generation;
            nfeAt(nextTarget) = nfe;

            nextTarget = nextTarget+1;
        end
    end

    if nextTarget<=T
        error('PSAMA:ContinuationSnapshotCap', ...
            'Generation cap reached before all fairness targets were matched.');
    end

    cont.targets = targetSeconds;
    cont.snapshots = snapshots;
    cont.actualSeconds = actualSeconds;
    cont.overshootSeconds = actualSeconds-targetSeconds;
    cont.overshootFraction = ...
        cont.overshootSeconds./max(targetSeconds,eps);

    cont.generationsAt = generationsAt;
    cont.nfeAt = nfeAt;

    cont.generationsAddedAt = generationsAt-checkpoint.generation;
    cont.nfeAddedAt = nfeAt-nfeStart;

    cont.totalElapsedSeconds = actualSeconds(end);
end
