function cont = continue_uniform_joint_walltime( ...
    checkpoint,targetSeconds,inst,cfg,variant)

    if targetSeconds < 0
        error('PSAMA:NegativeContinuationBudget', ...
            'Continuation wall-time budget must be nonnegative.');
    end

    N = cfg.evolution.populationSize;
    localBudget = max(0,ceil(cfg.experiment.localSearchRatio*N));

    pop = checkpoint.pop;
    archive = checkpoint.archive;

    generation = checkpoint.generation;
    nfeStart = checkpoint.nfe;
    nfe = nfeStart;
    seed = checkpoint.seed;

    generationsAdded = 0;
    tCont = tic;

    while toc(tCont) < targetSeconds
        if generationsAdded >= cfg.fairness.continuationGenerationCap
            break;
        end

        rng(seed+100000+generation,'twister');

        globalX = make_offspring(pop,inst,cfg,N);
        globalOffspring = evaluate_population(globalX,inst,cfg);
        nfe = nfe+globalOffspring.nfe;

        sourcePop = merge_populations(pop,globalOffspring);
        sourcePop = assign_rank_and_crowding(sourcePop);
        archive = update_external_archive(archive,globalOffspring,cfg);

        rng(seed+200000+generation,'twister');

        [lsPop,archive,~,~,lsNFE] = ...
            local_search_uniform_joint( ...
                sourcePop,archive,inst,cfg,localBudget,variant, ...
                generation+1,nfe);

        nfe = nfe+lsNFE;

        if size(lsPop.chromosomes,1)>0
            merged = merge_populations(sourcePop,lsPop);
        else
            merged = sourcePop;
        end

        pop = environmental_selection(merged,N);
        pop = assign_rank_and_crowding(pop);

        generation = generation+1;
        generationsAdded = generationsAdded+1;
    end

    elapsed = toc(tCont);

    cont.archive.chromosomes = archive.chromosomes;
    cont.archive.objectives = archive.objectives;
    cont.finalPopulationObjectives = pop.objectives;

    cont.targetSeconds = targetSeconds;
    cont.elapsedSeconds = elapsed;
    cont.overshootSeconds = max(0,elapsed-targetSeconds);
    cont.overshootFraction = cont.overshootSeconds/max(targetSeconds,eps);

    cont.generationsAdded = generationsAdded;
    cont.nfeAdded = nfe-nfeStart;
    cont.finalNFE = nfe;
    cont.finalGeneration = generation;

    cont.generationCapHit = ...
        generationsAdded >= cfg.fairness.continuationGenerationCap && ...
        elapsed < targetSeconds;
end
