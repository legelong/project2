function next = environmental_selection(merged, populationSize)
%ENVIRONMENTAL_SELECTION Standard NSGA-II environmental selection.

    merged = assign_rank_and_crowding(merged);
    selected = [];

    for fi = 1:numel(merged.fronts)
        front = merged.fronts{fi};

        if numel(selected) + numel(front) <= populationSize
            selected = [selected,front]; %#ok<AGROW>
        else
            remaining = populationSize - numel(selected);

            if remaining > 0
                d = merged.crowding(front);
                orderTable = [-d(:), front(:)];
                [~,order] = sortrows(orderTable,[1 2]);
                chosen = front(order(1:remaining));
                selected = [selected,chosen]; %#ok<AGROW>
            end
            break;
        end
    end

    next = subset_population(merged,selected);
    next = assign_rank_and_crowding(next);
end
