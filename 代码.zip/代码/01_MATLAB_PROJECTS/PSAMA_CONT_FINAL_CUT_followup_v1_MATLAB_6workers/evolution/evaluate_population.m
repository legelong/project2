function pop = evaluate_population(chromosomes, inst, cfg)
%EVALUATE_POPULATION Evaluate a chromosome matrix through the ONE common API.

    N = size(chromosomes,1);

    pop.chromosomes = chromosomes;
    pop.objectives = zeros(N,2);
    pop.decoded = cell(N,1);

    for i = 1:N
        [obj,decoded] = evaluate_solution(chromosomes(i,:),inst,cfg);
        pop.objectives(i,:) = obj;

        if cfg.evolution.cacheDecoded
            pop.decoded{i} = decoded;
        else
            pop.decoded{i} = [];
        end
    end

    pop.rank = inf(N,1);
    pop.crowding = zeros(N,1);
    pop.fronts = {};
    pop.nfe = N;
end
