function merged = merge_populations(a,b)
%MERGE_POPULATIONS Concatenate two population structs.

    merged.chromosomes = [a.chromosomes; b.chromosomes];
    merged.objectives = [a.objectives; b.objectives];
    merged.decoded = [a.decoded; b.decoded];

    n = size(merged.chromosomes,1);
    merged.rank = inf(n,1);
    merged.crowding = zeros(n,1);
    merged.fronts = {};
    merged.nfe = 0;
end
