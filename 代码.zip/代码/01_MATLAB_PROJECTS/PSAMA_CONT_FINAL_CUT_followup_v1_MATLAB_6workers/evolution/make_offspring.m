function offspring = make_offspring(pop, inst, cfg, nOffspring)
%MAKE_OFFSPRING NSGA-II parent selection + crossover + mutation.

    if nargin < 4 || isempty(nOffspring)
        nOffspring = size(pop.chromosomes,1);
    end

    L = size(pop.chromosomes,2);
    offspring = zeros(nOffspring,L);

    parentIndices = tournament_selection(pop, ...
        2*ceil(nOffspring/2),cfg);

    out = 0;
    p = 1;

    while out < nOffspring
        parent1 = pop.chromosomes(parentIndices(p),:);
        parent2 = pop.chromosomes(parentIndices(p+1),:);
        p = p + 2;

        [child1,child2] = crossover_pair(parent1,parent2,inst,cfg);

        child1 = mutate_chromosome(child1,inst,cfg);
        child2 = mutate_chromosome(child2,inst,cfg);

        out = out + 1;
        offspring(out,:) = child1;

        if out < nOffspring
            out = out + 1;
            offspring(out,:) = child2;
        end
    end
end
