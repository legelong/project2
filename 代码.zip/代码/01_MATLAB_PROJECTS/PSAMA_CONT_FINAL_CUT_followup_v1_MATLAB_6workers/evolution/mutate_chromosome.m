function child = mutate_chromosome(parent, inst, cfg)
%MUTATE_CHROMOSOME Independent mutation of FS/OS/MS/VS.

    parts = split_chromosome(parent,inst);
    pm = cfg.evolution.segmentMutationProbability;

    % -------------------------
    % FS mutation
    % -------------------------
    if rand() < pm && inst.size.numFactories > 1
        j = randi(inst.size.numJobs);
        current = parts.FS(j);
        choices = 1:inst.size.numFactories;
        choices(choices == current) = [];
        parts.FS(j) = choices(randi(numel(choices)));
    end

    % -------------------------
    % OS mutation: swap positions with different job IDs
    % -------------------------
    if rand() < pm && numel(parts.OS) > 1
        diffPairsFound = false;

        for trial = 1:20
            pos = randperm(numel(parts.OS),2);
            if parts.OS(pos(1)) ~= parts.OS(pos(2))
                tmp = parts.OS(pos(1));
                parts.OS(pos(1)) = parts.OS(pos(2));
                parts.OS(pos(2)) = tmp;
                diffPairsFound = true;
                break;
            end
        end

        %#ok<NASGU>
        diffPairsFound = diffPairsFound;
    end

    % -------------------------
    % MS mutation
    % -------------------------
    if rand() < pm
        g = randi(inst.size.totalOperations);
        j = inst.map.globalToJob(g);
        o = inst.map.globalToOperation(g);
        f = parts.FS(j);

        eligible = inst.process.eligibleMachines{f,j,o};
        choices = eligible(eligible ~= parts.MS(g));

        if ~isempty(choices)
            parts.MS(g) = choices(randi(numel(choices)));
        end
    end

    % -------------------------
    % VS mutation
    % -------------------------
    if rand() < pm
        g = randi(inst.size.totalOperations);
        speeds = inst.speed.levels(:)';
        choices = speeds(abs(speeds - parts.VS(g)) > 1e-12);

        if ~isempty(choices)
            parts.VS(g) = choices(randi(numel(choices)));
        end
    end

    child = [parts.FS,parts.OS,parts.MS,parts.VS];
    child = repair_chromosome(child,inst);
end
