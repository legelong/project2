function out = subset_population(pop,idx)
%SUBSET_POPULATION Select rows consistently from a population struct.

    idx = idx(:);

    out.chromosomes = pop.chromosomes(idx,:);
    out.objectives = pop.objectives(idx,:);
    out.decoded = pop.decoded(idx);

    if isfield(pop,'rank') && numel(pop.rank) >= max(idx)
        out.rank = pop.rank(idx);
    else
        out.rank = inf(numel(idx),1);
    end

    if isfield(pop,'crowding') && numel(pop.crowding) >= max(idx)
        out.crowding = pop.crowding(idx);
    else
        out.crowding = zeros(numel(idx),1);
    end

    out.fronts = {};
    out.nfe = 0;
end
