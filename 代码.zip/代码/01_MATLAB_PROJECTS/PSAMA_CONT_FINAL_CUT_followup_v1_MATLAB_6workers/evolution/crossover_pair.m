function [child1, child2] = crossover_pair(parent1, parent2, inst, cfg)
%CROSSOVER_PAIR Representation-aware four-segment crossover.
%
% FS: reserved uniform crossover
% OS: precedence-preserving job-set crossover (POX style)
% MS: two-point crossover
% VS: two-point crossover
%
% A common repair follows crossover because changing FS may invalidate MS
% when future datasets have factory-specific eligibility sets.

    if rand() > cfg.evolution.crossoverProbability
        child1 = parent1;
        child2 = parent2;
        return;
    end

    p1 = split_chromosome(parent1,inst);
    p2 = split_chromosome(parent2,inst);

    % -----------------------------
    % FS: reserved uniform crossover
    % -----------------------------
    c1FS = p1.FS;
    c2FS = p2.FS;

    for j = 1:numel(p1.FS)
        if p1.FS(j) == p2.FS(j)
            c1FS(j) = p1.FS(j);
            c2FS(j) = p1.FS(j);
        else
            if rand() < 0.5
                c1FS(j) = p1.FS(j);
                c2FS(j) = p2.FS(j);
            else
                c1FS(j) = p2.FS(j);
                c2FS(j) = p1.FS(j);
            end
        end
    end

    % -----------------------------------------
    % OS: precedence-preserving job-set crossover
    % -----------------------------------------
    J = inst.size.numJobs;
    maskJobs = false(1,J);

    if J == 1
        maskJobs(1) = true;
    else
        k = randi([1,J-1]);
        selected = randperm(J,k);
        maskJobs(selected) = true;
    end

    c1OS = pox_child(p1.OS,p2.OS,maskJobs);
    c2OS = pox_child(p2.OS,p1.OS,maskJobs);

    % -----------------------------
    % MS/VS: two-point crossover
    % -----------------------------
    [c1MS,c2MS] = two_point_segment(p1.MS,p2.MS);
    [c1VS,c2VS] = two_point_segment(p1.VS,p2.VS);

    child1 = [c1FS,c1OS,c1MS,c1VS];
    child2 = [c2FS,c2OS,c2MS,c2VS];

    child1 = repair_chromosome(child1,inst);
    child2 = repair_chromosome(child2,inst);
end

function child = pox_child(primary,secondary,selectedJobs)
    L = numel(primary);
    child = zeros(1,L);
    occupied = false(1,L);

    for pos = 1:L
        j = primary(pos);
        if selectedJobs(j)
            child(pos) = j;
            occupied(pos) = true;
        end
    end

    fillValues = secondary(~selectedJobs(secondary));
    fillPos = find(~occupied);

    if numel(fillValues) ~= numel(fillPos)
        error('PSAMA:POXInternal', ...
            'POX fill length mismatch. Check OS occurrence counts.');
    end

    child(fillPos) = fillValues;
end

function [c1,c2] = two_point_segment(a,b)
    L = numel(a);

    if L < 2
        c1 = a;
        c2 = b;
        return;
    end

    points = sort(randperm(L,2));
    left = points(1);
    right = points(2);

    c1 = a;
    c2 = b;

    c1(left:right) = b(left:right);
    c2(left:right) = a(left:right);
end
