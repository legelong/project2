function selected = tournament_selection(pop, nSelect, cfg)
%TOURNAMENT_SELECTION Binary/multiway NSGA-II tournament.

    N = size(pop.chromosomes,1);
    k = cfg.evolution.tournamentSize;
    selected = zeros(nSelect,1);

    for s = 1:nSelect
        candidates = randi(N,k,1);
        best = candidates(1);

        for q = 2:k
            challenger = candidates(q);

            if pop.rank(challenger) < pop.rank(best)
                best = challenger;
            elseif pop.rank(challenger) == pop.rank(best)
                if pop.crowding(challenger) > pop.crowding(best)
                    best = challenger;
                elseif pop.crowding(challenger) == pop.crowding(best)
                    if rand() < 0.5
                        best = challenger;
                    end
                end
            end
        end

        selected(s) = best;
    end
end
