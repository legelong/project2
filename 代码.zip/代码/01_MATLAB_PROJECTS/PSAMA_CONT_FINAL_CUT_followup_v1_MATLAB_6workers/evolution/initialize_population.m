function chromosomes = initialize_population(inst, cfg, populationSize)
%INITIALIZE_POPULATION Shared hybrid initialization.
%
% The SAME initializer is intended for the clean baseline, the proposed
% method, and internal ablations.
%
% Heuristic individuals:
%   FS: randomized load-aware factory assignment using factory-specific
%       estimated job workload.
%   OS: urgency-weighted roulette over currently available next operations.
%   MS: load-aware eligible-machine selection while scanning OS.
%   VS: uniform sampling from the lowest configured speed subset.
%
% Random individuals:
%   legal random FS/OS/MS/VS.

    if nargin < 3 || isempty(populationSize)
        populationSize = cfg.evolution.populationSize;
    end

    N = populationSize;
    L = inst.encoding.totalLength;
    chromosomes = zeros(N, L);

    nHeuristic = round(cfg.initialization.heuristicFraction * N);

    % Job-factory processing-load estimate independent of later search.
    jobFactoryLoad = estimate_job_factory_load(inst);

    for i = 1:N
        if i <= nHeuristic
            chromosome = make_heuristic_individual(inst, cfg, jobFactoryLoad);
        else
            chromosome = make_random_individual(inst);
        end

        validate_chromosome(chromosome, inst, true);
        chromosomes(i,:) = chromosome;
    end
end

function estimate = estimate_job_factory_load(inst)
    J = inst.size.numJobs;
    F = inst.size.numFactories;
    estimate = zeros(J,F);

    for j = 1:J
        for f = 1:F
            total = 0;
            for o = 1:inst.size.operationsPerJob(j)
                times = inst.process.baseTimeByEligible{f,j,o};
                total = total + mean(times);
            end
            estimate(j,f) = total;
        end
    end
end

function chromosome = make_heuristic_individual(inst, cfg, jobFactoryLoad)
    J = inst.size.numJobs;
    F = inst.size.numFactories;
    Mvec = inst.size.numMachinesPerFactory(:)';
    totalOps = inst.size.totalOperations;

    % -------------------------
    % FS: load-aware assignment
    % -------------------------
    FS = zeros(1,J);
    factoryLoad = zeros(1,F);
    jobOrder = randperm(J);

    for q = 1:J
        j = jobOrder(q);
        candidate = factoryLoad + jobFactoryLoad(j,:);
        best = min(candidate);
        ties = find(abs(candidate - best) <= 1e-12);
        f = ties(randi(numel(ties)));

        FS(j) = f;
        factoryLoad(f) = factoryLoad(f) + jobFactoryLoad(j,f);
    end

    % -----------------------------------------
    % Factory mean operation time for urgency
    % -----------------------------------------
    factoryMean = zeros(1,F);
    for f = 1:F
        vals = [];
        for j = 1:J
            for o = 1:inst.size.operationsPerJob(j)
                vals = [vals, inst.process.baseTimeByEligible{f,j,o}]; %#ok<AGROW>
            end
        end
        factoryMean(f) = mean(vals);
    end

    % -----------------------------------------
    % OS: urgency-weighted valid job sequence
    % -----------------------------------------
    OS = zeros(1,totalOps);
    nextOp = ones(J,1);
    outPos = 0;

    while outPos < totalOps
        availableJobs = find(nextOp <= inst.size.operationsPerJob);
        weights = zeros(numel(availableJobs),1);

        for q = 1:numel(availableJobs)
            j = availableJobs(q);
            o = nextOp(j);
            f = FS(j);

            opEstimate = mean(inst.process.baseTimeByEligible{f,j,o});
            weights(q) = max(opEstimate / max(factoryMean(f),eps), eps);
        end

        selectedLocal = weighted_choice(weights);
        j = availableJobs(selectedLocal);

        outPos = outPos + 1;
        OS(outPos) = j;
        nextOp(j) = nextOp(j) + 1;
    end

    % ---------------------------------------------------------
    % MS: load-aware eligible-machine assignment scanning OS
    % ---------------------------------------------------------
    MS = zeros(1,totalOps);
    machineLoad = cell(1,F);
    for f = 1:F
        machineLoad{f} = zeros(1,Mvec(f));
    end

    occurrence = zeros(J,1);

    for pos = 1:totalOps
        j = OS(pos);
        occurrence(j) = occurrence(j) + 1;
        o = occurrence(j);
        f = FS(j);
        g = inst.map.opGlobalIndex(j,o);

        eligible = inst.process.eligibleMachines{f,j,o};
        pTimes = inst.process.baseTimeByEligible{f,j,o};

        candidateLoad = zeros(1,numel(eligible));
        for k = 1:numel(eligible)
            m = eligible(k);
            candidateLoad(k) = machineLoad{f}(m) + pTimes(k);
        end

        best = min(candidateLoad);
        ties = find(abs(candidateLoad-best) <= 1e-12);
        k = ties(randi(numel(ties)));
        m = eligible(k);

        MS(g) = m;
        machineLoad{f}(m) = machineLoad{f}(m) + pTimes(k);
    end

    % ----------------------------------------
    % VS: low-speed subset for heuristic part
    % ----------------------------------------
    speeds = inst.speed.levels(:)';
    nLow = max(1, ceil(cfg.initialization.lowSpeedFraction * numel(speeds)));
    lowSpeeds = speeds(1:nLow);

    VS = zeros(1,totalOps);
    for g = 1:totalOps
        VS(g) = lowSpeeds(randi(numel(lowSpeeds)));
    end

    chromosome = [FS, OS, MS, VS];
end

function chromosome = make_random_individual(inst)
    J = inst.size.numJobs;
    F = inst.size.numFactories;
    totalOps = inst.size.totalOperations;

    FS = randi(F,1,J);

    OS = zeros(1,totalOps);
    p = 0;
    for j = 1:J
        n = inst.size.operationsPerJob(j);
        OS(p+1:p+n) = j;
        p = p+n;
    end
    OS = OS(randperm(totalOps));

    MS = zeros(1,totalOps);
    VS = zeros(1,totalOps);
    speeds = inst.speed.levels(:)';

    for g = 1:totalOps
        j = inst.map.globalToJob(g);
        o = inst.map.globalToOperation(g);
        f = FS(j);

        eligible = inst.process.eligibleMachines{f,j,o};
        MS(g) = eligible(randi(numel(eligible)));
        VS(g) = speeds(randi(numel(speeds)));
    end

    chromosome = [FS, OS, MS, VS];
end

function idx = weighted_choice(weights)
    weights = weights(:);
    weights(~isfinite(weights) | weights < 0) = 0;

    total = sum(weights);
    if total <= 0
        idx = randi(numel(weights));
        return;
    end

    u = rand() * total;
    c = cumsum(weights);
    idx = find(c >= u, 1, 'first');

    if isempty(idx)
        idx = numel(weights);
    end
end
