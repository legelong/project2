function chromosome = repair_chromosome(chromosome, inst)
%REPAIR_CHROMOSOME Common feasibility repair after variation.
%
% Internal operators should already preserve most validity. This function is
% deliberately conservative and only repairs actual infeasibility.

    parts = split_chromosome(chromosome,inst);

    J = inst.size.numJobs;
    F = inst.size.numFactories;
    totalOps = inst.size.totalOperations;

    % -------------------------
    % FS repair
    % -------------------------
    for j = 1:J
        value = parts.FS(j);
        if ~isfinite(value) || value ~= round(value) || value < 1 || value > F
            parts.FS(j) = randi(F);
        end
    end

    % -------------------------
    % OS count repair
    % -------------------------
    required = inst.size.operationsPerJob(:);
    counts = zeros(J,1);

    validPos = true(1,totalOps);
    for pos = 1:totalOps
        value = parts.OS(pos);

        if ~isfinite(value) || value ~= round(value) || value < 1 || value > J
            validPos(pos) = false;
        else
            counts(value) = counts(value) + 1;
        end
    end

    % Mark excess valid occurrences for replacement.
    currentSeen = zeros(J,1);
    for pos = 1:totalOps
        if ~validPos(pos)
            continue;
        end

        j = parts.OS(pos);
        currentSeen(j) = currentSeen(j) + 1;
        if currentSeen(j) > required(j)
            validPos(pos) = false;
        end
    end

    % Recompute retained counts.
    retained = zeros(J,1);
    for pos = 1:totalOps
        if validPos(pos)
            retained(parts.OS(pos)) = retained(parts.OS(pos)) + 1;
        end
    end

    missingJobs = [];
    for j = 1:J
        nMissing = required(j) - retained(j);
        if nMissing > 0
            missingJobs = [missingJobs, repmat(j,1,nMissing)]; %#ok<AGROW>
        end
    end

    replacePos = find(~validPos);

    if numel(replacePos) ~= numel(missingJobs)
        error('PSAMA:OSRepairInternal', ...
            'OS repair count mismatch.');
    end

    if ~isempty(replacePos)
        missingJobs = missingJobs(randperm(numel(missingJobs)));
        parts.OS(replacePos) = missingJobs;
    end

    % -------------------------
    % MS repair conditioned on repaired FS
    % -------------------------
    for g = 1:totalOps
        j = inst.map.globalToJob(g);
        o = inst.map.globalToOperation(g);
        f = parts.FS(j);

        eligible = inst.process.eligibleMachines{f,j,o};
        value = parts.MS(g);

        if ~isfinite(value) || value ~= round(value) || ~ismember(value,eligible)
            parts.MS(g) = eligible(randi(numel(eligible)));
        end
    end

    % -------------------------
    % VS repair
    % -------------------------
    speeds = inst.speed.levels(:)';

    for g = 1:totalOps
        value = parts.VS(g);
        if ~isfinite(value) || ~any(abs(speeds-value) <= 1e-12)
            parts.VS(g) = speeds(randi(numel(speeds)));
        end
    end

    chromosome = [parts.FS,parts.OS,parts.MS,parts.VS];
    validate_chromosome(chromosome,inst,true);
end
