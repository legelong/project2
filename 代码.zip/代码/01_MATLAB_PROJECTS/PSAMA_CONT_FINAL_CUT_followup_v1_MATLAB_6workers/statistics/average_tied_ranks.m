function ranks = average_tied_ranks(values)
%AVERAGE_TIED_RANKS Toolbox-free ascending ranks with average ties.

    values = values(:);
    n = numel(values);

    [sorted,order] = sort(values,'ascend');
    sortedRanks = zeros(n,1);

    i = 1;
    while i <= n
        j = i;
        while j < n && abs(sorted(j+1)-sorted(i)) <= 1e-12
            j = j+1;
        end

        r = mean(i:j);
        sortedRanks(i:j) = r;
        i = j+1;
    end

    ranks = zeros(n,1);
    ranks(order) = sortedRanks;
end
