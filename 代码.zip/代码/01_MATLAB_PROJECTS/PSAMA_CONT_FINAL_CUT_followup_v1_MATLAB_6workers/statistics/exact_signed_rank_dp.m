function out = exact_signed_rank_dp(improvement)
%EXACT_SIGNED_RANK_DP Exact two-sided paired Wilcoxon signed-rank test.
%
% Positive input means the second method is better.
% Zeros are removed.
% Average ranks are multiplied by 2, giving integer subset sums.
% Dynamic programming computes the exact sign-flip distribution.

    d = double(improvement(:));
    d = d(isfinite(d));
    d(abs(d)<=1e-14) = [];

    n = numel(d);

    out.n = n;
    out.wPlus = 0;
    out.wMinus = 0;
    out.rankBiserial = 0;
    out.pTwoSided = 1;

    if n==0
        return;
    end

    ranks = tied_rank_local(abs(d));
    rank2 = round(2*ranks);

    total2 = sum(rank2);
    observedW2 = sum(rank2(d>0));
    centerDistance = abs(2*observedW2-total2);

    counts = zeros(total2+1,1,'uint64');
    counts(1) = uint64(1);

    currentMax = 0;

    for i = 1:n
        r = rank2(i);

        next = counts;

        for s = 0:currentMax
            c = counts(s+1);

            if c>0
                next(s+r+1) = next(s+r+1)+c;
            end
        end

        counts = next;
        currentMax = currentMax+r;
    end

    extreme = uint64(0);

    for s = 0:total2
        if abs(2*s-total2) >= centerDistance
            extreme = extreme+counts(s+1);
        end
    end

    totalAssignments = 2^n;

    Wplus = observedW2/2;
    totalRank = total2/2;
    Wminus = totalRank-Wplus;

    out.wPlus = Wplus;
    out.wMinus = Wminus;
    out.rankBiserial = (Wplus-Wminus)/max(totalRank,eps);
    out.pTwoSided = double(extreme)/totalAssignments;
end

function r = tied_rank_local(x)
    x = double(x(:));
    [xs,ord] = sort(x,'ascend');
    rs = zeros(size(xs));

    i = 1;

    while i<=numel(xs)
        j = i;

        while j<numel(xs) && abs(xs(j+1)-xs(i))<=1e-12
            j = j+1;
        end

        rs(i:j) = (i+j)/2;
        i = j+1;
    end

    r = zeros(size(x));
    r(ord) = rs;
end
