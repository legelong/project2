function result = paired_wilcoxon(x,y)
%PAIRED_WILCOXON Paired two-sided Wilcoxon signed-rank test.
%
% Uses MATLAB signrank when available. Otherwise uses a normal approximation
% with tie-corrected variance.

    x = x(:);
    y = y(:);

    valid = isfinite(x) & isfinite(y);
    d = x(valid)-y(valid);
    d(abs(d) <= 1e-12) = [];

    result.n = numel(d);
    result.medianDifference = median(d);

    if isempty(d)
        result.p = 1;
        result.Wplus = 0;
        result.Wminus = 0;
        return;
    end

    if exist('signrank','file') == 2
        try
            p = signrank(x(valid),y(valid),'method','approximate');
        catch
            p = signrank(x(valid),y(valid));
        end
        result.p = p;

        ranks = average_tied_ranks(abs(d));
        result.Wplus = sum(ranks(d > 0));
        result.Wminus = sum(ranks(d < 0));
        return;
    end

    absd = abs(d);
    ranks = average_tied_ranks(absd);

    Wplus = sum(ranks(d > 0));
    Wminus = sum(ranks(d < 0));

    n = numel(d);
    mu = n*(n+1)/4;

    % Tie correction for Var(W+).
    [u,~,idx] = unique(absd);
    counts = accumarray(idx,1);
    tieTerm = sum(counts.^3-counts);

    varW = n*(n+1)*(2*n+1)/24 - tieTerm/48;
    varW = max(varW,eps);

    z = (abs(Wplus-mu)-0.5)/sqrt(varW);
    p = erfc(z/sqrt(2));

    result.p = min(max(p,0),1);
    result.Wplus = Wplus;
    result.Wminus = Wminus;
end
