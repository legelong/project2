function igd = compute_igd(approximation,reference)
%COMPUTE_IGD Inverted generational distance in normalized objective space.

    if isempty(approximation) || isempty(reference)
        igd = inf;
        return;
    end

    d = zeros(size(reference,1),1);

    for i = 1:size(reference,1)
        delta = approximation-reference(i,:);
        dist = sqrt(sum(delta.^2,2));
        d(i) = min(dist);
    end

    igd = mean(d);
end
