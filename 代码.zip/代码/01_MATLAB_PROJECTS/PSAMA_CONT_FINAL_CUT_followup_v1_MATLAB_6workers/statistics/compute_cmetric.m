function c = compute_cmetric(A,B)
%COMPUTE_CMETRIC Fraction of B weakly dominated by at least one point in A.

    if isempty(B)
        c = NaN;
        return;
    end

    covered = false(size(B,1),1);

    for j = 1:size(B,1)
        for i = 1:size(A,1)
            if all(A(i,:) <= B(j,:))
                covered(j) = true;
                break;
            end
        end
    end

    c = mean(covered);
end
