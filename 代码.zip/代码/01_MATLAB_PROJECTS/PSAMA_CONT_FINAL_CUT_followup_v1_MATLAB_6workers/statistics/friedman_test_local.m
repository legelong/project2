function result = friedman_test_local(X)
%FRIEDMAN_TEST_LOCAL Friedman test with runs as paired blocks.
%
% Rows: paired runs
% Cols: algorithms

    X = X(all(isfinite(X),2),:);
    [n,k] = size(X);

    result.n = n;
    result.k = k;

    if n < 2 || k < 2
        result.p = NaN;
        result.chiSquare = NaN;
        result.meanRanks = nan(1,k);
        return;
    end

    if exist('friedman','file') == 2
        try
            [p,tbl,stats] = friedman(X,1,'off');
            result.p = p;

            ranks = zeros(size(X));
            for i = 1:n
                ranks(i,:) = average_tied_ranks(X(i,:))';
            end

            result.meanRanks = mean(ranks,1);

            chi2 = NaN;
            if iscell(tbl) && size(tbl,1) >= 2 && size(tbl,2) >= 5
                candidate = tbl{2,5};
                if isnumeric(candidate)
                    chi2 = candidate;
                end
            end
            result.chiSquare = chi2;
            return;
        catch
        end
    end

    ranks = zeros(size(X));
    for i = 1:n
        ranks(i,:) = average_tied_ranks(X(i,:))';
    end

    rankSums = sum(ranks,1);
    Q = 12/(n*k*(k+1))*sum(rankSums.^2) - 3*n*(k+1);

    df = k-1;
    p = gammainc(Q/2,df/2,'upper');

    result.p = p;
    result.chiSquare = Q;
    result.meanRanks = mean(ranks,1);
end
