function adjusted = holm_adjust(p)
%HOLM_ADJUST Holm step-down adjusted p-values.

    p = double(p(:));
    m = numel(p);

    [ps,ord] = sort(p,'ascend');
    adjSorted = zeros(m,1);

    running = 0;

    for i = 1:m
        value = (m-i+1)*ps(i);
        running = max(running,value);
        adjSorted(i) = min(1,running);
    end

    adjusted = zeros(m,1);
    adjusted(ord) = adjSorted;
end
