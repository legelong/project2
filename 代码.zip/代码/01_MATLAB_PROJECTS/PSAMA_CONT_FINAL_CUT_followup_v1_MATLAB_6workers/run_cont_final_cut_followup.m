function outputs = run_cont_final_cut_followup()
%RUN_CONT_FINAL_CUT_FOLLOWUP Cheap strong control on saved formal raws.

    setup_project();

    cfg = make_shared_config();
    expCfg = make_cont_final_cut_followup_experiment();

    assert_digraph_maxflow_available();

    fprintf('\n============================================================\n');
    fprintf('PSA-MA CONT_FINAL -> CUT STRONG CONTROL v1\n');
    fprintf('Source    : completed formal20_cut_cbj1_cut_v1\n');
    fprintf('Instances : all 20\n');
    fprintf('Runs      : 20 each\n');
    fprintf('New work  : CUT only; no Stage-I / continuation rerun\n');
    fprintf('Control   : CONT_CUT = CONT_FINAL + CUT representatives\n');
    fprintf('Primary   : FINAL vs CONT_CUT\n');
    fprintf('Workers   : %d Processes workers\n',expCfg.workers);
    fprintf('============================================================\n\n');

    sourceReport = validate_followup_sources(cfg,expCfg); %#ok<NASGU>

    resultRoot = fullfile(cfg.project.root,'results',expCfg.tag);

    if ~isfolder(resultRoot)
        mkdir(resultRoot);
    end

    save(fullfile(resultRoot,'experiment_config.mat'), ...
        'cfg','expCfg','sourceReport','-v7');

    for ii = 1:numel(expCfg.instances)
        d = fullfile(resultRoot,'raw',expCfg.instances{ii});

        if ~isfolder(d)
            mkdir(d);
        end
    end

    tasks = struct('instanceName',{},'runIndex',{});
    t = 0;

    for ii = 1:numel(expCfg.instances)
        for rr = 1:expCfg.numRuns
            t = t+1;
            tasks(t).instanceName = expCfg.instances{ii};
            tasks(t).runIndex = rr;
        end
    end

    poolInfo = ensure_parallel_pool(expCfg.workers); %#ok<NASGU>
    summaries = cell(numel(tasks),1);

    parfor i = 1:numel(tasks)
        summaries{i} = run_cont_final_cut_followup_task( ...
            tasks(i),cfg,expCfg,resultRoot);

        fprintf(['[DONE] %s run%02d | selected=%d | ' ...
                 'CUT %.3fs | strong extra/FINAL=%+.1f%%\n'], ...
            tasks(i).instanceName,tasks(i).runIndex, ...
            summaries{i}.selectedPoints, ...
            summaries{i}.followupCUTSeconds, ...
            100*summaries{i}.strongControlExtraOverFinalFraction);
    end

    fprintf('\nBuilding strong-control paired metrics...\n');

    outputs = postprocess_cont_final_cut_followup( ...
        resultRoot,cfg,expCfg);

    save(fullfile(resultRoot,'cont_final_cut_followup_outputs.mat'), ...
        'outputs','-v7');

    fprintf('\n============================================================\n');
    fprintf('[CONT_FINAL -> CUT FOLLOW-UP COMPLETE]\n');
    fprintf('Results: %s\n',resultRoot);
    fprintf('============================================================\n');
end
