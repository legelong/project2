function [child,meta] = operator_A4_n6_insertion( ...
    parent,parentDecoded,inst,cfg)
%OPERATOR_A4_N6_INSERTION N6-style critical-block OS insertion.
%
% A maximal same-machine critical block with length >= 3 is chosen.
% One internal operation is selected and its OS token is inserted either
% immediately before the block-head token or immediately after the block-tail
% token.
%
% No objective evaluation occurs inside the operator.

    parts = split_chromosome(parent,inst);
    critical = analyze_critical_structure(parentDecoded,inst,cfg);
    blocks = find_critical_blocks(parentDecoded,critical);

    valid = {};
    for i = 1:numel(blocks)
        if numel(blocks{i}) >= 3
            valid{end+1} = blocks{i}; %#ok<AGROW>
        end
    end

    meta = base_meta(4,cfg);
    meta.candidateCount = numel(valid);

    if isempty(valid)
        child = parent;
        meta.reason = 'No representative critical block has length >= 3.';
        return;
    end

    block = valid{randi(numel(valid))};

    internal = block(2:end-1);
    g = internal(randi(numel(internal)));

    head = block(1);
    tail = block(end);

    fromPos = parentDecoded.op.osPriority(g);
    headPos = parentDecoded.op.osPriority(head);
    tailPos = parentDecoded.op.osPriority(tail);

    if rand() < 0.5
        mode = 'before';
        targetPos = headPos;
    else
        mode = 'after';
        targetPos = tailPos;
    end

    newOS = move_os_token(parts.OS,fromPos,targetPos,mode);

    parts.OS = newOS;
    child = [parts.FS,parts.OS,parts.MS,parts.VS];
    child = repair_chromosome(child,inst);

    meta.changed = ~isequal(child,parent);
    meta.globalOperation = g;
    meta.block = block;
    meta.fromOSPosition = fromPos;
    meta.targetOSPosition = targetPos;
    meta.insertionMode = mode;
    meta.reason = 'Internal critical-block OS token inserted toward a block boundary.';
end

function meta = base_meta(id,cfg)
    meta.operatorId = id;
    meta.operatorName = cfg.operators.names{id};
    meta.changed = false;
    meta.evaluationsInsideOperator = 0;
    meta.candidateCount = 0;
    meta.globalOperation = NaN;
    meta.block = [];
    meta.fromOSPosition = NaN;
    meta.targetOSPosition = NaN;
    meta.insertionMode = '';
    meta.reason = '';
end
