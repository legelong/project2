function [child,meta] = apply_operator( ...
    operatorId,parent,parentDecoded,inst,cfg)
%APPLY_OPERATOR One common Step-5 operator API.
%
% IMPORTANT:
%   This function NEVER evaluates the child.
%   A changed child consumes exactly one NFE only when the caller later invokes
%   evaluate_solution(). This separation is required for fair computation
%   accounting.

    switch operatorId
        case 1
            [child,meta] = operator_A1_lowload_machine( ...
                parent,parentDecoded,inst,cfg);
        case 2
            [child,meta] = operator_A2_critical_speedup( ...
                parent,parentDecoded,inst,cfg);
        case 3
            [child,meta] = operator_A3_critical_path_swap( ...
                parent,parentDecoded,inst,cfg);
        case 4
            [child,meta] = operator_A4_n6_insertion( ...
                parent,parentDecoded,inst,cfg);
        case 5
            [child,meta] = operator_A5_noncritical_slowdown( ...
                parent,parentDecoded,inst,cfg);
        case 6
            [child,meta] = operator_A6_shortest_time_machine( ...
                parent,parentDecoded,inst,cfg);
        otherwise
            error('PSAMA:UnknownOperator', ...
                'operatorId must be in 1..%d.',cfg.operators.count);
    end

    if meta.evaluationsInsideOperator ~= 0
        error('PSAMA:HiddenEvaluation', ...
            'Problem-specific operator performed a hidden objective evaluation.');
    end

    validate_chromosome(child,inst,true);
end
