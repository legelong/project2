function [child,meta] = operator_A6_shortest_time_machine( ...
    parent,parentDecoded,inst,cfg)
%OPERATOR_A6_SHORTEST_TIME_MACHINE Reassign critical op to faster machine.
%
% A representative critical-path operation is eligible only if another
% machine in the assigned factory has a STRICTLY shorter baseline processing
% time than its current machine.

    parts = split_chromosome(parent,inst);
    critical = analyze_critical_structure(parentDecoded,inst,cfg);
    path = critical.onePath;

    candidates = struct('g',{},'machines',{});

    for q = 1:numel(path)
        g = path(q);
        j = parentDecoded.op.job(g);
        o = parentDecoded.op.operation(g);
        f = parentDecoded.op.factory(g);
        current = parts.MS(g);

        eligible = inst.process.eligibleMachines{f,j,o};
        times = inst.process.baseTimeByEligible{f,j,o};

        currentPos = find(eligible == current,1,'first');
        currentTime = times(currentPos);

        betterMask = (eligible ~= current) & (times < currentTime);
        betterMachines = eligible(betterMask);

        if ~isempty(betterMachines)
            entry.g = g;
            entry.machines = betterMachines;
            candidates(end+1) = entry; %#ok<AGROW>
        end
    end

    meta = base_meta(6,cfg);
    meta.candidateCount = numel(candidates);

    if isempty(candidates)
        child = parent;
        meta.reason = 'No critical-path operation has a strictly faster eligible alternative machine.';
        return;
    end

    c = candidates(randi(numel(candidates)));
    g = c.g;

    j = parentDecoded.op.job(g);
    o = parentDecoded.op.operation(g);
    f = parentDecoded.op.factory(g);

    eligible = inst.process.eligibleMachines{f,j,o};
    times = inst.process.baseTimeByEligible{f,j,o};

    candidateTimes = zeros(size(c.machines));
    for k = 1:numel(c.machines)
        pos = find(eligible == c.machines(k),1,'first');
        candidateTimes(k) = times(pos);
    end

    bestTime = min(candidateTimes);
    bestMachines = c.machines(candidateTimes == bestTime);
    newMachine = bestMachines(randi(numel(bestMachines)));

    oldMachine = parts.MS(g);
    parts.MS(g) = newMachine;

    child = [parts.FS,parts.OS,parts.MS,parts.VS];
    child = repair_chromosome(child,inst);

    meta.changed = ~isequal(child,parent);
    meta.globalOperation = g;
    meta.oldValue = oldMachine;
    meta.newValue = newMachine;
    meta.reason = 'Critical-path operation reassigned to a strictly shorter-baseline-time machine.';
end

function meta = base_meta(id,cfg)
    meta.operatorId = id;
    meta.operatorName = cfg.operators.names{id};
    meta.changed = false;
    meta.evaluationsInsideOperator = 0;
    meta.candidateCount = 0;
    meta.globalOperation = NaN;
    meta.oldValue = NaN;
    meta.newValue = NaN;
    meta.reason = '';
end
