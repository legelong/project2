function newOS = move_os_token(OS,fromPos,targetPos,mode)
%MOVE_OS_TOKEN Remove one OS token and insert it around targetPos.
%
% mode:
%   'before'  insert immediately before the target token
%   'after'   insert immediately after the target token
%
% OS occurrence counts are preserved automatically.

    L = numel(OS);

    if fromPos < 1 || fromPos > L || targetPos < 1 || targetPos > L
        error('PSAMA:OSMoveIndex','OS move index out of range.');
    end

    if fromPos == targetPos
        newOS = OS;
        return;
    end

    token = OS(fromPos);
    reduced = OS;
    reduced(fromPos) = [];

    % After removing fromPos, target index may shift.
    adjustedTarget = targetPos;
    if fromPos < targetPos
        adjustedTarget = targetPos - 1;
    end

    switch lower(mode)
        case 'before'
            insertAt = adjustedTarget;
        case 'after'
            insertAt = adjustedTarget + 1;
        otherwise
            error('PSAMA:UnknownOSMoveMode','Unknown mode: %s',mode);
    end

    insertAt = max(1,min(insertAt,L));

    if insertAt == 1
        newOS = [token,reduced];
    elseif insertAt > numel(reduced)
        newOS = [reduced,token];
    else
        newOS = [reduced(1:insertAt-1),token,reduced(insertAt:end)];
    end

    if numel(newOS) ~= L
        error('PSAMA:OSMoveInternal','OS move changed sequence length.');
    end
end
