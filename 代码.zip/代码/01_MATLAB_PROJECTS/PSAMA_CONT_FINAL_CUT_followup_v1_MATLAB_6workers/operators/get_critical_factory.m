function criticalFactory = get_critical_factory(decoded,cfg)
%GET_CRITICAL_FACTORY One critical factory, random tie break.
%
% Tie breaking remains stochastic but reproducible under the experiment seed.

    if nargin < 2 || isempty(cfg)
        cfg = make_shared_config();
    end

    cmax = max(decoded.factoryMakespan);
    candidates = find( ...
        abs(decoded.factoryMakespan-cmax) <= cfg.features.criticalTolerance);

    if isempty(candidates)
        error('PSAMA:NoCriticalFactory','No critical factory identified.');
    end

    criticalFactory = candidates(randi(numel(candidates)));
end
