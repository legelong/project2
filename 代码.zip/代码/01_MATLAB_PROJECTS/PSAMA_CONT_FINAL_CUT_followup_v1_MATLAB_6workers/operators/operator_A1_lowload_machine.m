function [child,meta] = operator_A1_lowload_machine( ...
    parent,parentDecoded,inst,cfg)
%OPERATOR_A1_LOWLOAD_MACHINE Critical-path operation -> less-used machine.
%
% One operation on the representative critical path is reassigned to an
% eligible alternative physical machine having a strictly smaller current
% operation count than the current machine.
%
% No objective evaluation occurs inside the operator.

    parts = split_chromosome(parent,inst);
    critical = analyze_critical_structure(parentDecoded,inst,cfg);
    path = critical.onePath;

    candidates = struct('g',{},'machines',{});

    for q = 1:numel(path)
        g = path(q);
        j = parentDecoded.op.job(g);
        o = parentDecoded.op.operation(g);
        f = parentDecoded.op.factory(g);
        current = parts.MS(g);

        eligible = inst.process.eligibleMachines{f,j,o};
        alternative = eligible(eligible ~= current);

        if isempty(alternative)
            continue;
        end

        currentCount = numel(parentDecoded.machineSchedules{f,current});
        altCounts = zeros(size(alternative));

        for k = 1:numel(alternative)
            altCounts(k) = numel( ...
                parentDecoded.machineSchedules{f,alternative(k)});
        end

        better = alternative(altCounts < currentCount);

        if ~isempty(better)
            entry.g = g;
            entry.machines = better;
            candidates(end+1) = entry; %#ok<AGROW>
        end
    end

    meta = base_meta(1,cfg);
    meta.candidateCount = numel(candidates);

    if isempty(candidates)
        child = parent;
        meta.reason = 'No critical-path operation has a strictly lower-count alternative machine.';
        return;
    end

    c = candidates(randi(numel(candidates)));
    g = c.g;

    f = parentDecoded.op.factory(g);
    counts = zeros(size(c.machines));
    for k = 1:numel(c.machines)
        counts(k) = numel(parentDecoded.machineSchedules{f,c.machines(k)});
    end

    bestCount = min(counts);
    bestMachines = c.machines(counts == bestCount);
    newMachine = bestMachines(randi(numel(bestMachines)));

    oldMachine = parts.MS(g);
    parts.MS(g) = newMachine;

    child = [parts.FS,parts.OS,parts.MS,parts.VS];
    child = repair_chromosome(child,inst);

    meta.changed = ~isequal(child,parent);
    meta.globalOperation = g;
    meta.oldValue = oldMachine;
    meta.newValue = newMachine;
    meta.reason = 'Critical-path operation moved to a less-used eligible machine.';
end

function meta = base_meta(id,cfg)
    meta.operatorId = id;
    meta.operatorName = cfg.operators.names{id};
    meta.changed = false;
    meta.evaluationsInsideOperator = 0;
    meta.candidateCount = 0;
    meta.globalOperation = NaN;
    meta.oldValue = NaN;
    meta.newValue = NaN;
    meta.reason = '';
end
