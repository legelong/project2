function [child,meta] = operator_A2_critical_speedup( ...
    parent,parentDecoded,inst,cfg)
%OPERATOR_A2_CRITICAL_SPEEDUP Increase one critical-path speed by one level.

    parts = split_chromosome(parent,inst);
    critical = analyze_critical_structure(parentDecoded,inst,cfg);
    path = critical.onePath;
    speeds = inst.speed.levels(:)';

    candidates = [];

    for g = path
        current = parts.VS(g);
        idx = find(abs(speeds-current) <= 1e-12,1,'first');

        if ~isempty(idx) && idx < numel(speeds)
            candidates(end+1) = g; %#ok<AGROW>
        end
    end

    meta = base_meta(2,cfg);
    meta.candidateCount = numel(candidates);

    if isempty(candidates)
        child = parent;
        meta.reason = 'Every representative critical-path operation is already at maximum speed.';
        return;
    end

    g = candidates(randi(numel(candidates)));
    current = parts.VS(g);
    idx = find(abs(speeds-current) <= 1e-12,1,'first');
    newSpeed = speeds(idx+1);

    parts.VS(g) = newSpeed;

    child = [parts.FS,parts.OS,parts.MS,parts.VS];
    child = repair_chromosome(child,inst);

    meta.changed = ~isequal(child,parent);
    meta.globalOperation = g;
    meta.oldValue = current;
    meta.newValue = newSpeed;
    meta.reason = 'Critical-path operation speed increased by one level.';
end

function meta = base_meta(id,cfg)
    meta.operatorId = id;
    meta.operatorName = cfg.operators.names{id};
    meta.changed = false;
    meta.evaluationsInsideOperator = 0;
    meta.candidateCount = 0;
    meta.globalOperation = NaN;
    meta.oldValue = NaN;
    meta.newValue = NaN;
    meta.reason = '';
end
