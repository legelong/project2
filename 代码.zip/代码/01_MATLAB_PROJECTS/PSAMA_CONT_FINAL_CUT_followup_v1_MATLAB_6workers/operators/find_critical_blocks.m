function blocks = find_critical_blocks(decoded,critical)
%FIND_CRITICAL_BLOCKS Maximal same-machine subsequences on one critical path.
%
% A block is retained only when it has at least two operations.
% A4 itself requires block length >= 3 so that an internal operation exists.

    path = critical.onePath(:)';

    blocks = {};
    if isempty(path)
        return;
    end

    startPos = 1;

    while startPos <= numel(path)
        g0 = path(startPos);
        f0 = decoded.op.factory(g0);
        m0 = decoded.op.machine(g0);

        endPos = startPos;

        while endPos < numel(path)
            g1 = path(endPos+1);

            if decoded.op.factory(g1) == f0 && ...
               decoded.op.machine(g1) == m0
                endPos = endPos + 1;
            else
                break;
            end
        end

        if endPos-startPos+1 >= 2
            blocks{end+1} = path(startPos:endPos); %#ok<AGROW>
        end

        startPos = endPos + 1;
    end
end
