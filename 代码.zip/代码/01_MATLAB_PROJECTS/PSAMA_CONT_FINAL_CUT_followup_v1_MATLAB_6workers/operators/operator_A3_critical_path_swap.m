function [child,meta] = operator_A3_critical_path_swap( ...
    parent,parentDecoded,inst,cfg)
%OPERATOR_A3_CRITICAL_PATH_SWAP Swap OS priorities of two critical-path jobs.
%
% The two selected critical-path operations must belong to different jobs.
% In occurrence-based OS encoding, swapping the two job tokens preserves all
% required occurrence counts while perturbing sequencing priorities.

    parts = split_chromosome(parent,inst);
    critical = analyze_critical_structure(parentDecoded,inst,cfg);
    path = critical.onePath;

    pairList = zeros(0,2);

    for a = 1:numel(path)-1
        ga = path(a);
        ja = parentDecoded.op.job(ga);

        for b = a+1:numel(path)
            gb = path(b);
            jb = parentDecoded.op.job(gb);

            if ja ~= jb
                pairList(end+1,:) = [ga,gb]; %#ok<AGROW>
            end
        end
    end

    meta = base_meta(3,cfg);
    meta.candidateCount = size(pairList,1);

    if isempty(pairList)
        child = parent;
        meta.reason = 'No different-job operation pair exists on the representative critical path.';
        return;
    end

    pair = pairList(randi(size(pairList,1)),:);
    g1 = pair(1);
    g2 = pair(2);

    pos1 = parentDecoded.op.osPriority(g1);
    pos2 = parentDecoded.op.osPriority(g2);

    old1 = parts.OS(pos1);
    old2 = parts.OS(pos2);

    parts.OS([pos1,pos2]) = parts.OS([pos2,pos1]);

    child = [parts.FS,parts.OS,parts.MS,parts.VS];
    child = repair_chromosome(child,inst);

    meta.changed = ~isequal(child,parent);
    meta.globalOperation = [g1,g2];
    meta.oldValue = [old1,old2];
    meta.newValue = [old2,old1];
    meta.reason = 'OS priorities of two different-job critical-path operations were swapped.';
end

function meta = base_meta(id,cfg)
    meta.operatorId = id;
    meta.operatorName = cfg.operators.names{id};
    meta.changed = false;
    meta.evaluationsInsideOperator = 0;
    meta.candidateCount = 0;
    meta.globalOperation = [];
    meta.oldValue = [];
    meta.newValue = [];
    meta.reason = '';
end
