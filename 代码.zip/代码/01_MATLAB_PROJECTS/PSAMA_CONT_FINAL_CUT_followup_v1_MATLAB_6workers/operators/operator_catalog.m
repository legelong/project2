function catalog = operator_catalog(cfg)
%OPERATOR_CATALOG Frozen Step-5 operator IDs/names.

    if nargin < 1 || isempty(cfg)
        cfg = make_shared_config();
    end

    K = cfg.operators.count;
    catalog = struct('id',cell(K,1),'name',cell(K,1));

    for k = 1:K
        catalog(k).id = k;
        catalog(k).name = cfg.operators.names{k};
    end
end
