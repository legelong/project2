function [child,meta] = operator_A5_noncritical_slowdown( ...
    parent,parentDecoded,inst,cfg)
%OPERATOR_A5_NONCRITICAL_SLOWDOWN Slow one noncritical op in a critical factory.
%
% This Step-5 operator intentionally preserves the old "one speed level down"
% concept. Slack-aware / tariff-boundary-aware speed-time operators will be
% added only after the new framework itself has been validated.

    parts = split_chromosome(parent,inst);
    critical = analyze_critical_structure(parentDecoded,inst,cfg);
    criticalMask = critical.graph.criticalMask;
    speeds = inst.speed.levels(:)';

    criticalFactory = get_critical_factory(parentDecoded,cfg);

    candidates = [];

    for g = 1:inst.size.totalOperations
        if parentDecoded.op.factory(g) ~= criticalFactory
            continue;
        end

        if criticalMask(g)
            continue;
        end

        current = parts.VS(g);
        idx = find(abs(speeds-current) <= 1e-12,1,'first');

        if ~isempty(idx) && idx > 1
            candidates(end+1) = g; %#ok<AGROW>
        end
    end

    meta = base_meta(5,cfg);
    meta.criticalFactory = criticalFactory;
    meta.candidateCount = numel(candidates);

    if isempty(candidates)
        child = parent;
        meta.reason = 'No noncritical operation in the selected critical factory can be slowed.';
        return;
    end

    g = candidates(randi(numel(candidates)));
    current = parts.VS(g);
    idx = find(abs(speeds-current) <= 1e-12,1,'first');
    newSpeed = speeds(idx-1);

    parts.VS(g) = newSpeed;

    child = [parts.FS,parts.OS,parts.MS,parts.VS];
    child = repair_chromosome(child,inst);

    meta.changed = ~isequal(child,parent);
    meta.globalOperation = g;
    meta.oldValue = current;
    meta.newValue = newSpeed;
    meta.reason = 'Noncritical operation speed reduced by one level.';
end

function meta = base_meta(id,cfg)
    meta.operatorId = id;
    meta.operatorName = cfg.operators.names{id};
    meta.changed = false;
    meta.evaluationsInsideOperator = 0;
    meta.candidateCount = 0;
    meta.criticalFactory = NaN;
    meta.globalOperation = NaN;
    meta.oldValue = NaN;
    meta.newValue = NaN;
    meta.reason = '';
end
