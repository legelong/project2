function projectRoot = setup_project()
%SETUP_PROJECT Add the formal PSA-MA project to MATLAB path.

    projectRoot = fileparts(mfilename('fullpath'));
    addpath(genpath(projectRoot));

    fprintf('[PSA-MA Formal] Project path added:\n%s\n', projectRoot);
end
