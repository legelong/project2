function [reward,detail,afterObjectives] = compute_set_level_reward( ...
    archiveObjectives,childObjective,cfg)
%COMPUTE_SET_LEVEL_REWARD Marginal Pareto-set contribution of one child.
%
% The child is assumed to have already consumed one external objective
% evaluation. This function performs NO schedule/objective evaluation.
%
% Procedure:
%   1. Remove dominated/duplicate points from current archive.
%   2. Form ND(archive U child).
%   3. Define ideal/nadir from the AFTER nondominated union.
%   4. Measure BEFORE and AFTER under those SAME local bounds.
%   5. Reward = DeltaHV + gapWeight * (Gap_before - Gap_after).
%
% Dominated or duplicate child -> archive unchanged -> reward exactly 0.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    if isempty(archiveObjectives)
        error('PSAMA:EmptyRewardArchive', ...
            'Set-level local-search reward requires a nonempty current archive.');
    end

    if size(archiveObjectives,2) ~= 2 || numel(childObjective) ~= 2
        error('PSAMA:SetRewardShape', ...
            'Step-6 set reward is defined for exactly two objectives.');
    end

    before = nondominated_objectives(archiveObjectives);
    afterObjectives = nondominated_objectives([before;childObjective(:)']);

    unchanged = isequal(sortrows(before),sortrows(afterObjectives));

    if unchanged
        reward = 0;

        ideal = min(before,[],1);
        nadir = max(before,[],1);

        beforeQ = compute_set_quality(before,ideal,nadir,cfg);

        detail.before = beforeQ;
        detail.after = beforeQ;
        detail.deltaHV = 0;
        detail.gapImprovement = 0;
        detail.reward = 0;
        detail.archiveChanged = false;
        detail.childAccepted = false;
        return;
    end

    ideal = min(afterObjectives,[],1);
    nadir = max(afterObjectives,[],1);

    beforeQ = compute_set_quality(before,ideal,nadir,cfg);
    afterQ = compute_set_quality(afterObjectives,ideal,nadir,cfg);

    deltaHV = afterQ.hypervolume-beforeQ.hypervolume;
    gapImprovement = beforeQ.maxGap-afterQ.maxGap;

    reward = deltaHV + cfg.setReward.gapWeight*gapImprovement;

    % Floating-point roundoff should not turn a true nonnegative marginal
    % set contribution into a tiny negative number.
    if reward < 0 && abs(reward) <= 1e-12
        reward = 0;
    end

    detail.before = beforeQ;
    detail.after = afterQ;
    detail.deltaHV = deltaHV;
    detail.gapImprovement = gapImprovement;
    detail.reward = reward;
    detail.archiveChanged = true;

    % Accepted iff the child objective survives the nondominated union.
    survives = any(all(abs(afterObjectives-childObjective(:)') <= 1e-12,2));
    detail.childAccepted = survives;
end
