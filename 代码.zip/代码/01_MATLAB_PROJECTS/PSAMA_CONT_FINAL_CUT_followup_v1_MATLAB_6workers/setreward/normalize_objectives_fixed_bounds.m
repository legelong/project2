function normalized = normalize_objectives_fixed_bounds(objectives,ideal,nadir)
%NORMALIZE_OBJECTIVES_FIXED_BOUNDS Normalize with externally fixed bounds.

    range = nadir-ideal;
    range(range <= 0) = 1;

    normalized = (objectives-ideal)./range;
end
