function hv = compute_hypervolume_2d(points,referencePoint)
%COMPUTE_HYPERVOLUME_2D Exact 2D hypervolume for minimization.
%
% Input points should already be normalized and nondominated.

    if isempty(points)
        hv = 0;
        return;
    end

    if size(points,2) ~= 2 || numel(referencePoint) ~= 2
        error('PSAMA:HV2DShape','HV2D requires N-by-2 points and 1-by-2 reference.');
    end

    points = nondominated_objectives(points);

    % Points outside the reference rectangle do not contribute.
    keep = points(:,1) < referencePoint(1) & ...
           points(:,2) < referencePoint(2);
    points = points(keep,:);

    if isempty(points)
        hv = 0;
        return;
    end

    [~,order] = sort(points(:,1),'ascend');
    points = points(order,:);

    hv = 0;
    previousY = referencePoint(2);

    for i = 1:size(points,1)
        x = points(i,1);
        y = points(i,2);

        if y < previousY
            width = max(0,referencePoint(1)-x);
            height = previousY-y;
            hv = hv + width*height;
            previousY = y;
        end
    end
end
