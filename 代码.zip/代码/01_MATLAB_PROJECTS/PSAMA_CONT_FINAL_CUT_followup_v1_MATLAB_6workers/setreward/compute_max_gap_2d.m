function gap = compute_max_gap_2d(points,includeBoundaries)
%COMPUTE_MAX_GAP_2D Maximum adjacent gap in normalized 2D objective space.
%
% Distance is divided by sqrt(2), so the result is in [0,1] when points lie
% in [0,1]^2.
%
% If includeBoundaries=true, normalized anchors [0,1] and [1,0] are included.
% This is important for set reward: when a new extreme point extends the
% before/after normalization range, the BEFORE set receives an explicit
% boundary deficiency that the new extreme can fill.

    if nargin < 2
        includeBoundaries = true;
    end

    if isempty(points)
        gap = 1;
        return;
    end

    points = nondominated_objectives(points);
    points = min(max(points,0),1);

    if includeBoundaries
        points = [0,1;points;1,0];
    end

    points = unique(points,'rows','stable');
    [~,order] = sort(points(:,1),'ascend');
    points = points(order,:);

    if size(points,1) < 2
        gap = 1;
        return;
    end

    distances = sqrt(sum(diff(points,1,1).^2,2))/sqrt(2);
    gap = max(distances);
end
