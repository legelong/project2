function nd = nondominated_objectives(objectives)
%NONDOMINATED_OBJECTIVES Unique nondominated objective rows.

    if isempty(objectives)
        nd = zeros(0,size(objectives,2));
        return;
    end

    [uniqueObj,~] = unique(objectives,'rows','stable');
    [~,fronts] = fast_nondominated_sort(uniqueObj);

    if isempty(fronts)
        nd = zeros(0,size(objectives,2));
    else
        nd = uniqueObj(fronts{1},:);
    end
end
