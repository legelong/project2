function reward = compute_parent_dominance_reward(parentObjective,childObjective)
%COMPUTE_PARENT_DOMINANCE_REWARD Old-SCQMA-style ablation reward.
%
% child dominates parent       -> +1.0
% mutually nondominated        -> +0.3
% parent dominates child       -> -0.5
% exact duplicate              ->  0.0
%
% This is preserved only for the H1 ablation experiment.

    p = parentObjective(:)';
    c = childObjective(:)';

    if all(abs(p-c) <= 1e-12)
        reward = 0;
    elseif dominates_objective(c,p)
        reward = 1.0;
    elseif dominates_objective(p,c)
        reward = -0.5;
    else
        reward = 0.3;
    end
end
