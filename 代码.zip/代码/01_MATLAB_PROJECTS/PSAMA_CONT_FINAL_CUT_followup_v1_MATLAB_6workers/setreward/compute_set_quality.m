function quality = compute_set_quality( ...
    objectives,ideal,nadir,cfg)
%COMPUTE_SET_QUALITY Online local Pareto-set quality.
%
% Q = HV - gapWeight * MaxGap
%
% IMPORTANT:
% `ideal` and `nadir` are supplied externally so BEFORE and AFTER are measured
% under exactly the same local normalization for one transition.
%
% This online Q is used only for learning feedback.
% It is NOT the final cross-algorithm publication HV.

    if nargin < 4 || isempty(cfg)
        cfg = make_shared_config();
    end

    nd = nondominated_objectives(objectives);

    if isempty(nd)
        quality.normalizedObjectives = zeros(0,2);
        quality.hypervolume = 0;
        quality.maxGap = 1;
        quality.value = -cfg.setReward.gapWeight;
        return;
    end

    normalized = normalize_objectives_fixed_bounds(nd,ideal,nadir);

    quality.normalizedObjectives = normalized;
    quality.hypervolume = compute_hypervolume_2d( ...
        normalized,cfg.setReward.referencePoint);

    quality.maxGap = compute_max_gap_2d( ...
        normalized,cfg.setReward.includeBoundaryGaps);

    quality.value = quality.hypervolume - ...
        cfg.setReward.gapWeight*quality.maxGap;
end
