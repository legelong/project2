function [objectives, decoded, evaluation] = evaluate_solution(chromosome, inst, cfg)
%EVALUATE_SOLUTION Single common API for ALL future algorithms.
%
% Later baseline/full/ablation algorithms should call THIS function instead
% of implementing their own decoder or objective calculations.

    if nargin < 3 || isempty(cfg)
        cfg = make_shared_config();
    end

    decoded = decode_solution(chromosome, inst, cfg);
    evaluation = evaluate_decoded_schedule(decoded, inst);

    decoded.makespan = evaluation.makespan;
    decoded.cost = evaluation.cost;
    decoded.objectives = evaluation.objectives;

    if cfg.decoder.validateSchedule
        validate_schedule(decoded, inst, cfg, true);
    end

    objectives = evaluation.objectives;
end
