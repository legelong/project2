function power = processing_power(speed, inst)
%PROCESSING_POWER Common processing-power model.
%
%   P_work(v) = coefficient * v^2

    if ~isfinite(speed) || speed <= 0
        error('PSAMA:BadSpeed', 'speed must be finite and positive.');
    end

    power = inst.speed.processingPowerCoefficient * speed.^2;
end
