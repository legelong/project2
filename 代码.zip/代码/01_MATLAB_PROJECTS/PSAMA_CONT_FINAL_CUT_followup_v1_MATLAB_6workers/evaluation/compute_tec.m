function cost = compute_tec(decoded, inst)
%COMPUTE_TEC Compute processing + inter-operation idle TOU electricity cost.
%
% Processing cost:
%   integral P_work(v) * lambda(t) dt over every operation interval.
%
% Idle cost:
%   for two consecutive operations on the same physical (factory,machine),
%   integral P_idle * lambda(t) dt over the gap between them.
%
% No initial idle before a machine's first operation and no terminal idle
% after its final operation are charged.

    F = inst.size.numFactories;
    Mvec = inst.size.numMachinesPerFactory(:)';
    maxM = max(Mvec);

    processingByMachine = zeros(F, maxM);
    idleByMachine = zeros(F, maxM);

    for f = 1:F
        for m = 1:Mvec(f)
            ids = decoded.machineSchedules{f,m};
            if isempty(ids)
                continue;
            end

            % The decoder appends operations in scheduled chronological order.
            starts = decoded.op.start(ids);
            [~, order] = sort(starts, 'ascend');
            ids = ids(order);

            % Processing electricity cost.
            for q = 1:numel(ids)
                g = ids(q);
                power = processing_power(decoded.op.speed(g), inst);
                processingByMachine(f,m) = processingByMachine(f,m) + ...
                    integrate_tou_cost( ...
                        power, ...
                        decoded.op.start(g), ...
                        decoded.op.duration(g), ...
                        inst.tariff);
            end

            % Idle electricity cost only between consecutive operations.
            for q = 1:numel(ids)-1
                g1 = ids(q);
                g2 = ids(q+1);

                idleStart = decoded.op.finish(g1);
                idleDuration = decoded.op.start(g2) - idleStart;

                if idleDuration < -1e-9
                    error('PSAMA:MachineOverlapDuringCost', ...
                        'Negative idle gap detected at factory %d machine %d.', ...
                        f,m);
                end

                idleDuration = max(0, idleDuration);

                if idleDuration > 0
                    idleByMachine(f,m) = idleByMachine(f,m) + ...
                        integrate_tou_cost( ...
                            inst.speed.idlePower, ...
                            idleStart, ...
                            idleDuration, ...
                            inst.tariff);
                end
            end
        end
    end

    cost.processingByMachine = processingByMachine;
    cost.idleByMachine = idleByMachine;
    cost.totalByMachine = processingByMachine + idleByMachine;

    cost.processingByFactory = sum(processingByMachine, 2);
    cost.idleByFactory = sum(idleByMachine, 2);
    cost.totalByFactory = cost.processingByFactory + cost.idleByFactory;

    cost.processing = sum(processingByMachine(:));
    cost.idle = sum(idleByMachine(:));
    cost.total = cost.processing + cost.idle;
end
