function duration = processing_duration(baseTime, speed, inst)
%PROCESSING_DURATION Common speed-dependent processing-time rule.
%
% Current benchmark rule:
%   duration = max(1, floor(baseTime / speed))

    if ~isfinite(baseTime) || baseTime <= 0
        error('PSAMA:BadBaseTime', 'baseTime must be finite and positive.');
    end
    if ~isfinite(speed) || speed <= 0
        error('PSAMA:BadSpeed', 'speed must be finite and positive.');
    end

    raw = baseTime / speed;

    switch lower(inst.speed.durationRounding)
        case 'floor'
            duration = floor(raw);
        case 'ceil'
            duration = ceil(raw);
        case 'round'
            duration = round(raw);
        otherwise
            error('PSAMA:UnknownRounding', ...
                'Unknown duration rounding rule: %s', ...
                inst.speed.durationRounding);
    end

    duration = max(inst.speed.minDuration, duration);
end
