function evaluation = evaluate_decoded_schedule(decoded, inst)
%EVALUATE_DECODED_SCHEDULE Common objective evaluator.

    cost = compute_tec(decoded, inst);

    evaluation.makespan = max(decoded.op.finish);
    evaluation.factoryMakespan = decoded.factoryMakespan;
    evaluation.processingCost = cost.processing;
    evaluation.idleCost = cost.idle;
    evaluation.totalElectricityCost = cost.total;
    evaluation.cost = cost;

    evaluation.objectives = ...
        [evaluation.makespan, evaluation.totalElectricityCost];
end
