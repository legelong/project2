function cost = integrate_tou_cost(power, startTime, duration, tariff)
%INTEGRATE_TOU_COST Exact periodic TOU cost over [startTime,startTime+duration).
%
% Works for integer or fractional times. It does NOT approximate by a single
% tariff value when an operation crosses a tariff boundary.
%
% Cost = integral power * lambda(t) dt

    if ~isscalar(power) || ~isfinite(power) || power < 0
        error('PSAMA:BadPower', 'power must be one finite nonnegative scalar.');
    end
    if ~isscalar(startTime) || ~isfinite(startTime) || startTime < 0
        error('PSAMA:BadStartTime', ...
            'startTime must be one finite nonnegative scalar.');
    end
    if ~isscalar(duration) || ~isfinite(duration) || duration < 0
        error('PSAMA:BadDuration', ...
            'duration must be one finite nonnegative scalar.');
    end

    if duration == 0 || power == 0
        cost = 0;
        return;
    end

    % Every tariff discontinuity within one 24-unit period.
    boundaries = [0; ...
                  tariff.valleyIntervals(:); ...
                  tariff.peakIntervals(:); ...
                  tariff.period];
    boundaries = unique(boundaries);
    boundaries = sort(boundaries(:));

    t = startTime;
    tEnd = startTime + duration;
    cost = 0;
    tol = 1e-12;

    while t < tEnd - tol
        h = mod(t, tariff.period);

        % Find the next within-period boundary strictly after h.
        candidate = boundaries(boundaries > h + tol);

        if isempty(candidate)
            nextBoundary = t + (tariff.period - h);
        else
            nextBoundary = t + (candidate(1) - h);
        end

        segmentEnd = min(tEnd, nextBoundary);
        segmentDuration = segmentEnd - t;

        % Price is constant inside [t, segmentEnd).
        p = tou_price_at_time(t, tariff);
        cost = cost + power * p * segmentDuration;

        t = segmentEnd;
    end
end
