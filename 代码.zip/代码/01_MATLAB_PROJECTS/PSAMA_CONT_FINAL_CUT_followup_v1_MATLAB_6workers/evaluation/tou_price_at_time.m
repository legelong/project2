function price = tou_price_at_time(t, tariff)
%TOU_PRICE_AT_TIME Periodic TOU price at arbitrary nonnegative time.
%
% Half-open tariff intervals:
% valley [0,6), [11,14)
% peak   [16,23)
% flat   otherwise
%
% t may be a scalar or an array.

    if any(~isfinite(t(:))) || any(t(:) < 0)
        error('PSAMA:BadTime', 'Time values must be finite and nonnegative.');
    end

    h = mod(t, tariff.period);
    price = tariff.flatPrice * ones(size(h));

    for i = 1:size(tariff.valleyIntervals, 1)
        a = tariff.valleyIntervals(i, 1);
        b = tariff.valleyIntervals(i, 2);
        mask = (h >= a) & (h < b);
        price(mask) = tariff.valleyPrice;
    end

    for i = 1:size(tariff.peakIntervals, 1)
        a = tariff.peakIntervals(i, 1);
        b = tariff.peakIntervals(i, 2);
        mask = (h >= a) & (h < b);
        price(mask) = tariff.peakPrice;
    end
end
