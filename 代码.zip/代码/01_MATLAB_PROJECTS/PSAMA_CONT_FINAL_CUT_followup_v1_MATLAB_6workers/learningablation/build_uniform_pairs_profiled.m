function [pairs,profile] = build_uniform_pairs_profiled( ...
    pop,pool,archive,inst,cfg)
%BUILD_UNIFORM_PAIRS_PROFILED Build the same feasible pair candidates with no learning.
%
% Every feasible pair receives:
%   score = 0
%
% No solution context and no learned operator value are consulted.
% Random tieKey is retained, so equal-score competition is randomized.
%
% Parent reward is NOT available here and is not used for selection.

    if isempty(archive) || isempty(archive.objectives)
        error('PSAMA:EmptyArchive', ...
            'Uniform allocation requires a nonempty archive.');
    end

    catalog = operator_catalog(cfg);

    template = struct( ...
        'sourceIndex',NaN, ...
        'sourceType','', ...
        'recoveryScore',NaN, ...
        'sourceObjective',[], ...
        'operatorId',NaN, ...
        'operatorName','', ...
        'context',[], ...
        'score',NaN, ...
        'predictedMean',NaN, ...
        'uncertainty',NaN, ...
        'tieKey',NaN, ...
        'child',[], ...
        'operatorMeta',[]);

    pairs = repmat(template,0,1);

    profile.contextTime = 0;
    profile.operatorProposalTime = 0;
    profile.scoringTime = 0;
    profile.sources = numel(pool.indices);
    profile.operatorAttempts = 0;
    profile.feasiblePairs = 0;

    for q = 1:numel(pool.indices)
        idx = pool.indices(q);

        if isempty(pop.decoded{idx})
            error('PSAMA:MissingDecodedCache', ...
                'Pair construction requires decoded schedules.');
        end

        decoded = pop.decoded{idx};
        objective = pop.objectives(idx,:);

        for opId = 1:cfg.operators.count
            profile.operatorAttempts = profile.operatorAttempts+1;

            t = tic;
            [child,meta] = apply_operator( ...
                opId,pop.chromosomes(idx,:),decoded,inst,cfg);
            profile.operatorProposalTime = ...
                profile.operatorProposalTime+toc(t);

            if ~meta.changed
                continue;
            end

            item = template;
            item.sourceIndex = idx;
            item.sourceType = pool.sourceType{q};
            item.recoveryScore = pool.recoveryScore(q);
            item.sourceObjective = objective;
            item.operatorId = opId;
            item.operatorName = catalog(opId).name;
            item.context = [];
            item.score = cfg.uniform.score;
            item.predictedMean = cfg.uniform.predictedMean;
            item.uncertainty = cfg.uniform.uncertainty;

            if cfg.uniform.useRandomTieBreak
                item.tieKey = rand();
            else
                item.tieKey = opId;
            end

            item.child = child;
            item.operatorMeta = meta;

            pairs(end+1,1) = item; %#ok<AGROW>
        end
    end

    profile.feasiblePairs = numel(pairs);
end
