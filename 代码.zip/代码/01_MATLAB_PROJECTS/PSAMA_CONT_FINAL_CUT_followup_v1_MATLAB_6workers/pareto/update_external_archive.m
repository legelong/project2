function archive = update_external_archive(archive, candidates, cfg)
%UPDATE_EXTERNAL_ARCHIVE Objective-space external nondominated archive.
%
% Exact duplicate objective vectors are represented once in this minimum
% archive. Decision-space multimodality is intentionally NOT introduced yet.

    if isempty(archive) || ~isfield(archive,'chromosomes') || ...
       isempty(archive.chromosomes)
        combined = candidates;
    else
        combined = merge_populations(archive,candidates);
    end

    % Remove exact objective duplicates, preserving the first representative.
    [~,uniqueIdx] = unique(combined.objectives,'rows','stable');
    combined = subset_population(combined,uniqueIdx);

    combined = assign_rank_and_crowding(combined);

    if isempty(combined.fronts)
        archive = empty_archive(size(combined.chromosomes,2));
        return;
    end

    idx = combined.fronts{1};
    archive = subset_population(combined,idx);
    archive = assign_rank_and_crowding(archive);

    maxSize = cfg.evolution.archiveMaxSize;

    if size(archive.chromosomes,1) > maxSize
        d = archive.crowding;
        orderTable = [-d(:),(1:numel(d))'];
        [~,order] = sortrows(orderTable,[1 2]);
        archive = subset_population(archive,order(1:maxSize));
        archive = assign_rank_and_crowding(archive);
    end
end

function archive = empty_archive(L)
    archive.chromosomes = zeros(0,L);
    archive.objectives = zeros(0,2);
    archive.decoded = cell(0,1);
    archive.rank = zeros(0,1);
    archive.crowding = zeros(0,1);
    archive.fronts = {};
    archive.nfe = 0;
end
