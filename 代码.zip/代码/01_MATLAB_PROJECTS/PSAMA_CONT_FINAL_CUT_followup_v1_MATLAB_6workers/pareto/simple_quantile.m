function q = simple_quantile(values,p)
%SIMPLE_QUANTILE Toolbox-free linear empirical quantile.

    values = sort(values(:));
    n = numel(values);

    if n == 0
        q = NaN;
        return;
    end

    p = min(max(p,0),1);

    if n == 1
        q = values(1);
        return;
    end

    position = 1 + (n-1)*p;
    lo = floor(position);
    hi = ceil(position);

    if lo == hi
        q = values(lo);
    else
        w = position-lo;
        q = (1-w)*values(lo)+w*values(hi);
    end
end
