function pop = assign_rank_and_crowding(pop)
%ASSIGN_RANK_AND_CROWDING Populate rank/front/crowding fields.

    [rank,fronts] = fast_nondominated_sort(pop.objectives);
    crowding = compute_crowding_distance(pop.objectives,fronts);

    pop.rank = rank;
    pop.fronts = fronts;
    pop.crowding = crowding;
end
