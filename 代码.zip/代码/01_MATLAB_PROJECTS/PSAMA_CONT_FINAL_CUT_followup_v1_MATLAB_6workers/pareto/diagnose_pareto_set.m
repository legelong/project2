function diagnosis = diagnose_pareto_set(objectives,cfg)
%DIAGNOSE_PARETO_SET Continuous Pareto-front diagnostic descriptors.
%
% Returns for every nondominated point:
%   normalized objective location
%   local gap score
%   knee score
%   makespan/TEC extreme flags
%   sparse/dense/knee labels
%
% These labels are descriptive. The later allocator will learn from continuous
% context rather than use hard-coded region rules.

    if nargin < 2 || isempty(cfg)
        cfg = make_shared_config();
    end

    nd = nondominated_objectives(objectives);

    if isempty(nd)
        error('PSAMA:EmptyParetoDiagnosis', ...
            'Cannot diagnose an empty Pareto set.');
    end

    fmin = min(nd,[],1);
    fmax = max(nd,[],1);
    range = fmax-fmin;
    range(range <= 0) = 1;

    normObj = (nd-fmin)./range;

    [~,order] = sort(normObj(:,1),'ascend');
    sorted = normObj(order,:);
    n = size(sorted,1);

    % --------------------------------------------------------------
    % Local gap score
    % --------------------------------------------------------------
    localGapSorted = zeros(n,1);

    if n == 1
        localGapSorted(1) = 1;
    else
        segment = sqrt(sum(diff(sorted,1,1).^2,2));
        maxSegment = max(segment);

        if maxSegment > 0
            for k = 1:n
                adjacent = [];
                if k > 1
                    adjacent(end+1) = segment(k-1); %#ok<AGROW>
                end
                if k < n
                    adjacent(end+1) = segment(k); %#ok<AGROW>
                end
                localGapSorted(k) = max(adjacent)/maxSegment;
            end
        end
    end

    localGap = zeros(n,1);
    localGap(order) = localGapSorted;

    % --------------------------------------------------------------
    % Knee score: perpendicular distance from extreme chord
    % --------------------------------------------------------------
    kneeSorted = zeros(n,1);

    if n >= 3
        a = sorted(1,:);
        b = sorted(end,:);
        ab = b-a;
        denom = norm(ab);

        if denom > 0
            for k = 2:n-1
                p = sorted(k,:);
                % 2D point-line distance.
                kneeSorted(k) = abs( ...
                    ab(1)*(a(2)-p(2)) - ...
                    (a(1)-p(1))*ab(2)) / denom;
            end

            maxKnee = max(kneeSorted);
            if maxKnee > 0
                kneeSorted = kneeSorted/maxKnee;
            end
        end
    end

    kneeScore = zeros(n,1);
    kneeScore(order) = kneeSorted;

    [~,makespanExtreme] = min(nd(:,1));
    [~,tecExtreme] = min(nd(:,2));

    sparseThreshold = simple_quantile( ...
        localGap,cfg.paretoDiagnosis.sparseQuantile);
    denseThreshold = simple_quantile( ...
        localGap,cfg.paretoDiagnosis.denseQuantile);
    kneeThreshold = simple_quantile( ...
        kneeScore,cfg.paretoDiagnosis.kneeQuantile);

    isMakespanExtreme = false(n,1);
    isTECExtreme = false(n,1);
    isMakespanExtreme(makespanExtreme) = true;
    isTECExtreme(tecExtreme) = true;

    isSparse = localGap >= sparseThreshold;
    isDense = localGap <= denseThreshold;

    if max(kneeScore) <= 0
        isKnee = false(n,1);
    else
        isKnee = kneeScore >= kneeThreshold & kneeScore > 0;
    end

    roles = cell(n,1);

    for i = 1:n
        tags = {};

        if isMakespanExtreme(i)
            tags{end+1} = 'makespan-extreme'; %#ok<AGROW>
        end
        if isTECExtreme(i)
            tags{end+1} = 'TEC-extreme'; %#ok<AGROW>
        end
        if isKnee(i)
            tags{end+1} = 'knee'; %#ok<AGROW>
        end
        if isSparse(i)
            tags{end+1} = 'sparse'; %#ok<AGROW>
        end
        if isDense(i)
            tags{end+1} = 'dense'; %#ok<AGROW>
        end

        if isempty(tags)
            tags = {'regular'};
        end

        roles{i} = strjoin(tags,'|');
    end

    diagnosis.objectives = nd;
    diagnosis.normalizedObjectives = normObj;
    diagnosis.localGapScore = localGap;
    diagnosis.kneeScore = kneeScore;
    diagnosis.isMakespanExtreme = isMakespanExtreme;
    diagnosis.isTECExtreme = isTECExtreme;
    diagnosis.isSparse = isSparse;
    diagnosis.isDense = isDense;
    diagnosis.isKnee = isKnee;
    diagnosis.roles = roles;
    diagnosis.sortedOrder = order;
    diagnosis.sparseThreshold = sparseThreshold;
    diagnosis.denseThreshold = denseThreshold;
    diagnosis.kneeThreshold = kneeThreshold;
end
