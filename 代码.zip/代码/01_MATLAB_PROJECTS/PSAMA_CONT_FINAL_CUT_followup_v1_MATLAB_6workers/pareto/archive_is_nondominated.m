function tf = archive_is_nondominated(archive)
%ARCHIVE_IS_NONDOMINATED True if no archive point dominates another.

    tf = true;
    N = size(archive.objectives,1);

    for i = 1:N
        for j = 1:N
            if i ~= j && dominates_objective( ...
                    archive.objectives(i,:),archive.objectives(j,:))
                tf = false;
                return;
            end
        end
    end
end
