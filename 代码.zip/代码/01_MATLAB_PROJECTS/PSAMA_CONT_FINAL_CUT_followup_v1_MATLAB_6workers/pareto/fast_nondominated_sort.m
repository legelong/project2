function [rank,fronts] = fast_nondominated_sort(objectives)
%FAST_NONDOMINATED_SORT Standard NSGA-II nondominated sorting.

    N = size(objectives,1);
    dominationSet = cell(N,1);
    dominationCount = zeros(N,1);
    rank = inf(N,1);

    firstFront = [];

    for p = 1:N
        Sp = [];
        np = 0;

        for q = 1:N
            if p == q
                continue;
            end

            if dominates_objective(objectives(p,:),objectives(q,:))
                Sp(end+1) = q; %#ok<AGROW>
            elseif dominates_objective(objectives(q,:),objectives(p,:))
                np = np + 1;
            end
        end

        dominationSet{p} = Sp;
        dominationCount(p) = np;

        if np == 0
            rank(p) = 1;
            firstFront(end+1) = p; %#ok<AGROW>
        end
    end

    fronts = {};
    if isempty(firstFront)
        return;
    end

    fronts{1} = firstFront(:)';

    i = 1;
    while i <= numel(fronts) && ~isempty(fronts{i})
        nextFront = [];

        for pp = fronts{i}
            dominated = dominationSet{pp};

            for qq = dominated
                dominationCount(qq) = dominationCount(qq) - 1;

                if dominationCount(qq) == 0
                    rank(qq) = i + 1;
                    nextFront(end+1) = qq; %#ok<AGROW>
                end
            end
        end

        if ~isempty(nextFront)
            fronts{i+1} = unique(nextFront,'stable'); %#ok<AGROW>
        end

        i = i + 1;
    end
end
