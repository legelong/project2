function crowding = compute_crowding_distance(objectives,fronts)
%COMPUTE_CROWDING_DISTANCE Standard NSGA-II crowding distance.

    N = size(objectives,1);
    M = size(objectives,2);
    crowding = zeros(N,1);

    for fi = 1:numel(fronts)
        idx = fronts{fi};
        n = numel(idx);

        if n == 0
            continue;
        elseif n <= 2
            crowding(idx) = inf;
            continue;
        end

        localDistance = zeros(n,1);

        for m = 1:M
            values = objectives(idx,m);
            [sortedValues,order] = sort(values,'ascend');

            localDistance(order(1)) = inf;
            localDistance(order(end)) = inf;

            rangeValue = sortedValues(end) - sortedValues(1);
            if rangeValue <= 0
                continue;
            end

            for k = 2:n-1
                if isinf(localDistance(order(k)))
                    continue;
                end

                contribution = ...
                    (sortedValues(k+1)-sortedValues(k-1)) / rangeValue;

                localDistance(order(k)) = ...
                    localDistance(order(k)) + contribution;
            end
        end

        crowding(idx) = localDistance;
    end
end
