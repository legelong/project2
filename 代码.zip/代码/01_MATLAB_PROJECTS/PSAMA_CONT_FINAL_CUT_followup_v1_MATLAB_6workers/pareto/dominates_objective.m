function tf = dominates_objective(a,b)
%DOMINATES_OBJECTIVE Pareto dominance for minimization objectives.

    tf = all(a <= b) && any(a < b);
end
