function geom = compute_pareto_geometry(candidateObjective,frontObjectives)
%COMPUTE_PARETO_GEOMETRY Objective-space context relative to current F1.
%
% Outputs:
%   normalizedObjective       1x2, clipped to [0,1]
%   distanceToFront           nearest normalized front-point distance
%   proximity                 1/(1+distance)
%   localGapScore             [0,1], large means sparse front neighborhood
%   nearestFrontIndex
%
% The method is deliberately simple and deterministic for the minimum
% framework. More complex geometry can be tested later as an ablation.

    if size(candidateObjective,1) ~= 1 || size(candidateObjective,2) ~= 2
        error('candidateObjective must be 1x2.');
    end
    if size(frontObjectives,2) ~= 2 || isempty(frontObjectives)
        error('frontObjectives must be nonempty N-by-2.');
    end

    fmin = min(frontObjectives,[],1);
    fmax = max(frontObjectives,[],1);
    range = fmax-fmin;
    range(range <= 0) = 1;

    frontNorm = (frontObjectives-fmin)./range;
    candidateNormRaw = (candidateObjective-fmin)./range;
    candidateNorm = min(max(candidateNormRaw,0),1);

    d = sqrt(sum((frontNorm-candidateNorm).^2,2));
    [distanceToFront,nearest] = min(d);

    % Local front sparsity assigned to each point.
    [~,order] = sort(frontNorm(:,1),'ascend');
    sorted = frontNorm(order,:);
    n = size(sorted,1);

    pointGap = zeros(n,1);

    if n == 1
        pointGap(1) = 1;
    else
        segment = sqrt(sum(diff(sorted,1,1).^2,2));
        maxSegment = max(segment);

        if maxSegment <= 0
            pointGap(:) = 0;
        else
            for k = 1:n
                adjacent = [];
                if k > 1
                    adjacent(end+1) = segment(k-1); %#ok<AGROW>
                end
                if k < n
                    adjacent(end+1) = segment(k); %#ok<AGROW>
                end

                pointGap(k) = max(adjacent)/maxSegment;
            end
        end
    end

    % Convert sorted point gaps back to original front order.
    originalGap = zeros(n,1);
    originalGap(order) = pointGap;

    geom.normalizedObjective = candidateNorm;
    geom.normalizedObjectiveRaw = candidateNormRaw;
    geom.distanceToFront = distanceToFront;
    geom.proximity = 1/(1+distanceToFront);
    geom.localGapScore = originalGap(nearest);
    geom.nearestFrontIndex = nearest;

    geom.frontMin = fmin;
    geom.frontMax = fmax;
    geom.frontNormalized = frontNorm;
    geom.frontPointGapScore = originalGap;
end
