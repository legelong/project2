function outputs = summarize_cont_final_cut_followup()
%SUMMARIZE_CONT_FINAL_CUT_FOLLOWUP Show the decisive strong-control evidence.

    setup_project();

    cfg = make_shared_config();
    expCfg = make_cont_final_cut_followup_experiment();

    root = fullfile(cfg.project.root,'results',expCfg.tag,'tables');

    outputs.deltas = readtable(fullfile(root,'paired_deltas.csv'));
    outputs.statistics = readtable(fullfile(root,'paired_statistics.csv'));
    outputs.winTieLoss = readtable(fullfile(root,'win_tie_loss_by_instance.csv'));
    outputs.runtime = readtable(fullfile(root,'runtime_summary.csv'));
    outputs.schedule = readtable(fullfile(root,'schedule_cut_summary.csv'));

    fprintf('\n=== PRIMARY STRONG CONTROL: FINAL vs CONT_FINAL->CUT ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'FINAL_vs_CONT_CUT'),:));

    fprintf('\n=== What CUT adds after continued MA ===\n');
    disp(outputs.deltas(strcmp( ...
        outputs.deltas.Contrast,'CONT_CUT_vs_CONT_FINAL'),:));

    fprintf('\n=== Win / tie / loss across 20 instances ===\n');
    disp(outputs.winTieLoss);

    fprintf('\n=== Strong-control runtime advantage/disadvantage ===\n');
    disp(outputs.runtime);

    fprintf('\n=== CUT postprocessing on continuation representatives ===\n');
    disp(outputs.schedule);
end
