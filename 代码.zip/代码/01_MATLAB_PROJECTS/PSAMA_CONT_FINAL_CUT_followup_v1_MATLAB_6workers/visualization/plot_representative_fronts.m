function plot_representative_fronts(resultRoot,T,instanceName,cfg,expCfg)
%PLOT_REPRESENTATIVE_FRONTS Median-HV run per method in actual objective units.

    rawRoot = fullfile(resultRoot,'raw');
    figRoot = fullfile(resultRoot,'figures');

    variants = unique(T(:,{'Variant','Label'}),'rows','stable');

    fig = figure('Visible','off','Color','w', ...
        'Position',[100 100 900 600]);
    hold on;

    legendText = {};

    for i = 1:height(variants)
        mask = strcmp(T.Variant,variants.Variant{i});
        X = T(mask,:);

        [~,order] = sort(X.HV);
        mid = order(ceil(numel(order)/2));
        runIndex = X.Run(mid);

        file = fullfile(rawRoot,instanceName, ...
            variants.Variant{i},sprintf('run_%02d.mat',runIndex));
        S = load(file,'record');

        obj = sortrows(S.record.result.archive.objectives,1);

        plot(obj(:,1),obj(:,2),'-o','LineWidth',1.2, ...
            'MarkerSize',4);

        legendText{end+1} = variants.Label{i}; %#ok<AGROW>
    end

    xlabel('Makespan');
    ylabel('Total electricity cost');
    title(sprintf('%s representative Pareto fronts',instanceName));
    legend(legendText,'Location','best');
    grid on;
    box on;
    hold off;

    outBase = fullfile(figRoot,[instanceName '_Pareto']);

    try
        exportgraphics(fig,[outBase '.png'],'Resolution',300);
        exportgraphics(fig,[outBase '.pdf'],'ContentType','vector');
    catch
        print(fig,[outBase '.png'],'-dpng','-r300');
        print(fig,[outBase '.pdf'],'-dpdf','-bestfit');
    end

    close(fig);
end
