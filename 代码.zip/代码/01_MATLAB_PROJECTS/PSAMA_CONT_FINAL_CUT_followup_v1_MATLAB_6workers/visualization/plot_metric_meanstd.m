function plot_metric_meanstd(T,metricName,outBase)
%PLOT_METRIC_MEANSTD Paper-ready mean +/- std comparison.

    variants = unique(T(:,{'Variant','Label'}),'rows','stable');

    mu = zeros(height(variants),1);
    sd = zeros(height(variants),1);

    values = T.(metricName);

    for i = 1:height(variants)
        mask = strcmp(T.Variant,variants.Variant{i});
        mu(i) = mean(values(mask));
        sd(i) = std(values(mask));
    end

    fig = figure('Visible','off','Color','w', ...
        'Position',[100 100 900 520]);

    x = 1:numel(mu);
    bar(x,mu);
    hold on;
    errorbar(x,mu,sd,'k.','LineWidth',1.2);
    hold off;

    set(gca,'XTick',x,'XTickLabel',variants.Label);
    xtickangle(20);
    ylabel(metricName);
    grid on;
    box on;

    title(sprintf('%s: mean \\pm std',metricName));

    export_figure(fig,outBase);
    close(fig);
end

function export_figure(fig,outBase)
    try
        exportgraphics(fig,[outBase '.png'],'Resolution',300);
        exportgraphics(fig,[outBase '.pdf'],'ContentType','vector');
    catch
        print(fig,[outBase '.png'],'-dpng','-r300');
        print(fig,[outBase '.pdf'],'-dpdf','-bestfit');
    end
end
