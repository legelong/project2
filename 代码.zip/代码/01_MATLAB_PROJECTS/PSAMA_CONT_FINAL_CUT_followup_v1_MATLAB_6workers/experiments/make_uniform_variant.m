function variant = make_uniform_variant()
%MAKE_UNIFORM_VARIANT Frozen no-learning Uniform Joint MA.

    variant.id = 'UNIFORM_JOINT';
    variant.label = 'Uniform Joint MA';
    variant.sourceMode = 'F1';
    variant.rewardMode = 'DIAGNOSTIC_ONLY';
    variant.allocatorMode = 'JOINT';
    variant.methodType = 'MA_UNIFORM';
    variant.isImported = false;
end
