function outputs = postprocess_cont_final_cut_followup( ...
    resultRoot,cfg,expCfg)
%POSTPROCESS_CONT_FINAL_CUT_FOLLOWUP Strong-control paired analysis.

    tableRoot = fullfile(resultRoot,'tables');
    figRoot = fullfile(resultRoot,'figures');
    refRoot = fullfile(resultRoot,'reference_fronts');

    ensure_dir(tableRoot);
    ensure_dir(figRoot);
    ensure_dir(refRoot);

    methods = { ...
        'BASE','CUT','CUT_CBJ1','FINAL','CONT_FINAL','CONT_CUT'};

    records = cell(numel(expCfg.instances),expCfg.numRuns);
    refs = cell(numel(expCfg.instances),1);
    bounds = cell(numel(expCfg.instances),1);

    for ii = 1:numel(expCfg.instances)
        inst = expCfg.instances{ii};
        unionPts = [];

        for rr = 1:expCfg.numRuns
            S = load(fullfile(resultRoot,'raw',inst, ...
                sprintf('run_%02d.mat',rr)),'record');

            R = S.record;
            records{ii,rr} = R;

            for m = 1:numel(methods)
                unionPts = [unionPts;R.fronts.(methods{m})]; %#ok<AGROW>
            end
        end

        ref = nondominated_objectives(unionPts);
        refs{ii} = ref;

        lo = min(unionPts,[],1);
        hi = max(unionPts,[],1);
        span = hi-lo;
        span(span<=1e-12) = 1;

        bounds{ii}.lo = lo;
        bounds{ii}.span = span;

        writematrix(ref, ...
            fullfile(refRoot,[inst '_empirical_reference.csv']));
    end

    metricRows = {};
    runtimeRows = {};
    scheduleRows = {};
    rn = 0;

    for ii = 1:numel(expCfg.instances)
        inst = expCfg.instances{ii};

        lo = bounds{ii}.lo;
        span = bounds{ii}.span;
        refN = (refs{ii}-lo)./span;

        for rr = 1:expCfg.numRuns
            R = records{ii,rr};

            for m = 1:numel(methods)
                method = methods{m};
                F = R.fronts.(method);
                FN = (F-lo)./span;

                rn = rn+1;

                metricRows(rn,:) = { ...
                    inst,rr,R.summary.seed,method, ...
                    size(F,1),min(F(:,1)),min(F(:,2)), ...
                    compute_hypervolume_2d( ...
                        FN,cfg.refinement.hvReferencePoint), ...
                    compute_igd(FN,refN)};
            end

            runtimeRows(end+1,:) = { ... %#ok<AGROW>
                inst,rr,R.summary.seed, ...
                R.summary.selectedPoints, ...
                R.summary.finalTargetSeconds, ...
                R.summary.contActualSeconds, ...
                R.summary.followupCUTSeconds, ...
                R.summary.strongControlTotalSeconds, ...
                R.summary.strongControlExtraOverFinalSeconds, ...
                R.summary.strongControlExtraOverFinalFraction};

            for k = 1:numel(R.traces)
                if iscell(R.traces)
                    tr = R.traces{k};
                else
                    tr = R.traces(k);
                end

                scheduleRows(end+1,:) = { ... %#ok<AGROW>
                    inst,rr,k, ...
                    tr.sourceObjectives(1), ...
                    tr.sourceObjectives(2), ...
                    tr.cutObjectives(1), ...
                    tr.cutObjectives(2), ...
                    tr.tecReduction,tr.tecReductionPct, ...
                    tr.cutWallSeconds,tr.cutNodes,tr.cutEdges, ...
                    tr.certificateValid};
            end
        end
    end

    metricsT = cell2table(metricRows,'VariableNames',{ ...
        'Instance','Run','Seed','Method', ...
        'ArchiveSize','MinCmax','MinTEC','HV','IGD'});

    runtimeT = cell2table(runtimeRows,'VariableNames',{ ...
        'Instance','Run','Seed','SelectedPoints', ...
        'FINALTarget_s','CONTActual_s','FollowupCUT_s', ...
        'StrongControlTotal_s', ...
        'StrongControlExtraOverFINAL_s', ...
        'StrongControlExtraOverFINALFraction'});

    scheduleT = cell2table(scheduleRows,'VariableNames',{ ...
        'Instance','Run','SelectedPoint', ...
        'SourceCmax','SourceTEC','CUTCmax','CUTTEC', ...
        'TECReduction','TECReductionPct', ...
        'CUTWall_s','CUTNodes','CUTEdges','CertificateValid'});

    summaryT = summarize_methods(metricsT);
    deltaT = paired_deltas(metricsT);
    statsT = paired_statistics(metricsT,cfg);
    wtlT = win_tie_loss_instances(deltaT);
    runtimeSummaryT = summarize_runtime(runtimeT);
    scheduleSummaryT = summarize_schedules(scheduleT);

    writetable(metricsT,fullfile(tableRoot,'run_metrics.csv'));
    writetable(summaryT,fullfile(tableRoot,'summary_by_instance_method.csv'));
    writetable(deltaT,fullfile(tableRoot,'paired_deltas.csv'));
    writetable(statsT,fullfile(tableRoot,'paired_statistics.csv'));
    writetable(wtlT,fullfile(tableRoot,'win_tie_loss_by_instance.csv'));
    writetable(runtimeT,fullfile(tableRoot,'run_runtime.csv'));
    writetable(runtimeSummaryT,fullfile(tableRoot,'runtime_summary.csv'));
    writetable(scheduleT,fullfile(tableRoot,'selected_schedule_cut.csv'));
    writetable(scheduleSummaryT,fullfile(tableRoot,'schedule_cut_summary.csv'));

    if expCfg.writeXlsx
        try
            writetable(deltaT,fullfile(tableRoot,'paired_deltas.xlsx'));
            writetable(statsT,fullfile(tableRoot,'paired_statistics.xlsx'));
            writetable(runtimeSummaryT,fullfile(tableRoot,'runtime_summary.xlsx'));
        catch
        end
    end

    if expCfg.makeFigures
        make_relative_figure(deltaT,'FINAL_vs_CONT_CUT',figRoot);
        make_runtime_figure(runtimeSummaryT,figRoot);
    end

    outputs.metrics = metricsT;
    outputs.summary = summaryT;
    outputs.deltas = deltaT;
    outputs.statistics = statsT;
    outputs.winTieLoss = wtlT;
    outputs.runtime = runtimeT;
    outputs.runtimeSummary = runtimeSummaryT;
    outputs.schedule = scheduleT;
    outputs.scheduleSummary = scheduleSummaryT;
end

function T = summarize_methods(M)
    instances = unique(string(M.Instance),'stable');
    methods = {'BASE','CUT','CUT_CBJ1','FINAL','CONT_FINAL','CONT_CUT'};

    rows = {};
    rn = 0;

    for i = 1:numel(instances)
        for m = 1:numel(methods)
            X = M(string(M.Instance)==instances(i) & ...
                  strcmp(M.Method,methods{m}),:);

            rn = rn+1;
            rows(rn,:) = { ...
                char(instances(i)),methods{m},height(X), ...
                mean(X.HV),std(X.HV), ...
                mean(X.IGD),std(X.IGD), ...
                mean(X.MinCmax),mean(X.MinTEC)};
        end
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Method','Runs', ...
        'MeanHV','StdHV','MeanIGD','StdIGD', ...
        'MeanMinCmax','MeanMinTEC'});
end

function T = paired_deltas(M)
    instances = unique(string(M.Instance),'stable');

    contrasts = { ...
        'FINAL_vs_CONT_CUT','CONT_CUT','FINAL'; ...
        'CONT_CUT_vs_CONT_FINAL','CONT_FINAL','CONT_CUT'; ...
        'FINAL_vs_CONT_FINAL','CONT_FINAL','FINAL'; ...
        'FINAL_vs_CUT','CUT','FINAL'};

    rows = {};
    rn = 0;

    for i = 1:numel(instances)
        inst = instances(i);

        for c = 1:size(contrasts,1)
            label = contrasts{c,1};
            Aname = contrasts{c,2};
            Bname = contrasts{c,3};

            A = M(string(M.Instance)==inst & strcmp(M.Method,Aname),:);
            B = M(string(M.Instance)==inst & strcmp(M.Method,Bname),:);

            [~,oa] = sort(A.Run);
            [~,ob] = sort(B.Run);
            A = A(oa,:);
            B = B(ob,:);

            dHV = B.HV-A.HV;
            dIGD = A.IGD-B.IGD;
            dTEC = A.MinTEC-B.MinTEC;

            rn = rn+1;
            rows(rn,:) = { ...
                char(inst),label,Aname,Bname,height(A), ...
                mean(dHV),median(dHV),sum(dHV>1e-12), ...
                100*mean(dHV./max(abs(A.HV),eps)), ...
                mean(dIGD),median(dIGD),sum(dIGD>1e-12), ...
                100*mean(dIGD./max(abs(A.IGD),eps)), ...
                mean(dTEC),median(dTEC),sum(dTEC>1e-12), ...
                100*mean(dTEC./max(abs(A.MinTEC),eps))};
        end
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Contrast','MethodA','MethodB','Runs', ...
        'MeanHVAdvantageB','MedianHVAdvantageB','HVWinsB', ...
        'MeanRelativeHVAdvantagePct', ...
        'MeanIGDAdvantageB','MedianIGDAdvantageB','IGDWinsB', ...
        'MeanRelativeIGDAdvantagePct', ...
        'MeanMinTECAdvantageB','MedianMinTECAdvantageB','MinTECWinsB', ...
        'MeanRelativeMinTECAdvantagePct'});
end

function T = paired_statistics(M,cfg)
    instances = unique(string(M.Instance),'stable');

    contrasts = { ...
        'FINAL_vs_CONT_CUT','CONT_CUT','FINAL'; ...
        'CONT_CUT_vs_CONT_FINAL','CONT_FINAL','CONT_CUT'; ...
        'FINAL_vs_CONT_FINAL','CONT_FINAL','FINAL'; ...
        'FINAL_vs_CUT','CUT','FINAL'};

    rows = {};
    rn = 0;
    primaryP = [];
    primaryRows = [];

    for c = 1:size(contrasts,1)
        label = contrasts{c,1};

        for i = 1:numel(instances)
            inst = instances(i);

            A = M(string(M.Instance)==inst & ...
                  strcmp(M.Method,contrasts{c,2}),:);
            B = M(string(M.Instance)==inst & ...
                  strcmp(M.Method,contrasts{c,3}),:);

            [~,oa] = sort(A.Run);
            [~,ob] = sort(B.Run);
            A = A(oa,:);
            B = B(ob,:);

            metrics = { ...
                'HV',B.HV-A.HV; ...
                'IGD',A.IGD-B.IGD; ...
                'MinTEC',A.MinTEC-B.MinTEC};

            for q = 1:size(metrics,1)
                metric = metrics{q,1};
                improvement = metrics{q,2};

                W = exact_signed_rank_dp(improvement);

                rn = rn+1;
                rows(rn,:) = { ...
                    char(inst),label,metric,height(improvement), ...
                    mean(improvement),median(improvement), ...
                    sum(improvement>1e-12), ...
                    W.wPlus,W.wMinus,W.rankBiserial, ...
                    W.pTwoSided,NaN};

                if strcmp(label,cfg.statistics.primaryContrast) && ...
                   any(strcmp(cfg.statistics.primaryMetrics,metric))
                    primaryP(end+1,1) = W.pTwoSided; %#ok<AGROW>
                    primaryRows(end+1,1) = rn; %#ok<AGROW>
                end
            end
        end
    end

    adj = holm_adjust(primaryP);

    for j = 1:numel(adj)
        rows{primaryRows(j),12} = adj(j);
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Contrast','Metric','Runs', ...
        'MeanImprovement','MedianImprovement','ImprovedRuns', ...
        'WPlus','WMinus','RankBiserial','ExactP_TwoSided', ...
        'HolmAdjustedP_PrimaryFamily'});
end

function T = win_tie_loss_instances(D)
    contrasts = unique(string(D.Contrast),'stable');

    rows = {};
    rn = 0;

    for c = 1:numel(contrasts)
        X = D(string(D.Contrast)==contrasts(c),:);

        fields = { ...
            'HV','MeanHVAdvantageB'; ...
            'IGD','MeanIGDAdvantageB'; ...
            'MinTEC','MeanMinTECAdvantageB'};

        for q = 1:size(fields,1)
            v = X.(fields{q,2});

            wins = sum(v>1e-12);
            losses = sum(v<-1e-12);
            ties = numel(v)-wins-losses;

            rn = rn+1;
            rows(rn,:) = { ...
                char(contrasts(c)),fields{q,1},wins,ties,losses};
        end
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Contrast','Metric','Wins','Ties','Losses'});
end

function T = summarize_runtime(R)
    instances = unique(string(R.Instance),'stable');
    rows = cell(numel(instances),9);

    for i = 1:numel(instances)
        X = R(string(R.Instance)==instances(i),:);

        rows(i,:) = { ...
            char(instances(i)),height(X), ...
            mean(X.FINALTarget_s), ...
            mean(X.CONTActual_s), ...
            mean(X.FollowupCUT_s), ...
            mean(X.StrongControlTotal_s), ...
            mean(X.StrongControlExtraOverFINAL_s), ...
            mean(X.StrongControlExtraOverFINALFraction), ...
            mean(X.SelectedPoints)};
    end

    T = cell2table(rows,'VariableNames',{ ...
        'Instance','Runs', ...
        'MeanFINALTarget_s','MeanCONTActual_s','MeanFollowupCUT_s', ...
        'MeanStrongControlTotal_s', ...
        'MeanStrongControlExtraOverFINAL_s', ...
        'MeanStrongControlExtraOverFINALFraction', ...
        'MeanSelectedPoints'});
end

function T = summarize_schedules(S)
    instances = unique(string(S.Instance),'stable');
    rows = cell(numel(instances)+1,8);

    for i = 1:numel(instances)
        X = S(string(S.Instance)==instances(i),:);
        rows(i,:) = one_row(char(instances(i)),X);
    end

    rows(end,:) = one_row('ALL',S);

    T = cell2table(rows,'VariableNames',{ ...
        'Group','Schedules','MeanTECReductionPct', ...
        'StrictReductionCount','MeanCUTWall_s', ...
        'MeanCUTNodes','MeanCUTEdges','CertificateFailures'});
end

function row = one_row(label,X)
    row = { ...
        label,height(X), ...
        mean(X.TECReductionPct), ...
        sum(X.TECReduction>1e-6), ...
        mean(X.CUTWall_s), ...
        mean(X.CUTNodes), ...
        mean(X.CUTEdges), ...
        sum(~X.CertificateValid)};
end

function make_relative_figure(D,contrast,figRoot)
    X = D(strcmp(D.Contrast,contrast),:);

    Y = [ ...
        X.MeanRelativeHVAdvantagePct, ...
        X.MeanRelativeIGDAdvantagePct];

    f = figure('Visible','off','Position',[100 100 1200 520]);
    bar(Y);
    xticks(1:height(X));
    xticklabels(X.Instance);
    xtickangle(45);
    ylabel('Mean relative advantage of FINAL (%)');
    legend({'HV higher','IGD lower'},'Location','best');
    title(strrep(contrast,'_',' '));
    grid on;

    exportgraphics(f, ...
        fullfile(figRoot,[lower(contrast) '_relative.png']), ...
        'Resolution',220);

    exportgraphics(f, ...
        fullfile(figRoot,[lower(contrast) '_relative.pdf']));

    close(f);
end

function make_runtime_figure(R,figRoot)
    Y = [R.MeanFINALTarget_s,R.MeanStrongControlTotal_s];

    f = figure('Visible','off','Position',[100 100 1100 500]);
    bar(Y);
    xticks(1:height(R));
    xticklabels(R.Instance);
    xtickangle(45);
    ylabel('Additional wall time (s)');
    legend({'FINAL','CONT_FINAL -> CUT strong control'}, ...
        'Location','best');
    title('Strong-control computation budget');
    grid on;

    exportgraphics(f, ...
        fullfile(figRoot,'strong_control_runtime.png'), ...
        'Resolution',220);

    exportgraphics(f, ...
        fullfile(figRoot,'strong_control_runtime.pdf'));

    close(f);
end

function ensure_dir(p)
    if ~isfolder(p), mkdir(p); end
end
