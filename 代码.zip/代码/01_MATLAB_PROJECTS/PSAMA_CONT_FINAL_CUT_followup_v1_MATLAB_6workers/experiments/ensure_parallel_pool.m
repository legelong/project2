function info = ensure_parallel_pool(requestedWorkers)
%ENSURE_PARALLEL_POOL Start/reuse a local parallel pool safely.
%
% The saved default is 6 workers.
% If MATLAB's current local cluster allows fewer workers, this function
% automatically caps the request instead of falling back to serial execution.

    hw = hardware_profile();

    if nargin < 1 || isempty(requestedWorkers)
        requestedWorkers = hw.defaultWorkers;
    end

    info.enabled = false;
    info.numWorkers = 1;
    info.requestedWorkers = requestedWorkers;
    info.pool = [];
    info.profile = hw.parallelProfile;

    hasParallel = license('test','Distrib_Computing_Toolbox') && ...
                  ~isempty(ver('parallel'));

    if ~hasParallel
        fprintf('[Parallel] Toolbox unavailable -> serial execution.\n');
        return;
    end

    try
        profile = parallel.defaultClusterProfile;
        cluster = parcluster(profile);
        maxWorkers = cluster.NumWorkers;
    catch
        profile = hw.parallelProfile;
        cluster = parcluster(profile);
        maxWorkers = cluster.NumWorkers;
    end

    actualWorkers = min(requestedWorkers,maxWorkers);

    if actualWorkers < requestedWorkers
        fprintf(['[Parallel] Requested %d workers, but profile "%s" allows %d. ' ...
                 'Using %d workers.\n'], ...
                 requestedWorkers,profile,maxWorkers,actualWorkers);
    end

    pool = gcp('nocreate');

    if isempty(pool)
        fprintf('[Parallel] Starting "%s" pool with %d workers...\n', ...
            profile,actualWorkers);
        pool = parpool(profile,actualWorkers);

    elseif pool.NumWorkers ~= actualWorkers
        fprintf(['[Parallel] Existing pool has %d workers. ' ...
                 'Recreating with %d workers...\n'], ...
                 pool.NumWorkers,actualWorkers);
        delete(pool);
        pool = parpool(profile,actualWorkers);
    end

    info.enabled = true;
    info.numWorkers = pool.NumWorkers;
    info.pool = pool;
    info.profile = profile;

    fprintf('[Parallel] Pool ready with %d workers.\n',info.numWorkers);
end
