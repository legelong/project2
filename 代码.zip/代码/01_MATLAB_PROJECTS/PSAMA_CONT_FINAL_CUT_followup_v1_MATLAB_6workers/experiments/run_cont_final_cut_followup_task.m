function summary = run_cont_final_cut_followup_task( ...
    task,cfg,expCfg,resultRoot)
%RUN_CONT_FINAL_CUT_FOLLOWUP_TASK Apply CUT to saved CONT_FINAL representatives.

    outDir = fullfile(resultRoot,'raw',task.instanceName);

    if ~isfolder(outDir)
        mkdir(outDir);
    end

    outFile = fullfile(outDir,sprintf('run_%02d.mat',task.runIndex));

    if expCfg.resume && isfile(outFile)
        try
            S = load(outFile,'record');

            if isfield(S,'record') && ...
               isfield(S.record,'complete') && ...
               S.record.complete
                summary = S.record.summary;
                summary.skipped = true;
                return;
            end
        catch
        end
    end

    srcFile = fullfile(cfg.project.root,'source_results', ...
        cfg.repository.sourceTag,'raw',task.instanceName, ...
        sprintf('run_%02d.mat',task.runIndex));

    S = load(srcFile,'record');
    src = S.record;

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir, ...
        [task.instanceName '.txt']),cfg);

    X = src.followup.contSelectedChromosomes;
    savedObj = src.followup.contSelectedObjectives;

    if isvector(savedObj) && numel(savedObj)==2
        savedObj = reshape(savedObj,1,2);
    end

    K = size(savedObj,1);
    cutObj = nan(K,2);
    traces = cell(K,1);

    % Full follow-up CUT wall time includes chromosome decoding and CUT solve,
    % matching the operational interpretation of applying this postprocessor.
    tFollow = tic;

    for k = 1:K
        [obj,decoded] = evaluate_solution(X(k,:),inst,cfg);

        if max(abs(obj-savedObj(k,:)))>1e-8
            error('PSAMA:FollowupDecodeMismatch', ...
                'Saved CONT_FINAL chromosome/objective mismatch.');
        end

        deadline = decoded.makespan;

        t = tic;
        sol = solve_cut_retime(decoded,inst,cfg,deadline);
        solveWall = toc(t);

        if sol.totalTEC > decoded.cost.total+cfg.block.objectiveTolerance
            error('PSAMA:FollowupCUTWorse', ...
                'CUT became worse than its CONT_FINAL source schedule.');
        end

        cutObj(k,:) = sol.decoded.objectives;

        tr.selectedPoint = k;
        tr.sourceObjectives = obj;
        tr.cutObjectives = sol.decoded.objectives;
        tr.deadline = deadline;

        tr.tecReduction = obj(2)-sol.totalTEC;
        tr.tecReductionPct = ...
            100*tr.tecReduction/max(obj(2),eps);

        tr.cutWallSeconds = solveWall;
        tr.cutNodes = sol.nodes;
        tr.cutEdges = sol.edges;
        tr.certificateValid = sol.certificateValid;

        traces{k} = tr;
    end

    followupCutElapsed = toc(tFollow);

    fronts.BASE = src.fronts.BASE;
    fronts.CUT = src.fronts.CUT;
    fronts.CUT_CBJ1 = src.fronts.CUT_CBJ1;
    fronts.FINAL = src.fronts.FINAL;
    fronts.CONT_FINAL = src.fronts.CONT_FINAL;

    fronts.CONT_CUT = nondominated_objectives( ...
        [src.fronts.CONT_FINAL;cutObj]);

    summary.instance = task.instanceName;
    summary.run = task.runIndex;
    summary.seed = src.summary.seed;

    summary.selectedPoints = K;

    summary.finalTargetSeconds = src.summary.finalTargetSeconds;
    summary.contActualSeconds = src.summary.CONTActualSeconds;

    summary.followupCUTSeconds = followupCutElapsed;
    summary.strongControlTotalSeconds = ...
        src.summary.CONTActualSeconds+followupCutElapsed;

    summary.strongControlExtraOverFinalSeconds = ...
        summary.strongControlTotalSeconds-src.summary.finalTargetSeconds;

    summary.strongControlExtraOverFinalFraction = ...
        summary.strongControlExtraOverFinalSeconds / ...
        max(src.summary.finalTargetSeconds,eps);

    summary.skipped = false;

    record.complete = true;
    record.summary = summary;
    record.fronts = fronts;
    record.traces = traces;
    record.cutObjectives = cutObj;

    save(outFile,'record','-v7');
end
