function report = run_selfcheck()
%RUN_SELFCHECK Source-material and CUT regression for strong follow-up.

    setup_project();
    audit_config_fields();
    assert_digraph_maxflow_available();

    cfg = make_shared_config();
    expCfg = make_cont_final_cut_followup_experiment();

    sourceReport = validate_followup_sources(cfg,expCfg);

    % Check one real predecessor schedule end-to-end.
    srcFile = fullfile(cfg.project.root,'source_results', ...
        cfg.repository.sourceTag,'raw','100J6F','run_01.mat');

    S = load(srcFile,'record');
    R = S.record;

    inst = load_dhfjsp_instance( ...
        fullfile(cfg.paths.dhfjspInstanceDir,'100J6F.txt'),cfg);

    X = R.followup.contSelectedChromosomes;
    F = R.followup.contSelectedObjectives;

    if isvector(F) && numel(F)==2
        F = reshape(F,1,2);
    end

    [obj,decoded] = evaluate_solution(X(1,:),inst,cfg);

    assert(max(abs(obj-F(1,:)))<1e-8);

    sol = solve_cut_retime(decoded,inst,cfg,decoded.makespan);

    assert(sol.totalTEC<=decoded.cost.total+cfg.block.objectiveTolerance);
    assert(sol.certificateValid);

    report.ok = true;
    report.sourcesChecked = sourceReport.checked;
    report.sourceTEC = decoded.cost.total;
    report.cutTEC = sol.totalTEC;
    report.cutReduction = decoded.cost.total-sol.totalTEC;

    fprintf(['[PASS] Follow-up self-check: sources=%d, ' ...
             '100J6F sourceTEC=%.3f, CUT=%.3f, reduction=%.3f.\n'], ...
        report.sourcesChecked,report.sourceTEC, ...
        report.cutTEC,report.cutReduction);
end
